package com.techm.auto.autorunner.vo;

import java.util.ArrayList;
import java.util.List;


public class ProjectVO {

	private int projectId;

	private String projectName;
	
	private List<TestCasesVO> lstCases = new ArrayList<TestCasesVO>();
	
	private List<String> allprojectnames = new ArrayList<String>();
	
         
	public int getProjectId() {
		return projectId;
	}

	public List<String> getAllprojectnames() {
		return allprojectnames;
	}

	public void setAllprojectnames(List<String> allprojectnames) {
		this.allprojectnames = allprojectnames;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public List<TestCasesVO> getLstCases() {
		return lstCases;
	}

	public void setLstCases(List<TestCasesVO> lstCases) {
		this.lstCases = lstCases;
	}

	

}
