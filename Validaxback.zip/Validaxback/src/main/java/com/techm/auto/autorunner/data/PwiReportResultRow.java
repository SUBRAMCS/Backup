package com.techm.auto.autorunner.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * This class is used to maintain report input details.
 * @author : 212321748
 * @version : 1.0 
 */
public class PwiReportResultRow {

	private long i;
	private List<String> vals = new ArrayList<String>();
	
	public PwiReportResultRow(){}
	
	public PwiReportResultRow(long i, ArrayList<String> vals){
		this.i = i;
		this.vals = vals;
		
	}

	public long getI() {
		return i;
	}

	public void setI(long i) {
		this.i = i;
	}

	public List<String> getVals() {
		return vals;
	}

	public void setVals(ArrayList<String> vals) {
		this.vals = vals;
	}
	

}
