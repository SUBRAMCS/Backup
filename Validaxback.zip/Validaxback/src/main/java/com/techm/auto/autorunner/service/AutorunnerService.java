package com.techm.auto.autorunner.service;


import java.sql.SQLException;
import java.util.List;

import com.techm.auto.autorunner.common.Dropdown;
import com.techm.auto.autorunner.data.DataSourceData;
import com.techm.auto.autorunner.vo.Project;
import com.techm.auto.autorunner.vo.TestCasesVO;
import com.techm.auto.autorunner.vo.TestExecutionVO;
import com.techm.auto.autorunner.vo.TreeMenuVO;


/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object for object types.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface AutorunnerService {
	/**
	 * Used in Quick Intelligence and click-through menus
	 * @return all PWi Object Types for
	 */
	public List<Dropdown> findAllDataSources();

	public List<TestCasesVO> findAllTestCaseDtls(String projectid);

	public List<TestCasesVO> compareQueries(List<TestCasesVO> lstTestCaseVo) throws SQLException;

	public TestCasesVO compareTestQuery(TestCasesVO testCaseVo) throws SQLException;

	public int saveSelectedCases(TestCasesVO testExecVo);

	public List<TreeMenuVO> getUserProjects(int userId);

	public List<TestCasesVO> findSpecificTestCasedetails(String testcaseid);

	public int saveNewPrj(String projectname, String projectdesc, String projectowner);

	public int addTestCase(TestCasesVO testExecVo);

	public int deleteTestCase(TestCasesVO testExecVo);

	public int saveDS(Dropdown dropdown);

	public int editTestCaseName(TestCasesVO testExecVo);

	public int editPrjName(Project prj);

	public int deletePrj(Project prj);
	
	public int deleteDB(DataSourceData data);

	public int testDS(Dropdown dropdown) throws SQLException, ClassNotFoundException;
	
	public int writeExcel(TestCasesVO testCaseVo) throws SQLException;

    public int saveSelectedLstCases(int projectId,List<TestCasesVO> lstTestCases, boolean optradio);

    public int getMaxValcasefrPrj(int projectid);

    public int deleteAllTestCases(List<TestCasesVO> lstTtestCaseVo);

}
