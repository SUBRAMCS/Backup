package com.techm.auto.autorunner.database;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Configuration file to get appropriate template for database connection
 * */
public interface DatabaseTemplates {

	/*
	 * return appropriate data source
	 * */
	JdbcTemplate getDatasourceTemplate(String dsn);
	
	/*
	 * return template type
	 * */
	String getDatasourceTemplateType(String dsn);
}
