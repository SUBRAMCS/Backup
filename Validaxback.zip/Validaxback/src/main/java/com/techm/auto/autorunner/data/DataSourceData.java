package com.techm.auto.autorunner.data;

public class DataSourceData {

	private int dsid;
	private String dsname;
	private boolean active;
	private String dsType;
	private String dsUrl;
	private String dsUserName;
	private String dsPassword;
	private String dsHost;
	private String dsPort;
	private String dsService;	
	private String dsServiceType;
	
	
	public String getDsHost() {
		return dsHost;
	}
	public void setDsHost(String dsHost) {
		this.dsHost = dsHost;
	}
	public String getDsPort() {
		return dsPort;
	}
	public void setDsPort(String dsPort) {
		this.dsPort = dsPort;
	}
	public String getDsService() {
		return dsService;
	}
	public void setDsService(String dsService) {
		this.dsService = dsService;
	}
	public String getDsServiceType() {
		return dsServiceType;
	}
	public void setDsServiceType(String dsServiceType) {
		this.dsServiceType = dsServiceType;
	}
	public int getDsid() {
		return dsid;
	}
	public void setDsid(int dsid) {
		this.dsid = dsid;
	}
	public String getDsname() {
		return dsname;
	}
	public void setDsname(String dsname) {
		this.dsname = dsname;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getDsType() {
		return dsType;
	}
	public void setDsType(String dsType) {
		this.dsType = dsType;
	}
	public String getDsUrl() {
		return dsUrl;
	}
	public void setDsUrl(String dsUrl) {
		this.dsUrl = dsUrl;
	}
	public String getDsUserName() {
		return dsUserName;
	}
	public void setDsUserName(String dsUserName) {
		this.dsUserName = dsUserName;
	}
	public String getDsPassword() {
		return dsPassword;
	}
	public void setDsPassword(String dsPassword) {
		this.dsPassword = dsPassword;
	}
	
}
