package com.techm.auto.autorunner.config;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DBInitializeConfig {

    @Autowired
    private DataSource dataSource;
    
    @PostConstruct
    public void initialize(){
        try {
            Connection connection = dataSource.getConnection();
            Statement statement = connection.createStatement();
            
            statement.executeUpdate("CREATE TABLE if not exists PROJECT ( " +
                    "PROJECT_ID INTEGER Primary key AUTOINCREMENT, " +
                    "PROJECT_NAME VARCHAR(50) not null ) "  
                    );
            System.out.println("project created successfully");
                
            statement.executeUpdate(
                    "CREATE TABLE if not exists  TEST_CASES (" +
                    "PROJECT_ID INTEGER , " +
                    "TCNAME INTEGER(30)  null," +
                    "DESCRIPTION varchar(200)  null," +
                    "TCQRYONE varchar(4000) null," +
                    "TCQRYTWO varchar(4000)  null, " +
                    "FOREIGN KEY (PROJECT_ID) REFERENCES project (PROJECT_ID) "+
                    "ON UPDATE SET NULL)"
             );

            statement.executeUpdate(
                    "CREATE TABLE if not exists DATA_SOURCES (" +
                    "DSID INTEGER Primary key AUTOINCREMENT, " +
                    "DSNAME varchar(50) not null," +
                    "ACTIVE boolean  null ," +
                    "DSTYPE varchar(20)  , "+
                    "HOSTNAME  varchar(70)  ,"+
                    "PORT  varchar(10)  ,"+
                    "SERVICE  varchar(10)  ,"+
                    "SERVICETYPE  varchar(10)  ,"+
                    "DBUSERNAME varchar(50) ,"+
                    "DBPASSWORD varchar(50)  )"
                    );
          
            statement.close();
            connection.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
