/**
 * This class is a service interface for getting report related data.
 * @author : 212321748
 * @version : 1.0 
 */
package com.techm.auto.autorunner.dao;

import java.sql.SQLException;
import java.util.List;

import com.techm.auto.autorunner.common.Dropdown;

public interface PwiProcessXMLRepo {
	
	/*
	 * Process query for report inputs like dropdown/lookup/multiselect/combo
	 * */
	List<Dropdown> getListData(String query, String dsn) throws SQLException;
}
