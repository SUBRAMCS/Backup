package com.techm.auto.autorunner.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class DBConfig {
	
	@Bean(name="sqliteDs")
	@Primary
	public DataSource dataSource() {
	        DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
	        dataSourceBuilder.driverClassName("org.sqlite.JDBC");
	        dataSourceBuilder.url("jdbc:sqlite:ValidaXDB.db");
	        return dataSourceBuilder.build();   
	}
    
    
    @Bean(name = "jdbcSqlite") 
    public JdbcTemplate jdbcTemplate(@Qualifier("sqliteDs") DataSource oraDs) { 
        return new JdbcTemplate(oraDs); 
    }
    
    @Bean(name="oraDs")
    @ConfigurationProperties(prefix="spring.orads")
    public DataSource dataSourceOra() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean(name = "jdbcOrads") 
    public JdbcTemplate jdbcTemplateOra(@Qualifier("oraDs") DataSource oraDs) { 
        return new JdbcTemplate(oraDs); 
    }
    
    @Bean(name = "trnsPLMRDs") 
    public PlatformTransactionManager  transTemplatePLMR(@Qualifier("plmrDs") DataSource plmrDs) { 
        return new DataSourceTransactionManager(plmrDs); 
    }
    /*
	 * OT ends here
	 * */
	
    /*
	 * DT - data-source configuration for TeraData
	 * */
    @Bean(name="teraDs")
    @ConfigurationProperties(prefix="spring.terads")
    public DataSource dataSourceTera() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean(name = "jdbcTerads") 
    public JdbcTemplate jdbcTemplateTr(@Qualifier("teraDs") DataSource teraDs) { 
        return new JdbcTemplate(teraDs); 
    }	 
	/*
	 * DT ends here
	 * */
    
    /*
	 * RT - data-source configuration for RPLM
	 * */
    @Bean(name="rplmDs")
    @ConfigurationProperties(prefix="spring.rplmds")
    public DataSource dataSourceRPLM() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean(name = "jdbcRPLMDs") 
    public JdbcTemplate jdbcTemplateRPLM(@Qualifier("rplmDs") DataSource rplmDs) { 
        return new JdbcTemplate(rplmDs); 
    }	 
	/*
	 * RT ends here
	 * */
    
    /*
	 * PT - data-source configuration for PLMR Person
	 * */
    @Bean(name="plmrDs")
    @ConfigurationProperties(prefix="spring.plmrds")
    public DataSource dataSourcePLMR() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean(name = "jdbcPLMRDs") 
    public JdbcTemplate jdbcTemplatePLMR(@Qualifier("plmrDs") DataSource plmrDs) { 
        return new JdbcTemplate(plmrDs); 
    }
    
    /*
   	 * PT - data-source configuration for PLMR Person
   	 * */
    
    @Bean(name="dspDs")
    @ConfigurationProperties(prefix="spring.dspds")
    public DataSource dataSourceSQLServ() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean(name = "jdbcSQLServDs") 
    public JdbcTemplate jdbcTemplateSQLServ(@Qualifier("dspDs") DataSource dspDs) { 
        return new JdbcTemplate(dspDs); 
    }
    
}
