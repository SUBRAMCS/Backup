package com.techm.auto.autorunner.vo;

import java.io.Serializable;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;

public class TestCasesVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private int projectId;
    private String projectName;
    private String testCaseId;
    private String testCaseName;
    private String description;
    private String testQryOne;
    private String testQryTwo;
    private String testDSOne;
    private String testDSTwo;
    private String testDSNmOne;
    private String testDSNmTwo;
    private String testResultFlag;
    private String testResultStats;
    private boolean testExecFlag=true;
    private boolean collapse=true;
    private boolean editTestCase = false;
    private List<HashMap<String, String>> compareMap ;
    private HashMap<String,List<String>> diffColMapLft ;
    private HashMap<String,List<String>> diffColMapRht ;
    private List<ResultSetMetaData> metaDataList ;
    private String testCaseCode;
    private boolean newTestCase;
    
    public String getTestCaseId() {
        return testCaseId;
    }

    public void setTestCaseId(String testCaseId) {
        this.testCaseId = testCaseId;
    }

    public String getTestQryOne() {
        return testQryOne;
    }

    public void setTestQryOne(String testQryOne) {
        this.testQryOne = testQryOne;
    }

    public String getTestQryTwo() {
        return testQryTwo;
    }

    public void setTestQryTwo(String testQryTwo) {
        this.testQryTwo = testQryTwo;
    }

    public String getTestDSOne() {
        return testDSOne;
    }

    public void setTestDSOne(String testDSOne) {
        this.testDSOne = testDSOne;
    }

    public String getTestDSTwo() {
        return testDSTwo;
    }

    public void setTestDSTwo(String testDSTwo) {
        this.testDSTwo = testDSTwo;
    }

    public boolean isTestExecFlag() {
        return testExecFlag;
    }

    public void setTestExecFlag(boolean testExecFlag) {
        this.testExecFlag = testExecFlag;
    }

    public String getTestCaseName() {
        return testCaseName;
    }

    public void setTestCaseName(String testCaseName) {
        this.testCaseName = testCaseName;
    }

    public String getTestResultStats() {
        return testResultStats;
    }

    public void setTestResultStats(String testResultStats) {
        this.testResultStats = testResultStats;
    }

    public String getTestResultFlag() {
        return testResultFlag;
    }

    public void setTestResultFlag(String testResultFlag) {
        this.testResultFlag = testResultFlag;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isCollapse() {
        return collapse;
    }

    public void setCollapse(boolean collapse) {
        this.collapse = collapse;
    }

    public String getTestDSNmOne() {
        return testDSNmOne;
    }

    public void setTestDSNmOne(String testDSNmOne) {
        this.testDSNmOne = testDSNmOne;
    }

    public String getTestDSNmTwo() {
        return testDSNmTwo;
    }

    public void setTestDSNmTwo(String testDSNmTwo) {
        this.testDSNmTwo = testDSNmTwo;
    }

    public List<HashMap<String, String>> getCompareMap() {
        return compareMap;
    }

    public void setCompareMap(List<HashMap<String, String>> compareMap) {
        this.compareMap = compareMap;
    }

    public HashMap<String, List<String>> getDiffColMapLft() {
        if(diffColMapLft==null)
            diffColMapLft= new HashMap<String,List<String>> ();
        return diffColMapLft;
    }

    public void setDiffColMapLft(HashMap<String, List<String>> diffColMapLft) {
        if(diffColMapLft==null)
            diffColMapLft= new HashMap<String,List<String>> ();
        this.diffColMapLft = diffColMapLft;
    }

    public HashMap<String, List<String>> getDiffColMapRht() {
        if(diffColMapRht==null)
            diffColMapRht =new HashMap<String,List<String>> ();
        return diffColMapRht;
    }

    public void setDiffColMapRht(HashMap<String, List<String>> diffColMapRht) {
        if(diffColMapRht==null)
            diffColMapRht =new HashMap<String,List<String>> ();
        this.diffColMapRht = diffColMapRht;
    }

    /*public List<ResultSetMetaData> getMetaDataList() {
        if(metaDataList==null)
            metaDataList=new ArrayList<ResultSetMetaData>();
        return metaDataList;
    }*/

    public void setMetaDataList(List<ResultSetMetaData> metaDataList) {
        if(metaDataList==null)
            metaDataList=new ArrayList<ResultSetMetaData>();
        this.metaDataList = metaDataList;
    }

    public String getTestCaseCode() {
      return testCaseCode;
    }

    public void setTestCaseCode(String testCaseCode) {
      this.testCaseCode = testCaseCode;
    }

    public boolean isEditTestCase() {
      return editTestCase;
    }

    public void setEditTestCase(boolean editTestCase) {
      this.editTestCase = editTestCase;
    }

    public boolean isNewTestCase() {
      return newTestCase;
    }

    public void setNewTestCase(boolean newTestCase) {
      this.newTestCase = newTestCase;
    }
    
    
}