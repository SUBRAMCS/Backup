package com.techm.auto.autorunner.serviceImpl;


import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techm.auto.autorunner.common.Dropdown;
import com.techm.auto.autorunner.dao.AutorunnerDAO;
import com.techm.auto.autorunner.data.DataSourceData;
import com.techm.auto.autorunner.service.AutorunnerService;
import com.techm.auto.autorunner.vo.Project;
import com.techm.auto.autorunner.vo.TestCasesVO;
import com.techm.auto.autorunner.vo.TestExecutionVO;
import com.techm.auto.autorunner.vo.TreeMenuVO;


/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object for object types.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
@Service
public class AutorunnerServiceImpl implements AutorunnerService {

	@Autowired
	private AutorunnerDAO autoRunDao;
	
	@Override
	public List<Dropdown> findAllDataSources() {
		// TODO Auto-generated method stub
		return autoRunDao.findAllDataSources();
	}

	@Override
	public List<TestCasesVO> findAllTestCaseDtls(String projectid) {
		// TODO Auto-generated method stub
		return autoRunDao.findAllTestCaseDtls(projectid);
	}
	public List<TestCasesVO> findSpecificTestCasedetails(String testcaseid) {
		// TODO Auto-generated method stub
		return autoRunDao.findSpecificTestCasedetails(testcaseid);
	}
	

	@Override
	public List<TestCasesVO> compareQueries(List<TestCasesVO> lstTestCaseVo)
			throws SQLException {
		// TODO Auto-generated method stub
		return autoRunDao.compareQueries(lstTestCaseVo);
	}

	@Override
	public TestCasesVO compareTestQuery(TestCasesVO testCaseVo)
			throws SQLException {
		// TODO Auto-generated method stub
		return autoRunDao.compareTestQuery(testCaseVo);
	}

	@Override
	public int saveSelectedCases(TestCasesVO testExecVo) {
		// TODO Auto-generated method stub
		return autoRunDao.saveSelectedCases(testExecVo);
	}
	/**
	 * Used in Quick Intelligence and click-through menus
	 * @return all PWi Object Types for
	 */

	@Override
	public List<TreeMenuVO> getUserProjects(int userId) {
		// TODO Auto-generated method stub
		return autoRunDao.getUserProjects(userId);
	}

	@Override
	public int saveNewPrj(String projectname, String projectdesc, String projectowner) {
		// TODO Auto-generated method stub
		return autoRunDao.saveNewPrj(projectname,projectdesc,projectowner);
	}

	@Override
	public int addTestCase(TestCasesVO testExecVo) {
		// TODO Auto-generated method stub
		return autoRunDao.addTestCase(testExecVo);
	
	}

	@Override
	public int deleteTestCase(TestCasesVO testExecVo) {
		// TODO Auto-generated method stub
		return autoRunDao.deleteTestCase(testExecVo);
	}

	@Override
	public int saveDS( Dropdown dropdown) {
		// TODO Auto-generated method stub
		return autoRunDao.saveDS(dropdown);
	}

	@Override
	public int editTestCaseName(TestCasesVO testExecVo) {
		// TODO Auto-generated method stub
		return autoRunDao.editTestCaseName(testExecVo);
	}

	@Override
	public int editPrjName(Project prj) {
		// TODO Auto-generated method stub
		return autoRunDao.editPrjName(prj);
	}

	@Override
	public int deletePrj(Project prj) {
		// TODO Auto-generated method stub
		return autoRunDao.deletePrj(prj);
	}

	@Override
	public int deleteDB(DataSourceData data) {
		// TODO Auto-generated method stub
		return autoRunDao.deleteDB(data);
	}

	@Override
	public int testDS(Dropdown dropdown) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return autoRunDao.testDS(dropdown);
	}

	@Override
    public int writeExcel(TestCasesVO testCaseVo) throws SQLException {
        // TODO Auto-generated method stub
        return 0;//autoRunDao.writeExcel(testCaseVo);
    }

    @Override
    public int saveSelectedLstCases(int projectId,List<TestCasesVO> lstTestCases,boolean optradio) {
        // TODO Auto-generated method stub
      if(optradio) {
        autoRunDao.deleteExistingRecordFrPrj(projectId);
      }
        return autoRunDao.saveSelectedLstCases(projectId,lstTestCases);
    }

    @Override
    public int getMaxValcasefrPrj(int projectid) {
      // TODO Auto-generated method stub
      return autoRunDao.getMaxValcasefrPrj(projectid);
    }

    @Override
    public int deleteAllTestCases(List<TestCasesVO> lstTtestCaseVo) {
      // TODO Auto-generated method stub
      return autoRunDao.deleteAllTestCases(lstTtestCaseVo);
    }	

}
