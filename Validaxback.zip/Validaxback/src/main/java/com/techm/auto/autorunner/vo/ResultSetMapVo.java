package com.techm.auto.autorunner.vo;

import java.io.Serializable;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;

public class ResultSetMapVo implements Serializable {

	private static final long serialVersionUID = 1L;

	private ResultSetMetaData resultSetMetaData;
	private ArrayList<ArrayList<String>> lstFinalDataBlock = new ArrayList<ArrayList<String>>();
	private int rowCounter = 0;
	private String errorCode;
	
    public ResultSetMetaData getResultSetMetaData() {
      return resultSetMetaData;
    }
    public void setResultSetMetaData(ResultSetMetaData resultSetMetaData) {
      this.resultSetMetaData = resultSetMetaData;
    }
    public ArrayList<ArrayList<String>> getLstFinalDataBlock() {
      return lstFinalDataBlock;
    }
    public void setLstFinalDataBlock(ArrayList<ArrayList<String>> lstFinalDataBlock) {
      this.lstFinalDataBlock = lstFinalDataBlock;
    }
    public int getRowCounter() {
      return rowCounter;
    }
    public void setRowCounter(int rowCounter) {
      this.rowCounter = rowCounter;
    }
    public String getErrorCode() {
      return errorCode;
    }
    public void setErrorCode(String errorCode) {
      this.errorCode = errorCode;
    }
		
}
