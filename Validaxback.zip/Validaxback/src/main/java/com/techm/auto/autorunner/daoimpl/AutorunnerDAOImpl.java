package com.techm.auto.autorunner.daoimpl;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.techm.auto.autorunner.common.Dropdown;
import com.techm.auto.autorunner.common.PLMUtils;
import com.techm.auto.autorunner.dao.AutorunnerDAO;
import com.techm.auto.autorunner.data.DataSourceData;
import com.techm.auto.autorunner.data.PWiResultSetColMetaData;
import com.techm.auto.autorunner.data.PwiReportResultRow;
import com.techm.auto.autorunner.data.PwiReportResultRowMetaData;
import com.techm.auto.autorunner.database.DatabaseTemplates;
import com.techm.auto.autorunner.vo.Project;
import com.techm.auto.autorunner.vo.ProjectVO;
import com.techm.auto.autorunner.vo.ResultSetMapVo;
import com.techm.auto.autorunner.vo.TestCasesVO;
import com.techm.auto.autorunner.vo.TestExecutionVO;
import com.techm.auto.autorunner.vo.TreeMenuVO;

/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : ObjectTypeDAOImpl
 * 
 * Revision Log Jan 20, 2012 | v1.0. --------------------------------------------------------------
 */
@Service
public class AutorunnerDAOImpl implements AutorunnerDAO {

  @Autowired
  @Qualifier("jdbcSqlite")
  private JdbcTemplate      jdbcTemplate;

  @Autowired
  @Qualifier("jdbcOrads")
  private JdbcTemplate      jdbcTemplateOracle;

  @Autowired
  @Qualifier("jdbcPLMRDs")
  private JdbcTemplate      jdbcTeradsTr;

  @Autowired
  @Qualifier("jdbcSQLServDs")
  private JdbcTemplate      jdbcTemplateSQLServ;

  @Autowired
  private DatabaseTemplates pwiDatabaseTemplate;

  private String            findDataSource              =
      "SELECT dsid, dsname,active,dsType,hostname,port,service,servicetype,DBUSERNAME,DBPASSWORD FROM DATA_SOURCES order by dsname ";

  private String            deletedb                    = "delete from DATA_SOURCES where dsid = ?";

  private String            addDataSource               = "INSERT INTO DATA_SOURCES "
      + "(dsname,active,dsType,hostname,port,service,servicetype,DBUSERNAME,DBPASSWORD)" + "VALUES"
      + "(?,'true',?,?,?,?,?,?,?)";
  private String            updateDataSource            =
      "update DATA_SOURCES set dsname=?, dsType=?, hostname=?,port=?, service=?,servicetype=?,DBUSERNAME=?,DBPASSWORD=? where dsid=?";

  private String  findTestCases      =
      "SELECT TCNAME,DESCRIPTION,TCQRYONE,TCQRYTWO,PROJECT_ID FROM TEST_CASES ";

  private String            insertTestCase              = "INSERT INTO TEST_CASES "
      + "(PROJECT_ID,TCNAME,DESCRIPTION,TCQRYONE,TCQRYTWO) " + "VALUES "
      + "(?,?,?,?,?)";
  private String            updateTestCase              =
      "UPDATE TEST_CASES SET DESCRIPTION=?, TCQRYONE = ?, TCQRYTWO = ? WHERE TCNAME = ? AND PROJECT_ID = ? ";

  private String            editTestCaseName            =
      "UPDATE TEST_CASES SET tcname = ?  where tcid = ? ";

  private String            insertNewProject            =
      "INSERT INTO PROJECT " + "(PROJECT_NAME)" + "VALUES" + "(?)";

  private String            editPrjName                 =
      "UPDATE PROJECT SET PROJECT_NAME= ? where PROJECT_ID=? ";
  private String            findallprojectname          = " select PROJECT_NAME from PROJECT order by PROJECT_NAME ";
  private String            deletePrj                   =
      "Delete from PROJECT " + " where " + " PROJECT_ID=?";

  private String            insertNewTestCase           = "INSERT INTO TEST_CASES"
      + "(PROJECT_ID,TCNAME,description,tcqryone,tcqrytwo)" + "VALUES"
      + "(?,?,?,?,?)";

  private String            deleteNewTestCase           =
      "Delete from TEST_CASES" + " where " + " PROJECT_ID = ? AND  TCNAME =?";

  private String            findProjForUsers            =
      "SELECT PROJECT_ID,PROJECT_NAME FROM PROJECT order by PROJECT_NAME ";

  private String            findTstCasesFrProj          =
      "SELECT tcname,tcqryone,tcqrytwo,USRPRJ.PROJECT_ID,PROJECT_NAME,description FROM TEST_CASES TSCS LEFT JOIN PROJECT USRPRJ ON TSCS.PROJECT_ID = USRPRJ.PROJECT_ID where USRPRJ.PROJECT_ID = ?";
  private String            findSpecificTestCasedetails =
      "SELECT  PROJECT_ID,tcname,tcqryone,tcqrytwo,description FROM TEST_CASES where tcname=?";
  private String            findDataSourceDtls          =
      "SELECT dsid,dsname,active,dsType,DBUSERNAME,DBPASSWORD,hostname,port,service,servicetype FROM DATA_SOURCES where dsid = ?";

  private String            checkTestCaseName           =
      "select count(tcname) tccount from TEST_CASES where PROJECT_ID =? and tcname in (?)";
  private String            deleteTestCasesFrPrj        =
      "Delete from TEST_CASES  where PROJECT_ID=?";
  private String            maxValCaseFrPrj           =
      "select IFNULL(MAX(tcname), 0) tccount from TEST_CASES where PROJECT_ID =? ";
  
  private String            deleteAllTestCase           =
      "Delete from TEST_CASES" + " where " + " PROJECT_ID = ? ";

  /**
   * {@inheritDoc}
   */
  public List<Dropdown> findAllDataSources() {
    final RowMapper<Dropdown> mapper = new DropdownRowMapper();

    @SuppressWarnings("unchecked")
    List<Dropdown> result = (List<Dropdown>) jdbcTemplate.query(findDataSource, mapper);
    return result;
  }

  /**
   * Row Mapper for Object Types
   */
  public static class DropdownRowMapper implements RowMapper<Dropdown> {
    public Dropdown mapRow(ResultSet rs, int rowNum) throws SQLException {
      Dropdown dropdown = new Dropdown();
      dropdown.setKey(rs.getInt("dsid"));
      dropdown.setVal(rs.getString("dsname"));
      dropdown.setChecked(rs.getBoolean("active"));
      dropdown.setDsType(rs.getString("dsType"));
      dropdown.setDsHost(rs.getString("hostname"));
      dropdown.setDsPort(rs.getString("port"));
      dropdown.setDsService(rs.getString("service"));
      dropdown.setDsServiceType(rs.getString("servicetype"));
      dropdown.setDsUserName(rs.getString("DBUSERNAME"));
      dropdown.setDsPassword(rs.getString("DBPASSWORD"));
      return dropdown;
    }
  }

  @Override
  public List<TestCasesVO> findAllTestCaseDtls(String projectid) {
    final RowMapper<TestCasesVO> mapper = new TestCasesRowMapper();

    @SuppressWarnings("unchecked")
    List<TestCasesVO> result = (List<TestCasesVO>) jdbcTemplate.query(findTstCasesFrProj,
        new Object[] {projectid}, mapper);
    return result;
  }

  @Override
  public List<TestCasesVO> findSpecificTestCasedetails(String testcaseid) {
    final RowMapper<TestCasesVO> mapper = new SpecificTestCasesRowMapper();

    @SuppressWarnings("unchecked")
    List<TestCasesVO> result = (List<TestCasesVO>) jdbcTemplate.query(findSpecificTestCasedetails,
        new Object[] {testcaseid}, mapper);
    return result;
  }

  public static class SpecificTestCasesRowMapper implements RowMapper<TestCasesVO> {
    public TestCasesVO mapRow(ResultSet rs, int rowNum) throws SQLException {
      TestCasesVO testCase = new TestCasesVO();
      // SELECT tcid, tcname,tcqryone,tcqrytwo,tcdsone,tcdstwo,active FROM TEST_CASES
      testCase.setProjectId(rs.getInt(1));
      testCase.setTestCaseName(rs.getString(2));
      testCase.setTestQryOne(rs.getString(3));
      testCase.setTestQryTwo(rs.getString(4));
      testCase.setDescription(rs.getString(5));
      return testCase;
    }
  }



  /**
   * Row Mapper for Object Types
   */
  public static class TestCasesRowMapper implements RowMapper<TestCasesVO> {
    public TestCasesVO mapRow(ResultSet rs, int rowNum) throws SQLException {
     
      TestCasesVO testCase = new TestCasesVO();
      String testCaseName = rs.getString(1);
      testCase.setTestCaseName(testCaseName == null ? "0" : testCaseName);
      testCase.setTestQryOne(rs.getString(2));
      testCase.setTestQryTwo(rs.getString(3));

      testCase.setProjectId(Integer.parseInt(rs.getString(4)));
      testCase.setProjectName(rs.getString(5));
      testCase.setDescription(rs.getString(6));
      testCase.setTestCaseCode((testCase.getProjectName().substring(0,2)+testCase.getProjectName().substring(testCase.getProjectName().length()-2, testCase.getProjectName().length())).toUpperCase()+"_"+String.format("%03d" , Integer.parseInt(testCase.getTestCaseName())));
      testCase.setTestExecFlag(false);
      testCase.setEditTestCase(true);
      return testCase;
    }
  }

  @Override
  public List<TestCasesVO> compareQueries(List<TestCasesVO> lstTestCaseVo) throws SQLException {

    List<TestCasesVO> listTestCases = new ArrayList<TestCasesVO>();
    for (TestCasesVO testCases : lstTestCaseVo) {
      if (testCases.isTestExecFlag()) {
        listTestCases.add(compareTestQuery(testCases));
      }
      else {
        testCases.setTestResultFlag("");
        testCases.setTestResultStats("");
        listTestCases.add(testCases);
      }

    }
    return listTestCases;
  }

  public PwiReportResultRowMetaData executeQuery(String query, String dsn, String id)
      throws SQLException, ClassNotFoundException {

    String dbUrl = "";
    PwiReportResultRowMetaData reportResultRowMetaData = new PwiReportResultRowMetaData();
    List<HashMap<String, String>> rowMaps = new ArrayList<HashMap<String, String>>();
    List<PwiReportResultRow> resultRows = new ArrayList<PwiReportResultRow>();
    List<PWiResultSetColMetaData> PWirscmdLst = new ArrayList<PWiResultSetColMetaData>();
    // final RowMapper<DataSourceData> mapper = new DSRowMapper();
    @SuppressWarnings("unchecked")
    DataSourceData result = (DataSourceData) jdbcTemplate.queryForObject(findDataSourceDtls,
        new Object[] {dsn}, new DSRowMapper());


    /*
     * switch(result.getDsType()){ case "oracle" :
     * Class.forName("oracle.jdbc.driver.OracleDriver");break; case "mysql" :
     * Class.forName("com.mysql.jdbc.Driver");break; case "teradata" :
     * Class.forName("com.teradata.jdbc.TeraDriver");break; case "postgresql" :
     * Class.forName("org.postgresql.Driver");break; case "sqllite" :
     * Class.forName("org.sqlite.JDBC");break; case "sqlserver" :
     * Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");break; default:
     * Class.forName("oracle.jdbc.driver.OracleDriver");break; }
     * 
     * Connection con=DriverManager.getConnection(
     * result.getDsUrl(),result.getDBUSERNAME(),result.getDsPassword());
     */
    Connection con = null;
    switch (result.getDsType().toLowerCase()) {
      case "oracle":
        Class.forName("oracle.jdbc.driver.OracleDriver");
        if (result.getDsServiceType().equals("SID")) {
          dbUrl = dbUrl + "jdbc:oracle:thin:@" + result.getDsHost() + ":" + result.getDsPort() + ":"
              + result.getDsService();
        }
        else {
          dbUrl = dbUrl + "jdbc:oracle:thin://@" + result.getDsHost() + ":" + result.getDsPort()
              + "/" + result.getDsService();
        } ;
        break;
      case "mysql":
        Class.forName("com.mysql.jdbc.Driver");
        break;
      case "teradata":
        Class.forName("com.teradata.jdbc.TeraDriver");
        dbUrl = dbUrl + "jdbc:teradata://" + result.getDsHost();
        if (result.getDsPort() != null && !result.getDsPort().equals("")) {
          dbUrl = dbUrl + ":" + result.getDsPort();
        }
        break;
      case "postgresql":
        Class.forName("org.postgresql.Driver");
        break;
      case "sqllite":
        Class.forName("org.sqlite.JDBC");
        break;
      case "sqlserver":
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dbUrl = dbUrl + "jdbc:sqlserver://" + result.getDsHost();
        if (result.getDsPort() != null && result.getDsPort() != null) {
          dbUrl = dbUrl + ":" + result.getDsPort() + ";";
        }
        if (result.getDsService() != null && !result.getDsService().equals("")) {
          dbUrl = dbUrl + ";databaseName=" + result.getDsService() + ";";
        }
        break;
      default:
        Class.forName("oracle.jdbc.driver.OracleDriver");
        break;
    }

    con = DriverManager.getConnection(dbUrl, result.getDsUserName(), result.getDsPassword());

    // here sonoo is database name, root is username and password
    Statement stmt = con.createStatement();
    ResultSet rs = stmt.executeQuery(query);
    ResultSetMetaData metaData = rs.getMetaData();
    int columnCount = metaData.getColumnCount();

    // PwiReportResultRowMetaData reportResultRowMetaData = null;
    /*
     * reportResultRowMetaData = pwiDatabaseTemplate .getDatasourceTemplate(dsn).query( query, new
     * ResultSetExtractor<PwiReportResultRowMetaData>() {
     * 
     * @Override public PwiReportResultRowMetaData extractData( ResultSet rs) throws SQLException,
     * DataAccessException { PwiReportResultRowMetaData reportResultRowMetaData = new
     * PwiReportResultRowMetaData(); List<HashMap<String,String>> rowMaps = new
     * ArrayList<HashMap<String,String>>(); List<PwiReportResultRow> resultRows = new
     * ArrayList<PwiReportResultRow>(); List<PWiResultSetColMetaData> PWirscmdLst = new
     * ArrayList<PWiResultSetColMetaData>(); ResultSetMetaData metaData = rs.getMetaData(); int
     * columnCount = metaData.getColumnCount();
     */

    while (rs.next()) {
      int rowNum = 0;
      HashMap<String, String> rowMap = new HashMap<String, String>();
      ArrayList<String> rowVals = new ArrayList<String>();

      for (int i = 1; i <= columnCount; i++) {

        Object value = rs.getObject(i);
        // rowMap.put(metaData.getColumnName(i), String.valueOf(value));
        rowMap.put(i + "", String.valueOf(value));
        rowVals.add(String.valueOf(value));
      }
      rowMaps.add(rowMap);
      resultRows.add(new PwiReportResultRow(rowNum, rowVals));
    }
    HashMap<String, Integer> ht1 = new HashMap<String, Integer>();
    HashMap<Integer, PWiResultSetColMetaData> ht2 = new HashMap<Integer, PWiResultSetColMetaData>();
    if (rowMaps != null && rowMaps.size() > 0) {
      for (int i = 1; i <= rowMaps.get(0).size(); ++i) {
        PWiResultSetColMetaData PWirscmd = new PWiResultSetColMetaData();
        PWirscmd.colindex = i;
        PWirscmd.colname = metaData.getColumnName(i);
        PWirscmd.coltype = metaData.getColumnType(i);

        PWirscmdLst.add(PWirscmd);
        ht2.put(Integer.valueOf(i), PWirscmd);
        ht1.put(PWirscmd.colname, Integer.valueOf(i));
      }
    }
    reportResultRowMetaData.setMetaData(PWirscmdLst);
    reportResultRowMetaData.setData(ht1, ht2, rowMaps);
    reportResultRowMetaData.setResultRows(resultRows);
    // return reportResultRowMetaData;
    // }
    // });
    reportResultRowMetaData.setExecutedQry(query);
    // reportResultRowMetaData.setParams(pwiPlaceholderData.getParam());

    return reportResultRowMetaData;
  }

  @Override
  public int saveSelectedCases(TestCasesVO testExecVo) {


    int counter = 0;
    counter = counter + saveTestCase(testExecVo);

    System.out.println(counter);
    // testExecVo.setListTestCases(listTestCases);
    return counter;
  }

  public int saveTestCase(TestCasesVO testCases) {

    // (tcid,userId,tcname,tcqryone,tcqrytwo,tcdsone,tcdstwo,active)
    if (testCases.getTestCaseName() != null && !testCases.getTestCaseName().equals("")) {

      return jdbcTemplate.update(updateTestCase,
          new Object[] {testCases.getDescription(),testCases.getTestQryOne(), testCases.getTestQryTwo(),testCases.getTestCaseName(),testCases.getProjectId()});
    }
    else {


      return jdbcTemplate.update(insertTestCase,
          new Object[] {testCases.getProjectId(), testCases.getTestCaseName(),
              testCases.getDescription(), testCases.getTestQryOne(), testCases.getTestQryTwo()});
    }
  }

  public static class allprojectnamemapper implements RowMapper<ProjectVO> {
    public ProjectVO mapRow(ResultSet rs, int rowNum) throws SQLException {
      ProjectVO projectVO = new ProjectVO();
      // SELECT tcid, tcname,tcqryone,tcqrytwo,tcdsone,tcdstwo,active FROM TEST_CASES
      List<String> list = new ArrayList<>();
      while (rs.next()) {
        list.add(rs.getString("PROJECT_NAME"));

      }

      projectVO.setAllprojectnames(list);
      return projectVO;
    }
  }


  @Override
  public List<TreeMenuVO> getUserProjects(int userId) {

    final RowMapper<ProjectVO> mapper = new ProjectRowMapper();
    List<TreeMenuVO> lstProjfinal = new ArrayList<TreeMenuVO>();
    List<ProjectVO> lstProj = jdbcTemplate.query(findProjForUsers, mapper);
    for (ProjectVO prj : lstProj) {
      final RowMapper<TreeMenuVO> csmapper = new ChildrenRowMapper();

      TreeMenuVO treeVo = new TreeMenuVO();
      treeVo.setId(prj.getProjectId() + "");
      treeVo.setLabel(prj.getProjectName());
      @SuppressWarnings("unchecked")
      List<TreeMenuVO> result = (List<TreeMenuVO>) jdbcTemplate.query(findTstCasesFrProj,
          new Object[] {treeVo.getId()}, csmapper);
      treeVo.setChildren(result);
      // prj.setLstCases(result);
      lstProjfinal.add(treeVo);
    }
    return lstProjfinal;

  }

  public class ProjectRowMapper implements RowMapper {
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      ProjectVO proj = new ProjectVO();
      // SELECT tcid, tcname,tcqryone,tcqrytwo,tcdsone,tcdstwo,active FROM TEST_CASES
      proj.setProjectId(rs.getInt(1));
      proj.setProjectName(rs.getString(2));
      return proj;
    }

  }

  public static class ChildrenRowMapper implements RowMapper<TreeMenuVO> {
    public TreeMenuVO mapRow(ResultSet rs, int rowNum) throws SQLException {
      TreeMenuVO testCase = new TreeMenuVO();
      // SELECT tcid, tcname,tcqryone,tcqrytwo,tcdsone,tcdstwo,active FROM TEST_CASES
      testCase.setId(rs.getString(1));
      testCase.setLabel(rs.getString(2));
      return testCase;
    }
  }

  @Override
  public int saveNewPrj(String projectname, String projectdesc, String projectowner) {
    Statement stmt = null;
    ResultSet rs = null;
    // final RowMapper<ProjectVO> mapper = new allprojectnamemapper();
    try {
      Connection conn = null;
      String url = "jdbc:sqlite:ValidaXDB.db";
      conn = DriverManager.getConnection(url);
      stmt = conn.createStatement();
      rs = stmt.executeQuery(findallprojectname);
      List<String> prjnames = new ArrayList<String>();
      while (rs.next()) {
        prjnames.add(rs.getString(1));
      }

      if (prjnames.contains(projectname))
        return 999;
      rs.close();
      stmt.close();
    }
    catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    finally {

    }
    /*
     * @SuppressWarnings("unchecked") List<ProjectVO> result = (List<ProjectVO>) jdbcTemplate
     * .query(findallprojectname,mapper); List<String> prjnames = new ArrayList<String>();
     * for(ProjectVO prj: result) { prjnames.addAll(prj.getAllprojectnames()); }
     */
    /*
     * if(prjnames.contains(projectname)) { return 999; }
     */
    return jdbcTemplate.update(insertNewProject,
        new Object[] {projectname});
    // TODO Auto-generated method stub

  }

  @Override
  public int addTestCase(TestCasesVO testCaseVo) {
    // TODO Auto-generated method stub

    Statement stmt = null;
    ResultSet rs = null;
    // final RowMapper<ProjectVO> mapper = new allprojectnamemapper();
    try {
      Connection conn = null;
      String url = "jdbc:sqlite:ValidaXDB.db";
      conn = DriverManager.getConnection(url);
      stmt = conn.createStatement();
      rs = stmt.executeQuery(
          "select tcname from TEST_CASES where PROJECT_ID =" + testCaseVo.getProjectId());
      List<String> prjnames = new ArrayList<String>();
      while (rs.next()) {
        prjnames.add(rs.getString(1));
      }

      if (prjnames.contains(testCaseVo.getTestCaseName()))
        return 999;
      rs.close();
      stmt.close();
    }
    catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    finally {

    }


    return jdbcTemplate.update(insertNewTestCase,
        new Object[] {testCaseVo.getProjectId(), testCaseVo.getTestCaseName(),
            testCaseVo.getDescription(), testCaseVo.getTestQryOne(), testCaseVo.getTestQryTwo()});
  }

  @Override
  public int deleteTestCase(TestCasesVO testExecVo) {
    // TODO Auto-generated method stub
    return jdbcTemplate.update(deleteNewTestCase, new Object[] {testExecVo.getProjectId(),testExecVo.getTestCaseName()});
  }

  @Override
  public int saveDS(Dropdown dropdown) {

    System.out.println(dropdown.getDsHost());
    // TODO Auto-generated method stub
    Statement stmt = null;
    ResultSet rs = null;
    ResultSet rs2 = null;
    // final RowMapper<ProjectVO> mapper = new allprojectnamemapper();
    /*
     * try { Connection conn = null; String url = "jdbc:sqlite:ValidaXDB.db"; conn =
     * DriverManager.getConnection(url); stmt = conn.createStatement(); rs =
     * stmt.executeQuery("select dsname from DATASOURCES "); List<String> prjnames = new
     * ArrayList<String>(); while (rs.next()) { prjnames.add(rs.getString(1)); }
     * 
     * if(prjnames.contains(dropdown.getVal())) return 999; rs.close(); stmt.close(); } catch
     * (SQLException e) { // TODO Auto-generated catch block e.printStackTrace(); } finally {
     * 
     * }
     */
    if (dropdown.getKey() == 0) {
      try {
        Connection conn = null;
        String url = "jdbc:sqlite:ValidaXDB.db";
        conn = DriverManager.getConnection(url);
        stmt = conn.createStatement();
        rs = stmt.executeQuery("select dsname from DATA_SOURCES ");
        List<String> prjnames = new ArrayList<String>();
        while (rs.next()) {
          prjnames.add(rs.getString(1));
        }

        if (prjnames.contains(dropdown.getVal()))
          return 999;
        rs.close();
        stmt.close();
      }
      catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
      finally {

      }
      System.out.println(dropdown.getKey());
      System.out.println(dropdown.getVal());
      return jdbcTemplate.update(addDataSource,
          new Object[] {dropdown.getVal(), dropdown.getDsType(), dropdown.getDsHost(),
              dropdown.getDsPort(), dropdown.getDsService(), dropdown.getDsServiceType(),
              dropdown.getDsUserName(), dropdown.getDsPassword()});
    }
    else {
      try {
        Connection conn = null;
        String url = "jdbc:sqlite:ValidaXDB.db";
        conn = DriverManager.getConnection(url);
        stmt = conn.createStatement();
        rs2 = stmt.executeQuery("select dsname from DATA_SOURCES where dsid=" + dropdown.getKey());
        String dname = rs2.getString(1);
        rs = stmt.executeQuery("select dsname from DATA_SOURCES where dsname!=" + "'" + dname + "'");
        List<String> prjnames = new ArrayList<String>();
        while (rs.next()) {
          prjnames.add(rs.getString(1));
        }

        if (prjnames.contains(dropdown.getVal()))
          return 999;
        rs.close();
        stmt.close();
      }
      catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
      finally {

      }



      return jdbcTemplate.update(updateDataSource,
          new Object[] {dropdown.getVal(), dropdown.getDsType(), dropdown.getDsHost(),
              dropdown.getDsPort(), dropdown.getDsService(), dropdown.getDsServiceType(),
              dropdown.getDsUserName(), dropdown.getDsPassword(), dropdown.getKey()});
    }


  }


  /**
   * Row Mapper for Object Types
   */


  public class DSRowMapper implements RowMapper {
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      DataSourceData dsData = new DataSourceData();
      dsData.setDsid(rs.getInt("dsid"));
      dsData.setDsname(rs.getString("dsname"));
      dsData.setDsType(rs.getString("dsType"));
      // dsData.setDsUrl(rs.getString("dsUrl"));
      dsData.setDsUserName(rs.getString("DBUSERNAME"));
      dsData.setDsPassword(rs.getString("DBPASSWORD"));
      dsData.setActive(rs.getBoolean("active"));
      dsData.setDsHost(rs.getString("hostname"));
      dsData.setDsPort(rs.getString("port"));
      dsData.setDsService(rs.getString("service"));
      dsData.setDsServiceType(rs.getString("servicetype"));
      return dsData;
    }
  }

  @Override
  public int editTestCaseName(TestCasesVO testExecVo) {
    // TODO Auto-generated method stub

    Statement stmt = null;
    ResultSet rs = null;
    // final RowMapper<ProjectVO> mapper = new allprojectnamemapper();
    try {
      Connection conn = null;
      String url = "jdbc:sqlite:ValidaXDB.db";
      conn = DriverManager.getConnection(url);
      stmt = conn.createStatement();
      rs = stmt.executeQuery(
          "select tcname from TEST_CASES where PROJECT_ID =" + testExecVo.getProjectId());
      List<String> prjnames = new ArrayList<String>();
      while (rs.next()) {
        prjnames.add(rs.getString(1));
      }

      if (prjnames.contains(testExecVo.getTestCaseName()))
        return 999;
      rs.close();
      stmt.close();
    }
    catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    finally {

    }


    return jdbcTemplate.update(editTestCaseName,
        new Object[] {testExecVo.getTestCaseName(), testExecVo.getTestCaseId()});
  }

  @Override
  public int editPrjName(Project prj) {
    // TODO Auto-generated method stub

    Statement stmt = null;
    ResultSet rs = null;
    // final RowMapper<ProjectVO> mapper = new allprojectnamemapper();
    try {
      Connection conn = null;
      String url = "jdbc:sqlite:ValidaXDB.db";
      conn = DriverManager.getConnection(url);
      stmt = conn.createStatement();
      rs = stmt.executeQuery(findallprojectname);
      List<String> prjnames = new ArrayList<String>();
      while (rs.next()) {
        prjnames.add(rs.getString(1));
      }

      if (prjnames.contains(prj.getProjectname()))
        return 999;
      rs.close();
      stmt.close();
    }
    catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    finally {

    }

    return jdbcTemplate.update(editPrjName,
        new Object[] {prj.getProjectname(), prj.getProjectId()});
  }

  @Override
  public int deletePrj(Project prj) {
    // TODO Auto-generated method stub
    return jdbcTemplate.update(deletePrj, new Object[] {prj.getProjectId()});
  }

  @Override
  public int deleteDB(DataSourceData data) {
    // TODO Auto-generated method stub
    return jdbcTemplate.update(deletedb, new Object[] {data.getDsid()});
  }

  @Override
  public int testDS(Dropdown dropdown) {
    int valid = 0;
    Connection con = null;
    try {

      String dbUrl = "";

      switch (dropdown.getDsType().toLowerCase()) {
        case "oracle":
          Class.forName("oracle.jdbc.driver.OracleDriver");
          if (dropdown.getDsServiceType() != null) {
            if (dropdown.getDsServiceType().equals("SID")) {
              dbUrl = dbUrl + "jdbc:oracle:thin:@" + dropdown.getDsHost() + ":"
                  + dropdown.getDsPort() + ":" + dropdown.getDsService();
            }
            else {
              dbUrl = dbUrl + "jdbc:oracle:thin://@" + dropdown.getDsHost() + ":"
                  + dropdown.getDsPort() + "/" + dropdown.getDsService();
            }
          }
          break;
        case "mysql":
          Class.forName("com.mysql.jdbc.Driver");
          break;
        case "teradata":
          Class.forName("com.teradata.jdbc.TeraDriver");
          dbUrl = dbUrl + "jdbc:teradata://" + dropdown.getDsHost();
          if (dropdown.getDsPort() != null && dropdown.getDsPort() != "") {
            dbUrl = dbUrl + ":" + dropdown.getDsPort();
          }
          break;
        case "postgresql":
          Class.forName("org.postgresql.Driver");
          break;
        case "sqllite":
          Class.forName("org.sqlite.JDBC");
          break;
        case "sqlserver":
          Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
          dbUrl = dbUrl + "jdbc:sqlserver://" + dropdown.getDsHost();
          if (dropdown.getDsPort() != null) {
            dbUrl = dbUrl + ":" + dropdown.getDsPort() + ";";
          }
          if (dropdown.getDsService() != null) {
            dbUrl = dbUrl + ";databaseName=" + dropdown.getDsService() + ";";
          }
          break;
        default:
          Class.forName("oracle.jdbc.driver.OracleDriver");
          break;
      }

      con = DriverManager.getConnection(dbUrl, dropdown.getDsUserName(), dropdown.getDsPassword());
    }
   
    catch (Exception e) {
      valid = 999;
    }
    finally {
      try {
        if (con != null)
          con.close();
      }
      catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    return valid;
  }

  public TestCasesVO compareTestQuery(TestCasesVO testCases) {

    HashMap<String, List<String>> tempMapLeft = new HashMap<String, List<String>>();
    HashMap<String, List<String>> tempMapRight = new HashMap<String, List<String>>();
    ResultSetMapVo resultSetMapVoLft = new ResultSetMapVo();
    ResultSetMapVo resultSetMapVoRht = new ResultSetMapVo();

    try {
      System.out.println(testCases.getTestQryOne());
      System.out.println(testCases.getTestQryTwo());
      testCases.setTestExecFlag(true);

      testCases.setTestResultStats("");

      resultSetMapVoLft =   getExecuteQueryMap(testCases.getTestQryOne(), testCases.getTestDSOne(), null);
      
      if (resultSetMapVoLft.getErrorCode() != null) {

        testCases.setTestResultFlag("E");
        testCases.setTestResultStats(resultSetMapVoLft.getErrorCode());
        return testCases;
      }
      
      resultSetMapVoRht =  getExecuteQueryMap(testCases.getTestQryTwo(), testCases.getTestDSTwo(), null);

      if (resultSetMapVoRht.getErrorCode() != null) {

        testCases.setTestResultFlag("E");
        testCases.setTestResultStats(resultSetMapVoRht.getErrorCode());
        return testCases;
      }

      if (resultSetMapVoLft.getRowCounter() != resultSetMapVoRht.getRowCounter()) {
        testCases.setTestResultFlag("F");
        testCases.setTestResultStats("No. of columns are not matching.");
        return testCases;
      }

      int rowCounterInner = 0;
      int rowCounterOuter = 0;

      if (resultSetMapVoLft.getLstFinalDataBlock().size() == resultSetMapVoRht
          .getLstFinalDataBlock().size()) {
        for (ArrayList<String> rowValLeft : resultSetMapVoLft.getLstFinalDataBlock()) {
          for (ArrayList<String> rowValRight : resultSetMapVoRht.getLstFinalDataBlock()) {
            if (rowCounterOuter == rowCounterInner) {

              int count = resultSetMapVoLft.getRowCounter();
              boolean rowConflict = false;
              // List<String> columnListLft = new ArrayList<String>();
              // List<String> columnListRht = new ArrayList<String>();
              for (int i = 0; i < count; i++) {

                if (rowValLeft.get(i) != null && rowValRight.get(i) != null) {
                  if (!rowValLeft.get(i).toString().trim()
                      .equals(rowValRight.get(i).toString().trim())) {

                    rowConflict = true;

                  }
                }
                else {
                  rowConflict = true;
                }
              }

              if (rowConflict) {
                tempMapLeft.put(rowCounterInner + "", rowValLeft);
                tempMapRight.put(rowCounterInner + "", rowValRight);
              }
            }
            rowCounterInner++;
          }
          rowCounterOuter++;
        }
      }
      else {
        testCases.setTestResultStats("No. of records are not maching.");
      }
      testCases.setDiffColMapLft(tempMapLeft);
      testCases.setDiffColMapRht(tempMapRight);
      System.out.println(testCases.getDiffColMapLft());
      if (tempMapLeft.size() > 0 || tempMapRight.size() > 0
          || testCases.getTestResultStats().equalsIgnoreCase("No. of records are not maching.")) {

        testCases.setTestResultFlag("F");
        testCases.setTestResultStats("Value for columns are not maching ");

      }
      else {

        testCases.setTestResultFlag("P");
      }
    }
    catch (Exception e) {
      e.printStackTrace();
      testCases.setTestResultFlag("E");
      return testCases;
    }finally {
      
      resultSetMapVoLft=null;
      resultSetMapVoRht=null;
      tempMapLeft=null;
      tempMapRight=null;
    }
    return testCases;

  }

  public ResultSet getExecuteQuery(String query, String dsn, String id)
      throws ClassNotFoundException, SQLException {

    String dbUrl = "";
    Connection con = null;
    ResultSet rs = null;
    Statement stmt = null;
    // final RowMapper<DataSourceData> mapper = new DSRowMapper();
    try {

      @SuppressWarnings("unchecked")
      DataSourceData result = (DataSourceData) jdbcTemplate.queryForObject(findDataSourceDtls,
          new Object[] {dsn}, new DSRowMapper());

      switch (result.getDsType().toLowerCase()) {
        case "oracle":
          Class.forName("oracle.jdbc.driver.OracleDriver");
          if (result.getDsServiceType().equals("SID")) {
            dbUrl = dbUrl + "jdbc:oracle:thin:@" + result.getDsHost() + ":" + result.getDsPort()
                + ":" + result.getDsService();
          }
          else {
            dbUrl = dbUrl + "jdbc:oracle:thin://@" + result.getDsHost() + ":" + result.getDsPort()
                + "/" + result.getDsService();
          } ;
          break;
        case "mysql":
          Class.forName("com.mysql.jdbc.Driver");
          break;
        case "teradata":
          Class.forName("com.teradata.jdbc.TeraDriver");
          dbUrl = dbUrl + "jdbc:teradata://" + result.getDsHost();
          if (result.getDsPort() != null && !result.getDsPort().equals("")) {
            dbUrl = dbUrl + ":" + result.getDsPort();
          }
          break;
        case "postgresql":
          Class.forName("org.postgresql.Driver");
          break;
        case "sqllite":
          Class.forName("org.sqlite.JDBC");
          break;
        case "sqlserver":
          Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
          dbUrl = dbUrl + "jdbc:sqlserver://" + result.getDsHost();
          if (result.getDsPort() != null && !result.getDsPort().equals("")) {
            dbUrl = dbUrl + ":" + result.getDsPort() + ";";
          }
          if (result.getDsService() != null && !result.getDsService().equals("")) {
            dbUrl = dbUrl + ";databaseName=" + result.getDsService() + ";";
          }
          break;
        default:
          Class.forName("oracle.jdbc.driver.OracleDriver");
          break;
      }

      con = DriverManager.getConnection(dbUrl, result.getDsUserName(), result.getDsPassword());

      // here sonoo is database name, root is username and password
      stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
      rs = stmt.executeQuery(query);
    }
    catch (Exception e) {

      e.printStackTrace();
    }
    finally {

      try {
        if (con != null)
          con.close();
        stmt = null;
      }
      catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }

    }

    return rs;
  }

  public ResultSetMapVo getExecuteQueryMap(String query, String dsn, String id)
      throws ClassNotFoundException, SQLException {

    String dbUrl = "";
    Connection con = null;
    ResultSet rs = null;
    Statement stmt = null;
    ArrayList<ArrayList<String>> lstFinalDataBlock = new ArrayList<ArrayList<String>>();
    ResultSetMetaData resultSetMetaDataLeft = null;
    ResultSetMapVo resultMapVo = new ResultSetMapVo();
    ArrayList<String> lstDataRow = new ArrayList<String>();
    // final RowMapper<DataSourceData> mapper = new DSRowMapper();
    try {
      
      if(dsn.equals("") || query.startsWith("\"")) {
        
        lstDataRow = new ArrayList<String>();
        resultMapVo.setRowCounter(1);

          String value = query != null ? query.replace("\"", "") : "";
          lstDataRow.add(value);

        lstFinalDataBlock.add(lstDataRow);
        resultMapVo.setLstFinalDataBlock(lstFinalDataBlock);   
         
      }else {
        
        @SuppressWarnings("unchecked")
        DataSourceData result = (DataSourceData) jdbcTemplate.queryForObject(findDataSourceDtls,
            new Object[] {dsn}, new DSRowMapper());
  
        switch (result.getDsType().toLowerCase()) {
          case "oracle":
            Class.forName("oracle.jdbc.driver.OracleDriver");
            if (result.getDsServiceType().equals("SID")) {
              dbUrl = dbUrl + "jdbc:oracle:thin:@" + result.getDsHost() + ":" + result.getDsPort()
                  + ":" + result.getDsService();
            }
            else {
              dbUrl = dbUrl + "jdbc:oracle:thin://@" + result.getDsHost() + ":" + result.getDsPort()
                  + "/" + result.getDsService();
            } ;
            break;
          case "mysql":
            Class.forName("com.mysql.jdbc.Driver");
            break;
          case "teradata":
            Class.forName("com.teradata.jdbc.TeraDriver");
            dbUrl = dbUrl + "jdbc:teradata://" + result.getDsHost();
            if (result.getDsPort() != null && !result.getDsPort().equals("")) {
              dbUrl = dbUrl + ":" + result.getDsPort();
            }
            break;
          case "postgresql":
            Class.forName("org.postgresql.Driver");
            break;
          case "sqllite":
            Class.forName("org.sqlite.JDBC");
            break;
          case "sqlserver":
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            dbUrl = dbUrl + "jdbc:sqlserver://" + result.getDsHost();
            if (result.getDsPort() != null && !result.getDsPort().equals("")) {
              dbUrl = dbUrl + ":" + result.getDsPort() + ";";
            }
            if (result.getDsService() != null && !result.getDsService().equals("")) {
              dbUrl = dbUrl + ";databaseName=" + result.getDsService() + ";";
            }
            break;
          default:
            Class.forName("oracle.jdbc.driver.OracleDriver");
            break;
        }
  
        con = DriverManager.getConnection(dbUrl, result.getDsUserName(), result.getDsPassword());
  
        // here sonoo is database name, root is username and password
        stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        rs = stmt.executeQuery(query);
        int rowCounter = 0;
        while (rs.next()) {
          lstDataRow = new ArrayList<String>();
          if (rowCounter == 0) {
            resultSetMetaDataLeft = rs.getMetaData();
          }
  
          int columnCount = resultSetMetaDataLeft.getColumnCount();
          resultMapVo.setRowCounter(columnCount);
  
          for (int i = 1; i <= columnCount; ++i) {
  
            Object object = rs.getObject(i);
            String value = object != null ? object.toString().trim() : "";
            lstDataRow.add(value);
          }
          lstFinalDataBlock.add(lstDataRow);
        }
        resultMapVo.setLstFinalDataBlock(lstFinalDataBlock);        
      }

    }
    catch (Exception e) {


      System.out.println(e);


      resultMapVo.setErrorCode(e.getMessage());
    }
    finally {

      try {
        if (con != null)
          con.close();
        if (rs != null)
          rs.close();
        stmt = null;
      }
      catch (SQLException e) {
        // TODO Auto-generated catch block

        e.printStackTrace();
      }

    }

    return resultMapVo;
  }

  @Override
  public int writeExcel(TestCasesVO testCaseVo) throws SQLException {
    // TODO Auto-generated method stub
    /*
     * System.out.println(testCaseVo.getDiffColMapLft()); HashMap<String, List<String>> left =
     * testCaseVo.getDiffColMapLft();
     * 
     * HashMap<String, List<String>> right = testCaseVo.getDiffColMapRht(); //
     * List<ResultSetMetaData> Column_names=testCaseVo.getMetaDataList();
     * 
     * XSSFWorkbook workbook = new XSSFWorkbook(); XSSFSheet sheet =
     * workbook.createSheet("Source Query"); int cellmax = 0; int rownum = 0; Cell cell = null;
     * CellStyle style = workbook.createCellStyle();
     * style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
     * style.setFillPattern(CellStyle.SOLID_FOREGROUND); CellStyle style1 =
     * workbook.createCellStyle(); style1.setFillForegroundColor(IndexedColors.AQUA.getIndex());
     * style1.setFillPattern(CellStyle.SOLID_FOREGROUND); String name =
     * testCaseVo.getTestCaseName();
     * 
     * Row row = sheet.createRow(rownum); for(ResultSetMetaData r:Column_names) { int cellnum = 0;
     * int count=r.getColumnCount(); for(int i=0;i<=count;i++) { String col=r.getColumnName(i);
     * 
     * Cell cell = row.createCell(cellnum++); cell.setCellValue(col); } }
     * 
     * Set<String> keyset = left.keySet(); Row row1 = null; for (String key : keyset) { row1 =
     * sheet.createRow(rownum++);
     * 
     * 
     * List<String> objArrLft = left.get(key); List<String> objArrRht = right.get(key); int cellnum
     * = 0; for (Object obj : objArrLft) { cell = row1.createCell(cellnum++);
     * 
     * if (obj instanceof String) { cell.setCellValue((String) obj); cell.setCellStyle(style); }
     * else if (obj instanceof Integer) { cell.setCellValue((Integer) obj);
     * cell.setCellStyle(style); } cellmax++; } cellnum = cellmax + 3; for (Object obj : objArrRht)
     * { cell = row1.createCell(cellnum++);
     * 
     * if (obj instanceof String) { cell.setCellValue((String) obj); cell.setCellStyle(style1); }
     * else if (obj instanceof Integer) { cell.setCellValue((Integer) obj);
     * cell.setCellStyle(style1); } cellmax++; } cellmax = 0;
     * 
     * } // XSSFSheet sheet1 = workbook.createSheet("Destination"); rownum = 0;
     * 
     * try { // Write the workbook in file system FileOutputStream out = new FileOutputStream(new
     * File(name + ".xlsx")); workbook.write(out); out.close(); System.out.println(name +
     * ".xlsx written successfully on disk."); } catch (Exception e) { e.printStackTrace(); }
     */
    return 1;
  }

  @Override
  public int saveSelectedLstCases(int projectId, List<TestCasesVO> lstTestCases) {

    List<String> tstCaseLst = new ArrayList<String>();
    int[] lstVal = null;

    try {

      for (TestCasesVO testCasesVO : lstTestCases) {

        tstCaseLst.add(testCasesVO.getTestCaseName());
      }
      String strTstCase = PLMUtils.convertListToString(tstCaseLst);

      @SuppressWarnings("unchecked")
      int count = (int) jdbcTemplate.queryForObject(checkTestCaseName,
          new Object[] {projectId, strTstCase}, new CountRowMapper());

      if (count > 0)
        return 999;

      lstVal = jdbcTemplate.batchUpdate(insertNewTestCase, new BatchPreparedStatementSetter() {

        public void setValues(PreparedStatement ps, int i) throws SQLException {
          ps.setInt(1, projectId);
          ps.setString(2, lstTestCases.get(i).getTestCaseName());
          ps.setString(3, lstTestCases.get(i).getDescription());
          ps.setString(4, lstTestCases.get(i).getTestQryOne());
          ps.setString(5, lstTestCases.get(i).getTestQryTwo());
        }

        public int getBatchSize() {
          return lstTestCases.size();
        }

      });

    }
    catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    finally {

    }
    return lstVal.length;
  }

  public class CountRowMapper implements RowMapper {
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

      return rs.getInt("tccount");
    }
  }

  @Override
  public int deleteExistingRecordFrPrj(int projectId) {

    return jdbcTemplate.update(deleteTestCasesFrPrj, new Object[] {projectId});

  }

  @Override
  public int getMaxValcasefrPrj(int projectid) {

    int count = (int) jdbcTemplate.queryForObject(maxValCaseFrPrj,
        new Object[] {projectid}, new CountRowMapper());
    
    return count;
  }

  @Override
  public int deleteAllTestCases(List<TestCasesVO> lstTtestCaseVo) {
    
    List<String> lstTestCaseNm = new ArrayList<String>();
    String projectId = "";
    
    for(TestCasesVO caseVo : lstTtestCaseVo )
    {
      projectId = caseVo.getProjectId()+"";
      if(caseVo.isTestExecFlag()) {
        lstTestCaseNm.add(caseVo.getTestCaseName());
      }
    }
      
    String strListCases = PLMUtils.convertListToStr(lstTestCaseNm);
    
    // TODO Auto-generated method stub
    String deleteQry = deleteAllTestCase ;
    deleteQry = deleteQry + " AND  TCNAME in ( "+ strListCases +")";
    System.out.println("deleteQry--"+deleteQry);
    return jdbcTemplate.update(deleteQry, new Object[] {projectId});
  }

}
