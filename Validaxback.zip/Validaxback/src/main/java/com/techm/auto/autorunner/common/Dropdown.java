package com.techm.auto.autorunner.common;

/**
 * This class is used for dropdown data structure.
 * @author : 212321748
 * @version : 1.0 
 */

public class Dropdown {

	private int key;
	private String val;
	private boolean checked;
	private String dsType;
	private String dsUrl;
	private String dsUserName;
	private String dsPassword;
	private String dsHost;
	private String dsPort;
	private String dsService;	
	private String dsServiceType;
	
	
	public Dropdown(){}
	
	public String getDsType() {
		return dsType;
	}

	public void setDsType(String dsType) {
		this.dsType = dsType;
	}

	public String getDsUrl() {
		return dsUrl;
	}

	public void setDsUrl(String dsUrl) {
		this.dsUrl = dsUrl;
	}

	public String getDsUserName() {
		return dsUserName;
	}

	public void setDsUserName(String dsUserName) {
		this.dsUserName = dsUserName;
	}

	public String getDsPassword() {
		return dsPassword;
	}

	public void setDsPassword(String dsPassword) {
		this.dsPassword = dsPassword;
	}

	public Dropdown(int key, String val){
		this.key = key;
		this.val = val;
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public String getVal() {
		return val;
	}

	public void setVal(String val) {
		this.val = val;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getDsHost() {
		return dsHost;
	}

	public void setDsHost(String dsHost) {
		this.dsHost = dsHost;
	}

	public String getDsPort() {
		return dsPort;
	}

	public void setDsPort(String dsPort) {
		this.dsPort = dsPort;
	}

	public String getDsService() {
		return dsService;
	}

	public void setDsService(String dsService) {
		this.dsService = dsService;
	}

	public String getDsServiceType() {
		return dsServiceType;
	}

	public void setDsServiceType(String dsServiceType) {
		this.dsServiceType = dsServiceType;
	}
	
	
	
}
