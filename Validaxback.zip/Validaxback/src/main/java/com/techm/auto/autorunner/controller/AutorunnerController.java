package com.techm.auto.autorunner.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.aspectj.weaver.ast.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.techm.auto.autorunner.common.Dropdown;
import com.techm.auto.autorunner.common.PLMUtils;
import com.techm.auto.autorunner.data.DataSourceData;
import com.techm.auto.autorunner.service.AutorunnerService;
import com.techm.auto.autorunner.vo.Project;
import com.techm.auto.autorunner.vo.TestCasesVO;
import com.techm.auto.autorunner.vo.TestExecutionVO;
import com.techm.auto.autorunner.vo.TreeMenuVO;

@RestController
public class AutorunnerController {
    
    @Autowired
    private AutorunnerService autorunnerService;
    
    @RequestMapping(value="/getDataSources", method = RequestMethod.GET)
    public List<Dropdown> getDataSources() throws SQLException{
        
        return autorunnerService.findAllDataSources();
    }
    
    @RequestMapping(value="/getUserProjects", method = RequestMethod.GET)
    public List<TreeMenuVO> getUserProjects() throws SQLException{
        int userId = 1;
        return autorunnerService.getUserProjects(userId);
    }
    
    @RequestMapping(value="/getTestCaseDtls", method = RequestMethod.GET)
    public List<TestCasesVO> getTestCaseDtls(@RequestParam String projectid) throws SQLException{
        
        return autorunnerService.findAllTestCaseDtls(projectid);
    }
    @RequestMapping(value="/getSpecificTestCasedetails", method = RequestMethod.GET)
    public List<TestCasesVO> getSpecificTestCasedetails(@RequestParam String testcaseid) throws SQLException{
        
        return autorunnerService.findSpecificTestCasedetails(testcaseid);
    }
    
    
    @RequestMapping(value="/compareQueries", method = RequestMethod.POST)
   // public TestExecutionVO compareQueries(@RequestParam("listTestCases") List<TestCasesVO> lstTestCaseVo,@RequestParam("dbSourceId") String dbSourceId,@RequestParam("dbTargetId") String dbTargetId) throws SQLException{
    public List<TestCasesVO> compareQueries(@RequestBody  List<TestCasesVO> lstTestCaseVo) throws SQLException{
            
        return autorunnerService.compareQueries(lstTestCaseVo);
    }
    
    @RequestMapping(value="/saveNewPrj", method = RequestMethod.POST)
    public int saveNewPrj(@RequestBody Project prj) throws SQLException{
        int a=0;
        a=2;
        int counter= autorunnerService.saveNewPrj(prj.getProjectname(),prj.getProjectdesc(),prj.getProjectowner());
        return counter;
    }
    
    @RequestMapping(value="/compareQuery", method = RequestMethod.POST)
   // public TestCasesVO compareQueries(@RequestParam("testCaseVo") TestCasesVO testCaseVo,@RequestParam("dbSourceId") String dbSourceId,@RequestParam("dbTargetId") String dbTargetId) throws SQLException{
    public TestCasesVO compareQueries(@RequestBody TestCasesVO testCaseVo) throws SQLException{
      
        return autorunnerService.compareTestQuery(testCaseVo);
    }
    
    @RequestMapping(value="/saveSelectedCases", method = RequestMethod.POST)
    public int saveSelectedCases(@RequestBody TestCasesVO testExecVo) throws SQLException{
        
        int counter =  autorunnerService.saveSelectedCases(testExecVo);
       
        return counter;
    }
    @RequestMapping(value="/addTestCase", method = RequestMethod.POST)
    public int addTestCase(@RequestBody TestCasesVO testExecVo) throws SQLException{
        
        int counter =  autorunnerService.addTestCase(testExecVo);
      
        return counter;
    }
    
    @RequestMapping(value="/saveDS", method = RequestMethod.POST)
    public int saveDS(@RequestBody Dropdown dropdown) throws SQLException, ClassNotFoundException{
        
      int countConn =  autorunnerService.testDS(dropdown);
     
      int counter = 0;
      
        if (countConn == 0)
        {
          counter =  autorunnerService.saveDS(dropdown);
        }
        else{
          counter = 998;
        }
        return counter;
    }
    
    @RequestMapping(value="/deleteTestCase", method = RequestMethod.POST)
    public int deleteTestCase(@RequestBody TestCasesVO testExecVo) throws SQLException{
        
        int counter =  autorunnerService.deleteTestCase(testExecVo);
      
        return counter;
    }
    @RequestMapping(value="/editTestCaseName", method = RequestMethod.POST)
    public int editTestCaseName(@RequestBody TestCasesVO testExecVo) throws SQLException{
        
        int counter =  autorunnerService.editTestCaseName(testExecVo);
        /*if (counter >0)
        {
            testExecVo.setListTestCases(getTestCaseDtls());
        }*/
        return counter;
    }
    @RequestMapping(value="/editPrjName", method = RequestMethod.POST)
    public int editPrjName(@RequestBody Project prj) throws SQLException{
        
        int counter =  autorunnerService.editPrjName(prj);
        /*if (counter >0)
        {
            testExecVo.setListTestCases(getTestCaseDtls());
        }*/
        return counter;
    }
    @RequestMapping(value="/deletePrj", method = RequestMethod.POST)
    public int deletePrj(@RequestBody Project prj) throws SQLException{
        
        int counter =  autorunnerService.deletePrj(prj);
        /*if (counter >0)
        {
            testExecVo.setListTestCases(getTestCaseDtls());
        }*/
        return counter;
    }
    @RequestMapping(value="/deleteDB", method = RequestMethod.POST)
    public int deleteDB(@RequestBody DataSourceData data) throws SQLException{
        
        int counter =  autorunnerService.deleteDB(data);
        /*if (counter >0)
        {
            testExecVo.setListTestCases(getTestCaseDtls());
        }*/
        return counter;
    }
    @RequestMapping(value="/testDS", method = RequestMethod.POST)
    public int testDS(@RequestBody Dropdown dropdown) throws SQLException, ClassNotFoundException{
        
        int counter =  autorunnerService.testDS(dropdown);
        /*if (counter >0)
        {
            testExecVo.setListTestCases(getTestCaseDtls());
        }*/
        return counter;
    }
    
    @RequestMapping(value="/writeExcel", method = RequestMethod.POST)
    public int writeExcel(@RequestBody TestCasesVO testCaseVo) throws SQLException{
        
        return 0;//autorunnerService.writeExcel(testCaseVo);
    }
    
    @RequestMapping(value="/exportTestCases", method = RequestMethod.POST,produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    @ResponseBody
    public ResponseEntity<byte[]> writeExcelAll(@RequestBody List<TestCasesVO> testCaseVo,HttpServletRequest request, HttpServletResponse response)  throws MalformedURLException, FileNotFoundException {
        
      String downLoadFilePath = PLMUtils.exportTestCases(testCaseVo);
      File file = new File(downLoadFilePath);
      
        if (!file.exists()) { // handle FNF
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    
        try {
            FileSystemResource fileResource = new FileSystemResource(file);
    
            byte[] base64Bytes = Base64.encodeBase64(IOUtils.toByteArray(fileResource.getInputStream()));
    
            HttpHeaders headers = new HttpHeaders();
            headers.add("filename", fileResource.getFilename());
    
            return ResponseEntity.ok().headers(headers).body(base64Bytes);
        } catch (IOException e) {
            //log.error("Failed to download file ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    
    }
    
    
    @RequestMapping(value="/importTestCases", method = RequestMethod.POST)
    public void mapReapExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile,@RequestParam("projectid") int projectid,@RequestParam("optradio") boolean optradio) throws IOException {

       List<Test> tempStudentList = new ArrayList<Test>();
        XSSFWorkbook workbook = new XSSFWorkbook(reapExcelDataFile.getInputStream());
        XSSFSheet worksheet = workbook.getSheetAt(0);
        List<TestCasesVO> lstTestCases = new ArrayList<TestCasesVO>();
        
       int maxVal = autorunnerService.getMaxValcasefrPrj(projectid);
       int rowCount= 0;
       if(optradio) {
         maxVal =0;
       }
       
       Iterator rows = worksheet.rowIterator();

       while (rows.hasNext()) {
         
         
          TestCasesVO testCase = new TestCasesVO();

            XSSFRow row = (XSSFRow)rows.next();
            if(rowCount>0) {
            
            testCase.setTestCaseName(++maxVal+"");
            
            if(row.getCell(0).getCellType()==Cell.CELL_TYPE_NUMERIC)
            {
              testCase.setDescription(row.getCell(0).getNumericCellValue()+"");
            }else {
              testCase.setDescription(row.getCell(0).getStringCellValue());
            }
            
            if(row.getCell(1).getCellType()==Cell.CELL_TYPE_NUMERIC)
            {
              testCase.setTestQryOne(row.getCell(1).getNumericCellValue()+"");
            }else {
              testCase.setTestQryOne(row.getCell(1).getStringCellValue());
            }
            
            if(row.getCell(2).getCellType()==Cell.CELL_TYPE_NUMERIC)
            {
              testCase.setTestQryTwo(row.getCell(2).getNumericCellValue()+"");
            }else {
              testCase.setTestQryTwo(row.getCell(2).getStringCellValue());
            }
            
            testCase.setTestDSOne(1+"");
            testCase.setTestDSTwo(1+"");
                       
            lstTestCases.add(testCase);
         }
         
         rowCount++;
             
        }
        
        autorunnerService.saveSelectedLstCases(projectid,lstTestCases,optradio);
    }
    
    @RequestMapping(value = "/download", method = RequestMethod.GET,produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<byte[]> download(@RequestParam ("name") String name, final HttpServletRequest request, final HttpServletResponse response)  {
       

        File file = new File ("Test_Case_Template.xlsx");
        //File file = getReportFile(id); // a method that returns file for given ID
        if (!file.exists()) { // handle FNF
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }

        try {
            FileSystemResource fileResource = new FileSystemResource(file);

            byte[] base64Bytes = Base64.encodeBase64(IOUtils.toByteArray(fileResource.getInputStream()));

            HttpHeaders headers = new HttpHeaders();
            headers.add("filename", fileResource.getFilename());

            return ResponseEntity.ok().headers(headers).body(base64Bytes);
        } catch (IOException e) {
            //log.error("Failed to download file ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
        
        

    }
    
    @RequestMapping(value = "/download1", method = RequestMethod.GET)
    public ResponseEntity<InputStreamResource> download1(@RequestParam ("name") String name, final HttpServletRequest request, final HttpServletResponse response)  {
       

        File file = new File ("Test_Cases.xlsx");
        InputStreamResource resource = null;
        HttpHeaders headers = new HttpHeaders();
       
        try {
          
          resource = new InputStreamResource(new FileInputStream(file));

          
          headers.add("Content-Disposition", "attachment; filename=TestCaseTemplate.xlsx");
          headers.add("Content-Type", "application/octet-stream");
      
        } catch (IOException e) {
           e.printStackTrace();
        }
        
        return ResponseEntity.ok().headers(headers).body(resource);

    }
    
    @RequestMapping(value="/deleteAllTestCases", method = RequestMethod.POST)
    @ResponseBody
    public int deleteAllTestCases(@RequestBody List<TestCasesVO> lstTtestCaseVo)  throws MalformedURLException, FileNotFoundException {
        
      int counter =  autorunnerService.deleteAllTestCases(lstTtestCaseVo);
      
      return counter;
    
    }
    
}
