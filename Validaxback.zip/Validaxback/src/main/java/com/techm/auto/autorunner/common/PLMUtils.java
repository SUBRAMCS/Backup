/**
 * Copyright (C) 2014 GE Infra. All rights reserved
 * 
 * @FileName PLMUtils.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.techm.auto.autorunner.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.techm.auto.autorunner.vo.TestCasesVO;



public class PLMUtils {
  
  public static boolean isEmpty(String value) {
    boolean emptyFlag = false;
    String localVal = value;
    if (localVal != null) {
      localVal = localVal.trim();
    }
    if (localVal == null || localVal.equals("")) {
      emptyFlag = true;
    }
    return emptyFlag;
  }

  
  public static String chkNull(String strToCheck) {
    if ((null != strToCheck) && !strToCheck.equals("")) {
      return strToCheck;
    } else {
      return "";
    }
  }

 
  public static String checkNullVal(String val) {
    String value = val;

    if (value == null) {
      value = "";
    } else if (value.equalsIgnoreCase("null")) {
      value = "";
    }
    return value;
  }

  /**
   * @param val
   * @return
   */
  public static String appendHash(String val) {
    String value = null;
    value = val.replace(' ', '#');
    return value;
  }

  /**
   * @param val
   * @return
   */
  public static String removeHash(String val) {
    String value = "";
    value = val.replace('#', ' ');
    return value;
  }

  /**
   * @param val
   * @param ch
   * @return
   */
  public static String removeChar(String val, char ch) {
    StringBuilder value = new StringBuilder();
    for (int i = 0; i < val.length(); i++) {
      if (val.charAt(i) != ch) {
        value = value.append(val.charAt(i));
      }
    }
    return value.toString();
  }

 
  
  

  /**
   * @param sso
   * @return
   */
  public static String removeAsteriskAndSpaceFromSSOFields(String sso) {
    String ssoVal = sso;
    if (ssoVal.indexOf('*') != -1) {
      ssoVal = ssoVal.replace("*", "");
    }
    if (ssoVal.indexOf(' ') != -1) {
      ssoVal = ssoVal.replace(" ", "");
    }
    return ssoVal;
  }

 
  public static boolean setNewDropDownValue(int value) {
    if (value == 15 || value == 25 || value == 50 || value == 100 || value == 200) {
      return false;
    } else {
      return true;
    }
  }

  
  public static String getPropertyFromBundle(String key, String bundleName) {
    ResourceBundle rb = null;
    String value = null;
    try {
      rb = ResourceBundle.getBundle(bundleName);
      if (rb != null && !isEmpty(key)) {
        value = rb.getString(key);
      } else {
        value = "";
      }
    } catch (Exception e) {
     // LOG.info("Error raised in Catch Block", e);
    }
    return value;
  }

 
  public static String generateQueryWhereClauseWithEquals(String field_name, String field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    // Locale locale = Locale.getDefault();
    // whereClauseQry.append("UPPER(" + field_name + ") = ");
    whereClauseQry.append(field_name + " = ");
    whereClauseQry.append("'");
    // whereClauseQry.append(field_value.toUpperCase(locale));
    whereClauseQry.append(field_value);
    whereClauseQry.append("'");
    return whereClauseQry.toString();
  }

  /**
   * @param field_name
   * @param field_value
   * @return
   */
  public static String generateQueryWhereClauseForTaskSearch(String field_name, String field_value) {
    String wild_field_value = field_value.replace("*", "%");
    StringBuffer whereClauseQry = new StringBuffer();
    int index = wild_field_value.indexOf('%');
    if (index == -1) {
      whereClauseQry.append(field_name + " = ");
    } else {
      whereClauseQry.append(field_name + " LIKE ");
    }
    whereClauseQry.append("'");
    whereClauseQry.append(wild_field_value);
    whereClauseQry.append("'");
    return whereClauseQry.toString();
  }

  /**
   * This Method is used to generate WhereClause
   * 
   * @param field_name
   * @param whereClause_field_value
   * 
   * @return String
   */
  public static String generateQueryWhereClause(String field_name, String whereClause_field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    // Locale locale = Locale.getDefault();
    // String field_value = whereClause_field_value.replace("*", "%").toUpperCase(locale);
    String field_value = whereClause_field_value.replace("*", "%");
    if (field_value.indexOf(',') != -1) {
      // contains multiple search criteria
      String[] tokens = field_value.split(",");
      String field_tok = null;

      for (int i = 0; i < tokens.length; i++) {
        // whereClauseQry.append("UPPER(" + field_name + ") LIKE ");
        whereClauseQry.append(field_name + " LIKE ");
        field_tok = tokens[i].trim();
        if (field_tok != null && field_tok.lastIndexOf('*') != -1
            && field_tok.lastIndexOf('*') == field_tok.length() - 1) {
          field_tok = field_tok.substring(0, field_tok.length() - 1);
          //LOG.info("If loop Engg ID(contains multiple search criteria):" + field_tok);
        }
        //LOG.info("After SubString the Value of the Engg ID(contains multiple search criteria):"            + field_tok);

        whereClauseQry.append("'");
        whereClauseQry.append(field_tok);
        whereClauseQry.append("%' OR ");
       // LOG.info("whereClauseQry now is:::" + whereClauseQry + "::::");
      }
    } else if (field_value.lastIndexOf('*') != -1
        && (field_value.lastIndexOf('*') == field_value.length() - 1)) {
      whereClauseQry.append(field_name + " LIKE ");
      // simple search
      field_value = field_value.substring(0, field_value.length() - 1);
      //LOG.info("If loop Engg ID(simple search):" + field_value);

     // LOG.info("After SubString the Value of the Engg ID(simple search):" + field_value);

      whereClauseQry.append("'");
      whereClauseQry.append(field_value);
      whereClauseQry.append("%' OR ");
    } else {
      // whereClauseQry.append("UPPER(" + field_name + ") LIKE ");
      whereClauseQry.append(field_name + " LIKE ");
      whereClauseQry.append("'");
      whereClauseQry.append(field_value);
      whereClauseQry.append("%' OR ");
    }
    String query = whereClauseQry.toString();
    query = query.substring(0, query.length() - 4);
    whereClauseQry = new StringBuffer(query);

    return whereClauseQry.toString();
  }

  /**
   * @param strList
   * @return
   */
  public static String convertListToString(List<String> strList) {
    StringBuilder retValue = new StringBuilder();
    String retVal = "";
    if (!isEmptyList(strList)) {
      for (int i = 0; i < strList.size(); i++) {
        if (!isEmpty(strList.get(i))) {
          retValue.append(strList.get(i) + ",");
        }
      }
      if (!isEmpty(retValue.toString())) {
        retVal = retValue.substring(0, retValue.length() - 1);
      }
    }
    return retVal;
  }


  /**
   * @param str
   * @return
   */
  public static List<String> convertStringToList(String str) {
    List<String> strList = new ArrayList<String>();
    if (!isEmpty(str)) {
      StringTokenizer token = new StringTokenizer(str, ",");
      while (token.hasMoreElements()) {
        String value = token.nextToken();
        strList.add(value.trim());
      }
    }
    return strList;
  }

  /**
   * @param strList
   * @return
   */
  public static String setListForQuery(List<String> strList) {
    StringBuffer stMake = null;
    StringTokenizer stToken = null;
    String aText = null;

    if (strList != null) {
      for (int i = 0; i < strList.size(); i++) {
        if (aText != null) {
          aText = aText + strList.get(i) + ",";
          // Log.Info(" demandList " + i + " " + aText);
        } else {
          aText = strList.get(i) + ",";
          // Log.Info(" demandList " + i + " " + aText);
        }
      }
    }

    if (aText != null) {
      aText = aText.replace("'", "''");
      stToken = new StringTokenizer(aText, ",");

      while (stToken.hasMoreTokens()) {
        if (stMake == null) {
          stMake = new StringBuffer();
          stMake.append("'");// StringBuffer("'");
          stMake.append(stToken.nextToken());
          stMake.append("'");
          // Log.Info("::stMake - 1::" + stMake);
        } else {
          stMake.append(",");
          stMake.append("'").append(stToken.nextToken()).append("'");
          // Log.Info("::stMake - 2::" + stMake);
        }
      }
    }
    return stMake != null ? stMake.toString() : " ";
  }

  /**
   * @param strList
   * @return
   */
  public static String setListForEccnQuery(List<String> strList) {

    StringBuffer stMake = null;
    String aText = "";

    if (strList != null) {
      for (int i = 0; i < strList.size(); i++) {
        if (aText != null) {
          aText = aText + "\"" + strList.get(i) + "\"" + ",";
          // Log.Info(" demandList " + i + " " + aText);
				} /*
					 * else { aText = "\"" + strList.get(i) + "\"" + ","; // Log.Info(" demandList "
					 * + i + " " + aText); }
					 */
      }
    }

    // System.out.println("aText "+aText);
    aText = aText.replace("'", "''");

    String[] tokens = aText.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
    for (String t : tokens) {
      if (stMake == null) {
        stMake = new StringBuffer();
        stMake.append(t.replace("\"", "\'"));
      } else {

        stMake.append(",");
        stMake.append(t.replace("\"", "\'"));
      }
      // System.out.println("> " + t.replace("\"","\'"));
    }
    // System.out.println("St Make "+stMake);
    return stMake != null ? stMake.toString() : " ";
  }

  /**
   * @param strList
   * @param str
   * @return
   */
  public static String setListForQueryStrFnLn(List<String> strList, String str) {
    StringBuffer stMake = null;
    StringTokenizer stToken = null;
    String aText = null;
    if (strList != null) {
      for (int i = 0; i < strList.size(); i++) {
        if (aText != null) {
          aText = aText + strList.get(i) + ",";
        } else {
          aText = strList.get(i) + ",";
        }
      }
    }
    if (aText != null) {

      stToken = new StringTokenizer(aText, ",");

      while (stToken.hasMoreTokens()) {
        if (stMake == null) {
          stMake = new StringBuffer();
          stMake.append("'");
          stMake.append(stToken.nextToken());
          stMake.append("%'");

        } else {
          if (str.equals("firstName")) {
            stMake.append(" OR FIRST_NM LIKE ");
            stMake.append("'").append(stToken.nextToken()).append("%'");
          } else if (str.equals("lastName")) {
            stMake.append(" OR LAST_NM LIKE ");
            stMake.append("'").append(stToken.nextToken()).append("%'");
          }
        }
      }
    }
    return stMake != null ? stMake.toString() : null;
  }

 
  public static boolean isEmptyDate(Date dateVal) {
    boolean emptyFlag = false;
    if (dateVal == null) {
      emptyFlag = true;
    }
    return emptyFlag;
  }

  /**
   * @param from_Date
   * @param to_Date
   * @return
   */
  public static boolean checkForNullOfTwoDates(Date from_Date, Date to_Date) {
    boolean emptyFlag = false;
    if ((isEmptyDate(from_Date) && !isEmptyDate(to_Date))
        || (!isEmptyDate(from_Date) && isEmptyDate(to_Date))) {
      emptyFlag = true;
    }
    return emptyFlag;
  }

  /**
   * @param list
   * @return
   */
  public static boolean isEmptyList(List list) {
    boolean isEmpty = false;
    if (list == null || list.size() == 0) {
      isEmpty = true;
    }
    return isEmpty;
  }

  /**
   * @param Map
   * @return
   */
  public static boolean isEmptyMap(Map map) {
    boolean isEmpty = false;
    if (map == null || map.size() == 0) {
      isEmpty = true;
    }
    return isEmpty;
  }

  /**
   * @param strInputVal
   * @return
   */
  public static boolean checkForSpecialCharsInWhereUsed(String strInputVal) {

    String reqExpression = "[^~`@?;(){}''!\\\\\"\"$^]*";

    return Pattern.matches(reqExpression, strInputVal);

  }

  /**
   * @param strInputVal
   * @return
   */
  public static boolean checkForSpecialChars(String strInputVal) {

    String reqExpression = "[^~`#@?%;(){}''!\\\\\"\"$^*]*";

    return Pattern.matches(reqExpression, strInputVal);

  }

  /**
   * @param strInputVal
   * @return
   */
  public static boolean checkForSpecialCharsForTaskSearch(String strInputVal) {

    String reqExpression = "[^~`#@?%;(){}''!\\\\\"\"$^]*";

    return Pattern.matches(reqExpression, strInputVal);

  }

  /**
   * @param strInputVal
   * @return
   */
  public static boolean checkForSpecialCharsForAbitSearch(String strInputVal) {

    String reqExpression = "[^~`#@?%;(){}''!\\\\\"\"$^]*";

    return Pattern.matches(reqExpression, strInputVal);

  }

  /**
   * @param strInputVal
   * @return
   */
  public static boolean checkForSpecialCharsForInteger(String strInputVal) {

    String reqExpression = "[^[0-9]~`#@?%;(){}''!\\\\\"\"$^*]*";
    return Pattern.matches(reqExpression, strInputVal);

  }

  /**
   * @param inputFromDateVal
   * @param inputToDateVal
   * @return
   */
  public static boolean checkForFromAndToDate(Date inputFromDateVal, Date inputToDateVal) {
    boolean dateFlag = false;
    if (!isEmptyDate(inputFromDateVal) && !isEmptyDate(inputToDateVal)) {
      if (inputFromDateVal.after(inputToDateVal)) {
        dateFlag = inputFromDateVal.after(inputToDateVal);
      }
    }
    return dateFlag;
  }

  /**
   * @param type
   * @return
   */
  public static String getFormatedDate(String type) {
    String finalDate = "";
    Date curr = new Date();
    Calendar cal = Calendar.getInstance();
    cal.setTime(curr);
    int maxDay = 0;
    int maxYear = 0;
    Format formatter = new SimpleDateFormat("yyyy-MM-dd");

    if ("currDate".equals(type.trim())) {
      finalDate = formatter.format(curr);
    }
    if ("wstart".equals(type.trim())) {
      cal.add(Calendar.DAY_OF_YEAR, (cal.get(Calendar.DAY_OF_WEEK) * -1) + 1);
      finalDate = formatter.format(cal.getTime());
    }
    if ("wend".equals(type.trim())) {
      cal.add(Calendar.DAY_OF_YEAR, (cal.get(Calendar.DAY_OF_WEEK) * -1) + 7);
      finalDate = formatter.format(cal.getTime());
    }
    if ("mstart".equals(type.trim())) {
      cal.add(Calendar.DAY_OF_YEAR, (cal.get(Calendar.DAY_OF_MONTH) * -1) + 1);
      finalDate = formatter.format(cal.getTime());
    }
    if ("mend".equals(type.trim())) {
      maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
      cal.add(Calendar.DAY_OF_YEAR, (cal.get(Calendar.DAY_OF_MONTH) * -1) + maxDay);
      finalDate = formatter.format(cal.getTime());
    }
    if ("ystart".equals(type.trim())) {
      cal.add(Calendar.DAY_OF_YEAR, (cal.get(Calendar.DAY_OF_YEAR) * -1) + 1);
      finalDate = formatter.format(cal.getTime());
    }
    if ("yend".equals(type.trim())) {
      maxYear = cal.getActualMaximum(Calendar.DAY_OF_YEAR);
      cal.add(Calendar.DAY_OF_YEAR, (cal.get(Calendar.DAY_OF_YEAR) * -1) + maxYear);
      finalDate = formatter.format(cal.getTime());
    }

    return finalDate;
  }

 
  public static boolean isHtmlIndependent(String assetType) {
    Pattern mask = null;
    Matcher matcher = null;
    String checkValue = "[^<>]*";
    mask = Pattern.compile(checkValue);

    if (assetType != null) {
      matcher = mask.matcher(assetType);
      return matcher.matches();
    }
    return false;
  }

  /**
   * Checks whether a string is null or empty and returns boolean value
   * 
   * @param str
   * @return
   */
  public static boolean isNullOrEmpty(String str) {
    return (str == null) ? true : str.length() == 0;
  }

  /**
   * Read Property value from any properties file.
   * 
   * @param key String
   * @return String
   */
  public static String getMessage(String key, String propFile) {
    ResourceBundle rb = null;
    String value = null;
    try {
      rb = ResourceBundle.getBundle(propFile);
      if (rb != null && !isEmpty(key)) {
        value = rb.getString(key);
      } else {
        value = "";
      }
    } catch (Exception e) {
      value = "";
    }
    return value;
  }

  /**
   * Returns date as formatted string
   * 
   * @param dateVal
   * @return
   */
  public static Date getFormattedDate(String dateVal) {
    final SimpleDateFormat DATE_FORMAT_FROM_PROC = new SimpleDateFormat("dd-MMM-yyyy");
    Date toRet = null;
    try {
      if (!chkNull(dateVal).equals("")) {
        toRet = DATE_FORMAT_FROM_PROC.parse(dateVal);
      } else {
        toRet = null;
      }
    } catch (Exception e) {
      //LOG.log(Level.ERROR, "Error raised in Catch Block", e);
      toRet = null;
    }
    return toRet;
  }

  /**
   * Returns Current date and time as formatted string
   * 
   * 
   * @return String
   */

  public static String getCurrentDateTime() {
    String DATE_FORMAT_NOW = "ddMMMyyyy_HHmmss";
    Calendar cal = Calendar.getInstance();
    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
    return sdf.format(cal.getTime());

  }

  /**
   * Returns date as formatted string
   * 
   * @param dateVal
   * @return
   */
  public static String getFormatRelDate(Date dateVal) {
    final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("MM/dd/yyyy");
    if (dateVal != null) {
      return DATE_FORMAT_PROC.format(dateVal);
    } else {
      return null;
    }
  }


  /**
   * Returns date as formatted string
   * 
   * @param dateVal
   * @return
   */
  public static String getFormatDate(Date dateVal) {
    final SimpleDateFormat DATE_FORMAT_FROM_PROC = new SimpleDateFormat("dd-MMM-yyyy");
    if (dateVal != null) {
      return DATE_FORMAT_FROM_PROC.format(dateVal);
    } else {
      return null;
    }
  }

  /**
   * This method is used to check the length of the String
   * 
   * @param aName
   * @param aLength
   * @return
   */
  public static boolean checkLength(String aName, int aLength) {
    boolean exceedMaxLength = false;
    try {
      if (aName != null && aName.length() > aLength) {
        exceedMaxLength = true;
      }// end of if
    } catch (Exception ex) {
     // LOG.error("An exception has occurred here in checkLength", ex);
    }
    return exceedMaxLength;
  }

  
  public static boolean isEmptyForMultipleValues(String value) {
    boolean emptyFlag = false;
    String localVal = value;
    if (localVal != null) {
      localVal = localVal.trim();
    }
    if (localVal == null || localVal.equals("")) {
      emptyFlag = true;
    }
    if (localVal != null) {
      StringTokenizer valueToken = new StringTokenizer(localVal, ",");
      if (!valueToken.hasMoreElements()) {
        emptyFlag = true;
      }
    }
    return emptyFlag;
  }

  /**
   * @param field_name
   * @param field_value
   * @return
   */
  public static String generateQueryForMultipleNames(String field_name, String field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    boolean whereFlag = false;
    List<String> fieldValueInList = new ArrayList<String>();
    List<String> fieldValueLikeList = new ArrayList<String>();

    StringTokenizer token = new StringTokenizer(field_value, ",");
    List<String> fieldValueList = new ArrayList<String>();
    while (token.hasMoreElements()) {
      String arrayValue = token.nextToken();
      fieldValueList.add(arrayValue.trim());
    }
    if (!PLMUtils.isEmptyList(fieldValueList)) {
      for (int i = 0; i < fieldValueList.size(); i++) {
        String arrayValue = fieldValueList.get(i);
        if (arrayValue.indexOf('*') != -1) {
          arrayValue = arrayValue.replace("*", "%");
          fieldValueLikeList.add(arrayValue);
        } else {
          fieldValueInList.add(arrayValue);
        }
      }
    }

    if (!PLMUtils.isEmptyList(fieldValueInList)) {
      whereClauseQry
          .append(field_name + " IN (" + PLMUtils.setListForQuery(fieldValueInList) + ")");
      whereFlag = true;
    }

    if (!PLMUtils.isEmptyList(fieldValueLikeList)) {
      if (whereFlag) {
        whereClauseQry.append(" OR ");
      }
      for (int i = 0; i < fieldValueLikeList.size(); i++) {
        String likeValue = fieldValueLikeList.get(i);
        whereClauseQry.append(field_name + " LIKE '" + likeValue + "'");
        if (i < fieldValueLikeList.size() - 1) {
          whereClauseQry.append(" OR ");
        }
      }
    }
    return whereClauseQry.toString();
  }

 
  public static String getChildString(List<String> childList) {
    String temp = null;
    StringBuffer rsString = new StringBuffer();
    int iCount = 0;
    if (childList != null && childList.size() > 0) {
      rsString.append("'");
      for (iCount = 0; iCount < childList.size(); iCount++) {
        temp = childList.get(iCount);
        rsString.append(temp + "','");
      }
    }
    if (rsString.lastIndexOf(",") >= 0) {
      temp = rsString.toString().substring(0, rsString.toString().lastIndexOf(','));
    }
    if (temp == null) {
      temp = "''";
    }
    return temp;
  }

  /**
   * @param childList
   * @return
   */
  public static String getChildStringFilter(List<String> childList) {
    String temp = null;
    StringBuffer rsString = new StringBuffer();
    int iCount = 0;
    if (childList != null && childList.size() > 0) {
      rsString.append("");
      for (iCount = 0; iCount < childList.size(); iCount++) {
        temp = childList.get(iCount);
        rsString.append(temp + "");
      }
    }
    if (rsString.lastIndexOf(",") >= 0) {
      temp = rsString.toString().substring(0, rsString.toString().lastIndexOf(','));
    }
    if (temp == null) {
      temp = "''";
    }
    return temp;
  }

  /**
   * This method is used for generating zip file
   * 
   * @return void
   */
  public static void generateZipFile(String filePathXls, String filePathZip) throws IOException {
   // LOG.info("Entering generateZipFile method");
    FileOutputStream fileOut = null;
    BufferedOutputStream bufferOut = null;
    ZipOutputStream zipOut = null;
    // BufferedInputStream bufferIn = null;
    FileInputStream fileIn = null;
    File xlsFile = new File(filePathXls);
    try {
      fileOut = new FileOutputStream(filePathZip);
      bufferOut = new BufferedOutputStream(fileOut);
      zipOut = new ZipOutputStream(bufferOut);
      fileIn = new FileInputStream(filePathXls);
      // bufferIn = new BufferedInputStream(fileIn);
      int count;
      byte[] data = new byte[1000];
      zipOut.putNextEntry(new ZipEntry(xlsFile.getName()));
      while ((count = fileIn.read(data, 0, 1000)) != -1) {
        zipOut.write(data, 0, count);
      }
      // bufferIn.close();
      zipOut.flush();
      zipOut.close();
    } catch (FileNotFoundException e) {
    //  LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
      throw e;
    } catch (IOException e) {
      //LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
      throw e;
    } finally {
      try {
        if (fileIn != null) {
          fileIn.close();
        }
        if (bufferOut != null) {
          bufferOut.close();
        }
      } catch (IOException e) {
       // LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
        throw e;
      } finally {
        if (zipOut != null) {
          zipOut.close();
        }
        if (fileOut != null) {
          fileOut.close();
        }
      }
    }
   // LOG.info("Exiting generateZipFile Method");
  }

  /**
   * This method is used for generating zip file
   * 
   * @return void
   */
  /*
   * public static void generateZipFile(List<String> filePathXlsLst,String filePathZip) throws
   * IOException { LOG.info("Entering generateZipFile method"); FileOutputStream fileOut = null;
   * BufferedOutputStream bufferOut = null; ZipOutputStream zipOut = null; BufferedInputStream
   * bufferIn = null; FileInputStream fileIn = null; String filePathXls = null; try {
   * LOG.info("filePathZip >> " + filePathZip); fileOut = new FileOutputStream(filePathZip);
   * bufferOut = new BufferedOutputStream(fileOut); zipOut = new ZipOutputStream(bufferOut);
   * 
   * for (int i = 0; i < filePathXlsLst.size(); i++) { try{ filePathXls =
   * filePathXlsLst.get(i).toString(); File xlsFile = new File(filePathXls);
   * //LOG.info("filePathXls in loop >> " + filePathXls); fileIn = new FileInputStream(filePathXls);
   * bufferIn = new BufferedInputStream(fileIn); int count; byte[] data = new byte[1000];
   * zipOut.putNextEntry(new ZipEntry(xlsFile.getName())); while((count = fileIn.read(data,0,1000))
   * != -1){ zipOut.write(data, 0, count); } }finally{ if(bufferIn != null){ bufferIn.close(); } } }
   * 
   * zipOut.flush(); // zipOut.close(); }catch (FileNotFoundException e) { LOG.log(Level.ERROR,
   * "Exception@generateZipFile: ", e); throw e; }catch (IOException e) { LOG.log(Level.ERROR,
   * "Exception@generateZipFile: ", e); throw e; }finally { try { if (bufferOut != null) {
   * bufferOut.close(); } if (zipOut != null) { zipOut.close(); } if (fileOut != null) {
   * fileOut.close(); } if (fileIn != null) { fileIn.close(); } if (bufferIn != null) {
   * bufferIn.close(); } } catch (IOException e) { LOG.log(Level.ERROR,
   * "Exception@generateZipFile: ", e); throw e; } } LOG.info("Exiting generateZipFile Method"); }
   */

  /**
   * This method is used for Deleting zip file and xls file
   * 
   * @return void
   */
  public static void deleteFiles(List<String> filePathZipLst, Map<String, List<String>> folderMap) {
    //LOG.info("Entering deleteFiles method");
    // String folderPathVal=folderPath;
    boolean zipFileExist;
    // boolean xlsFileExist;
    File zipFile = null;
    String filePathZip = "";
    // String filePathXls = "";
    // File xlsFile = null;
    // List<String> filePathXlsLst = null;

    // Delete Files and Folders List

    Iterator<String> folderMapItr = folderMap.keySet().iterator();
   // LOG.info("Delete Files and Folders List Start ");
    while (folderMapItr.hasNext()) {
      String folderPath = (String) folderMapItr.next();
      //LOG.info("folderPath >>>> " + folderPath);
      // Delete Folder
      File fol = new File(folderPath);
      deleteFolderRecrussive(fol);
    }
   // LOG.info("Delete Files and Folders List END ");

    // Delete ZIP Files List
    for (int x = 0; x < filePathZipLst.size(); x++) {
      filePathZip = filePathZipLst.get(x);
      zipFile = new File(filePathZip);
      zipFileExist = zipFile.exists();

      if (zipFileExist) {
        boolean deleted = zipFile.delete();
        //LOG.info("Successfully deleted zip file : " + filePathZip + " :: " + deleted);
      }
    }
   // LOG.info("Exiting deleteFiles Method");
  }

  /**
   * This method is used for Deleting zip file and xls file
   * 
   * @return void
   */
  public static void deleteFiles(String filePathXls, String filePathZip) {
   // LOG.info("Entering deleteFiles method");
    boolean zipFileExist;
    boolean xlsFileExist;
    File zipFile = new File(filePathZip);
    zipFileExist = zipFile.exists();
    File xlsFile = new File(filePathXls);
    xlsFileExist = xlsFile.exists();
    if (zipFileExist) {
      boolean deleted = zipFile.delete();
     // LOG.info("Successfully deleted zip file : " + deleted);
    }
    if (xlsFileExist) {
      boolean deleted = xlsFile.delete();
     // LOG.info("Successfully deleted xls file : " + deleted);
    }
   // LOG.info("Exiting deleteFiles Method");
  }

  public static void deleteFolderRecrussive(File fileName) {
    if (fileName.isDirectory()) {
      File[] lstFls = fileName.listFiles();
      if (lstFls != null) {
        for (File c : lstFls)
          deleteFolderRecrussive(c);
      }
    }
    if (fileName.exists()) {
      boolean deleted = fileName.delete();
     // LOG.info("Successfully deleted Folder :  >>> " + deleted);
    }
  }

  /**
   * This method is used for Removing duplicates from List
   * 
   * @return void
   */
  public static void removeDulicatesFromArrayList(List<String> dataList) {
    Set setItems = new LinkedHashSet(dataList);
    dataList.clear();
    dataList.addAll(setItems);
  }

  /**
   * This method is used for generating zip file
   * 
   * @return void
   */
  public static Map<String, Double> generateZipFile(List<String> filePathXlsLst,
      String filePathZip, boolean isCompressedSzieCalLogic) throws IOException {

    Map<String, Double> compressedFilesWithSize = new HashMap<String, Double>();
    FileOutputStream fos = new FileOutputStream(filePathZip);
    ZipOutputStream zos = new ZipOutputStream(fos);
    BufferedInputStream bis = null;
    FileInputStream fis = null;
    zos.setLevel(Deflater.DEFAULT_COMPRESSION);
    int bytesRead;
    byte[] buffer = new byte[1024];
    double zipSize = 0;
    double totSize = 0;
    double compressedSize = 0;
    boolean zipEntryFlag = false;
    try {
      for (int i = 0; i < filePathXlsLst.size(); i++) {
        String name = filePathXlsLst.get(i);
        File file = new File(name);
        if (file.exists()) {
          fis = new FileInputStream(file);
          bis = new BufferedInputStream(fis);
          ZipEntry entry = new ZipEntry(file.getName());
          zos.putNextEntry(entry);

          while ((bytesRead = bis.read(buffer)) != -1) {
            zos.write(buffer, 0, bytesRead);
          }

          if (isCompressedSzieCalLogic) {
            // try {
            zipSize = getZipFileSize(filePathZip);
            compressedSize = roundDecimal((zipSize - totSize), 2, BigDecimal.ROUND_HALF_UP);
            totSize += compressedSize;

            compressedFilesWithSize.put(name, compressedSize);
           // LOG.info("File Name = " + name + " Compressed size " + compressedSize);

            /*
             * } finally { bis.close(); }
             */

          }
          zipEntryFlag = true;
        }
        bis.close();
        fis.close();
      }
    } catch (FileNotFoundException e) {
    //  LOG.log(Level.ERROR, "FileNotFoundException@generateZipFile: ", e);
      throw e;
    } catch (IOException e) {
     // LOG.log(Level.ERROR, "IOException@generateZipFile: ", e);
      throw e;
    } finally {
      try {
      //  LOG.info("zos is not null trying to close the stream " + zipEntryFlag);
        zos.flush();
        zos.closeEntry();
      } catch (IOException e) {
     //   LOG.log(Level.ERROR, "IOException@generateZipFile While closing : ", e);
        throw e;
      } finally {
        try {
          zos.close();
          fos.close();
          if (fis != null) {
            fis.close();
          }
        } catch (IOException ie) {
          ie.printStackTrace();
        } finally {
          if (bis != null) {
            bis.close();
          }
        }
      }
    }
    return compressedFilesWithSize;

  }

  /**
   * This method is used for calculate zip file size
   * 
   * @return double
   */
  public static double getZipFileSize(String filePathZip) {
    File fObj = null;
    double sizeInBytes = 0;
    double sizeInMb = 0;

   // LOG.info("Inside getZipFileSize method filePathZipNew " + filePathZip);
    fObj = new File(filePathZip);
    // Get the number of bytes in the file
    sizeInBytes = fObj.length();
    // transform in MB
    sizeInMb = sizeInBytes / (1024 * 1024);

   // LOG.info("Total file size in MB >>>>>>>> " + sizeInMb);


    return sizeInMb;
  }

  public static double roundDecimal(double unrounded, int precision, int roundingMode) {
    BigDecimal bd = new BigDecimal(unrounded);
    BigDecimal rounded = bd.setScale(precision, roundingMode);
    return rounded.doubleValue();
  }


  /**
   * 
   * @param zipfile the template file
   * @param tmpfile the XML file with the sheet data
   * @param entry the name of the sheet entry to substitute, e.g. xl/worksheets/sheet1.xml
   * @param out the stream to write the result to
   */
  public static void substitute(File zipfile, File tmpfile, String entry, OutputStream out)
      throws IOException {
    ZipFile zip = new ZipFile(zipfile);
    InputStream is = null;
    ZipOutputStream zos = new ZipOutputStream(out);
    try {
      @SuppressWarnings("unchecked")
      Enumeration<ZipEntry> en = (Enumeration<ZipEntry>) zip.entries();
      while (en.hasMoreElements()) {
        ZipEntry ze = en.nextElement();
        if (!ze.getName().equals(entry)) {
          zos.putNextEntry(new ZipEntry(ze.getName()));
          InputStream inpstr = zip.getInputStream(ze);
          copyStream(inpstr, zos);
          inpstr.close();
        }
      }
      zos.putNextEntry(new ZipEntry(entry));
      is = new FileInputStream(tmpfile);
      copyStream(is, zos);
    } finally {
      try {
        if (is != null) {
          is.close();
        }
      } catch (IOException ie) {
        ie.printStackTrace();
      } finally {
        try {
          zos.close();
        } catch (IOException ie) {
          ie.printStackTrace();
        } finally {
          zip.close();
        }
      }
    }
  }

  /**
   * @param in
   * @param out
   * @throws IOException
   */
  public static void copyStream(InputStream in, OutputStream out) throws IOException {
    byte[] chunk = new byte[1024];
    int count;
    while ((count = in.read(chunk)) >= 0) {
      out.write(chunk, 0, count);
    }
  }

  /**
   * Repeat the string n times
   * 
   * @param String
   * @param String
   * @param int
   * @return boolean
   */
  public static String repeatStr(String str, String append, int repeat) {
    StringBuffer newstr = new StringBuffer();
    for (int rept = 0; rept < repeat; rept++) {
      newstr.append(str + "" + append);
    }
    return newstr.toString();
  }

  /**
   * @param folderPath
   * @param fileExtension
   * @return
   */
  public static File[] getFilesByExtension(String folderPath, final String fileExtension) {
    File dir = new File(folderPath);
    File[] files = dir.listFiles(new FilenameFilter() {
      public boolean accept(File dir, String name) {
        return name.endsWith(fileExtension);
      }
    });
    return files;
  }

  /**
   * @param folderPath
   * @param fileExtension
   * @param fileExclude
   * @param numOfDaysOld
   */
  /*
   * public static void deleteFilesWithExtensionOlderThanDays(String folderPath, String
   * fileExtension, String fileExclude, int numOfDaysOld){ long diff; final long
   * MILLISECONDS_PER_DAY = 24L*3600*1000; LOG.info("MILLISECONDS_PER_DAY "+MILLISECONDS_PER_DAY);
   * File[] files = getFilesByExtension(folderPath, fileExtension); try { if (files != null) {
   * LOG.info("Total Files with specified extension "+ files.length); for (File file : files) { diff
   * = new Date().getTime() - file.lastModified(); if (diff > numOfDaysOld * MILLISECONDS_PER_DAY) {
   * if (!file.getName().equals(fileExclude)) { LOG.info(file.getName() + " " + file.delete()); } }
   * } } } catch (Exception e) {
   * LOG.info("Error raised while deleteFilesWithExtensionOlderThanDays : ", e); } }
   */

  /**
   * @param strList
   * @return
   */
  public static String convertListToStringWithQuotes(List<String> strList) {
    String retValue = "";
    StringBuffer sb = new StringBuffer();
    if (!isEmptyList(strList)) {
      for (String srtVal : strList) {
        if (!isEmpty(srtVal)) {
          sb.append("'");
          sb.append(srtVal);
          sb.append("',");
        }
      }
    }
    if (!isEmpty(sb.toString())) {
      retValue = sb.substring(0, sb.length() - 1);
    }
    return retValue;
  }

  // newly added Project Change summary
  /**
   * @param strInputVal
   * @return
   */
  /*
   * public static boolean checkSplCharsProjSumry(String strInputVal) {
   * 
   * String reqExpression = "[^~`#@?%;(){}''!\\\\\"\"$^><]";
   * 
   * return Pattern.matches(reqExpression, strInputVal);
   * 
   * }
   */

  public static boolean checkSplCharsProjSumry(String strInputVal) {
    boolean bSpecialFlag = false;
    String sSpecialChars = "[^~`#@?%;(){}''!\\\\\"\"$^><]";
    /* try { */
    if (strInputVal != null) {
      for (int iLength = 0; iLength < strInputVal.length(); iLength++) {
        if (sSpecialChars.indexOf(strInputVal.charAt(iLength)) != -1) {
          bSpecialFlag = true;
        }// end of if
      }// end of for loop
    }// end of if
    /*
     * } catch (Exception ex) { LOG.error("Exception in the checkSpecialCharsForLegalEntity ", ex);
     * }
     */
    return bSpecialFlag;
  }


  // newly added Project Change summary
  /**
   * @param field_name
   * @param field_value
   * @return
   */
  public static String generatePrjQuryForMultipleNames(String field_name, String field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    boolean whereFlag = false;
    List<String> fieldValueInList = new ArrayList<String>();
    List<String> fieldValueLikeList = new ArrayList<String>();

    StringTokenizer token = new StringTokenizer(field_value, ",");
    List<String> fieldValueList = new ArrayList<String>();
    while (token.hasMoreElements()) {
      String arrayValue = token.nextToken();
      fieldValueList.add(arrayValue.trim());
    }
    if (!PLMUtils.isEmptyList(fieldValueList)) {
      for (int i = 0; i < fieldValueList.size(); i++) {
        String arrayValue = fieldValueList.get(i);
        if (arrayValue.indexOf('*') != -1) {
          arrayValue = arrayValue.replace("*", "%");
          fieldValueLikeList.add(arrayValue);
        } else {
          fieldValueInList.add(arrayValue);
        }
      }
    }

    if (!PLMUtils.isEmptyList(fieldValueInList)) {
      whereClauseQry
          .append(field_name + " IN (" + PLMUtils.setListForQuery(fieldValueInList) + ")");
      whereFlag = true;
    }

    if (!PLMUtils.isEmptyList(fieldValueLikeList)) {
      if (whereFlag) {
        whereClauseQry.append(" OR ");
      }

      whereClauseQry.append(field_name + " LIKE ANY (");
      for (int i = 0; i < fieldValueLikeList.size(); i++) {
        String likeValue = fieldValueLikeList.get(i);
        whereClauseQry.append("'" + likeValue + "'");
        if (i < fieldValueLikeList.size() - 1) {
          whereClauseQry.append(" , ");
        }
      }
      whereClauseQry.append(" ) ");
    }
    return whereClauseQry.toString();
  }

  public static String convertCostFlt(String cost) {
    String costVal = cost;
    String number = "";
    try {
      NumberFormat formatter;
      double doubleVal = 0.0;
      if (costVal != null) {
        if (costVal.contains(" ")) {
          costVal = costVal.replace(" ", "");
          doubleVal = Double.parseDouble(costVal);
        }
        formatter = new DecimalFormat("0.00");
        number = formatter.format(doubleVal);
      }
    } catch (NumberFormatException e) {

      number = costVal;
    }
    return number;
  }


  // newly Added by srinivas for FMI
  /**
   * @param strList
   * @return
   */
  public static String setListsForQuery(List<List<String>> strList) {
    StringBuffer stMake = null;
    StringTokenizer stToken = null;
    String aText = null;

    if (strList != null) {
      for (int i = 0; i < strList.size(); i++) {
        if (aText != null) {
          aText = aText + strList.get(i) + ",";
          // Log.Info(" demandList " + i + " " + aText);
        } else {
          aText = strList.get(i) + ",";
          // Log.Info(" demandList " + i + " " + aText);
        }
      }
    }

    if (aText != null) {
      aText = aText.replace("'", "''");
      aText = aText.replace("[", "");
      aText = aText.replace("]", "");
      stToken = new StringTokenizer(aText, ",");

      while (stToken.hasMoreTokens()) {
        if (stMake == null) {
          stMake = new StringBuffer();
          stMake.append("'");// StringBuffer("'");
          stMake.append(stToken.nextToken());
          stMake.append("'");
          // Log.Info("::stMake - 1::" + stMake);
        } else {
          stMake.append(",");
          stMake.append("'").append(stToken.nextToken()).append("'");
          // Log.Info("::stMake - 2::" + stMake);
        }
      }
    }
    return stMake != null ? stMake.toString() : " ";
  }


  // newly added for wildcard seperation of numeric and alpha numeric of Project Change summary
  /**
   * @param field_name
   * @param field_value
   * @return
   */
  public static String generatePrjQuryForSsoIds(String field_name, String field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    boolean whereFlag = false;
    List<String> fieldValueInList = new ArrayList<String>();
    List<String> fieldValueLikeList = new ArrayList<String>();
    String feildValFinal = field_value;
    feildValFinal = feildValFinal.replace(" ", "");
   // LOG.info("feildValFinal ID" + feildValFinal);
    String numerics = "((-|\\+)?[0-9*]+(\\.[0-9*]+)?)+";
    StringTokenizer token = new StringTokenizer(feildValFinal, ",");
    List<String> fieldValueList = new ArrayList<String>();
    while (token.hasMoreElements()) {
      String arrayValue = token.nextToken();
      if (arrayValue.matches(numerics)) {
        fieldValueList.add(arrayValue.trim());
      }
    }
    if (!PLMUtils.isEmptyList(fieldValueList)) {
      for (int i = 0; i < fieldValueList.size(); i++) {
        String arrayValue = fieldValueList.get(i);
        if (arrayValue.indexOf('*') != -1) {
          arrayValue = arrayValue.replace("*", "%");
          fieldValueLikeList.add(arrayValue);
        } else {
          fieldValueInList.add(arrayValue);
        }
      }
    }

    if (!PLMUtils.isEmptyList(fieldValueInList)) {
      whereClauseQry
          .append(field_name + " IN (" + PLMUtils.setListForQuery(fieldValueInList) + ")");
      whereFlag = true;
    }

    if (!PLMUtils.isEmptyList(fieldValueLikeList)) {
      if (whereFlag) {
        whereClauseQry.append(" OR ");
      }

      whereClauseQry.append(field_name + " LIKE ANY (");
      for (int i = 0; i < fieldValueLikeList.size(); i++) {
        String likeValue = fieldValueLikeList.get(i);
        whereClauseQry.append("'" + likeValue + "'");
        if (i < fieldValueLikeList.size() - 1) {
          whereClauseQry.append(" , ");
        }
      }
      whereClauseQry.append(" ) ");
    }
    return whereClauseQry.toString();
  }

  /**
   * @param field_name
   * @param field_value
   * @return
   */
  public static String generatePrjQuryForSsoNames(String field_name, String field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    boolean whereFlag = false;
    List<String> fieldValueInList = new ArrayList<String>();
    List<String> fieldValueLikeList = new ArrayList<String>();
    String feildValFinal = field_value;
    feildValFinal = feildValFinal.replace(" ", "");
   // LOG.info("feildValFinal Str" + feildValFinal);

    String Strpattern = "((-|\\+)?[a-zA-Z*]+(\\.[a-zA-Z*]+)?)+";
    StringTokenizer token = new StringTokenizer(feildValFinal, ",");
    List<String> fieldValueList = new ArrayList<String>();
    while (token.hasMoreElements()) {
      String arrayValue = token.nextToken();
      if (arrayValue.matches(Strpattern)) {
        fieldValueList.add(arrayValue.trim());
      }
    }
    if (!PLMUtils.isEmptyList(fieldValueList)) {
      for (int i = 0; i < fieldValueList.size(); i++) {
        String arrayValue = fieldValueList.get(i);
        if (arrayValue.indexOf('*') != -1) {
          arrayValue = arrayValue.replace("*", "%");
          fieldValueLikeList.add(arrayValue);
        } else {
          fieldValueInList.add(arrayValue);
        }
      }
    }

    if (!PLMUtils.isEmptyList(fieldValueInList)) {
      whereClauseQry
          .append(field_name + " IN (" + PLMUtils.setListForQuery(fieldValueInList) + ")");
      whereFlag = true;
    }

    if (!PLMUtils.isEmptyList(fieldValueLikeList)) {
      if (whereFlag) {
        whereClauseQry.append(" OR ");
      }

      whereClauseQry.append(field_name + " LIKE ANY (");
      for (int i = 0; i < fieldValueLikeList.size(); i++) {
        String likeValue = fieldValueLikeList.get(i);
        whereClauseQry.append("'" + likeValue + "'");
        if (i < fieldValueLikeList.size() - 1) {
          whereClauseQry.append(" , ");
        }
      }
      whereClauseQry.append(" ) ");
    }
    return whereClauseQry.toString();
  }



  public static boolean checkSplCharWhereUsed(String strInputVal) {
    return checkSplCharWhereUsed(strInputVal, "[^~`#@?%;(){}''!\\\\\"\"$%*^><]");
  }
  
  public static boolean checkSplCharAllowStar(String strInputVal) {
	    return checkSplCharWhereUsed(strInputVal, "[^~`#@?%;(){}''!\\\\\"\"$%^><]");
  }
  
  public static boolean checkSplCharWhereUsed(String strInputVal, String sSpecialChars) {
	    boolean bSpecialFlag = false;
	    //String sSpecialChars = "[^~`#@?%;(){}''!\\\\\"\"$%*^><]";
	    try {
	      if (strInputVal != null) {
	        for (int iLength = 0; iLength < strInputVal.length(); iLength++) {
	          if (sSpecialChars.indexOf(strInputVal.charAt(iLength)) != -1) {
	            bSpecialFlag = true;
	          }// end of if
	        }// end of for loop
	      }// end of if
	    } catch (Exception ex) {
	    //  LOG.error("Exception in the checkSpecialCharsForLegalEntity ", ex);
	    }
	    return bSpecialFlag;
	  }

  /**
   * 
   * class to sort list of object of type PLMDocGenFmiData.
   * 
   */
  public static class SortStringList implements Comparator<String>, Serializable {
    /**
     * long serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    /**
     * used for comparision..
     */
    public int compare(String aString, String bString) {
      return aString.compareTo(bString);
    }

  }

  // Added by Shekhar for Cost Cycle Smry Report
  /**
   * @param subStr
   * @return
   */
  public static String checkNullValCostCycle(String val) {
    String value = val;

    if (value == null) {
      value = "Others";
    } else if (value.equalsIgnoreCase("null")) {
      value = "Others";
    }
    return value;
  }


  // Added by Srinivas for Cost Cycle Smry Report for decimal points
  /**
   * @param cost
   * @return
   */
  public static Double convertCostCycle(Double cost) {
    Double costVal = cost;
    String strCostVal = "";
    double doubleVal = 0.0;
    try {
      NumberFormat formatter;
      formatter = new DecimalFormat("#0.0000");
      if (costVal != 0.0) {
        strCostVal = formatter.format(costVal);
        doubleVal = Double.valueOf(strCostVal);
      }
    } catch (NumberFormatException e) {
      e.printStackTrace();
    }
    return doubleVal;
  }

  /**
   * @param strList
   * @return String
   */
  public static String convertListToStr(List<String> strList) {
    StringBuffer stMake = null;
    StringTokenizer stToken = null;
    String aText = null;

    if (strList != null) {
      for (int i = 0; i < strList.size(); i++) {
        if (aText != null) {
          aText = aText + strList.get(i) + ", ";
          // Log.Info(" demandList " + i + " " + aText);
        } else {
          aText = strList.get(i) + ", ";
          // Log.Info(" demandList " + i + " " + aText);
        }
      }
    }

    if (aText != null) {
      aText = aText.replace("'", "''");
      stToken = new StringTokenizer(aText, ", ");

      while (stToken.hasMoreTokens()) {
        if (stMake == null) {
          stMake = new StringBuffer();
          // stMake.append("'");// StringBuffer("'");
          stMake.append(stToken.nextToken());
          // stMake.append("'");
          // Log.Info("::stMake - 1::" + stMake);
        } else {
          stMake.append(", ");
          stMake.append(stToken.nextToken());
          // Log.Info("::stMake - 2::" + stMake);
        }
      }
    }
    return stMake != null ? stMake.toString() : " ";
  }

  // Added by Srinivas for Cost Cycle Smry Report for height alignment setting
  /**
   * @param noRecs
   * @return String
   */
  public static String getTableHeight(int noRecs) {
    int height = 0;
    if (noRecs > 12) {
      return "450px";
    } else {
      height = (noRecs * 35) + 70;
      return height + "px";
    }
  }

  // Newly added by srinvas for pin value comparision
  /**
   * @param subStr
   * @return
   */
  public static String checkPINVal(String val) {
    String value = "";
    if ("MSDM".equalsIgnoreCase(val) || "MSSM".equalsIgnoreCase(val)
        || "MSDV".equalsIgnoreCase(val)) {
      value = "MSD";
    } else {
      value = "Factory";
    }
    return value;
  }

  
  public static Double convertCyclePart(Double cost) {
    Double costVal = cost;
    String strCostVal = "";
    double doubleVal = 0.0;
    try {
      NumberFormat formatter;
      formatter = new DecimalFormat("#0.00");
      if (costVal != 0.0) {
        strCostVal = formatter.format(costVal);
        doubleVal = Double.valueOf(strCostVal);
      }
    } catch (NumberFormatException e) {
      e.printStackTrace();
    }
    return doubleVal;
  }

  
  public static boolean checkForSpecialCharsCustDoc(String strInputVal) {

    String reqExpression = "[^~`#@%;_&(){}''!\\\\\"\"$^]*";

    return Pattern.matches(reqExpression, strInputVal);

  }

  public static boolean checkForSpecialCharsCustDoc1(String strInputVal) {

    String reqExpression = "[^~`#@?%;_&(){}''!\\\\\"\"$^*]*";

    return Pattern.matches(reqExpression, strInputVal);

  }

  public static boolean checkForCharsDigitsCustDoc(String strInputVal) {

    String reqExpression = "[a-zA-Z0-9]{2,}";

    return Pattern.matches(reqExpression, strInputVal.replace("*", "").replace("?", ""));

  }

  public static boolean checkForCharsDigitsCustDocNew(String strInputVal) {

    String reqExpression = "[a-zA-Z0-9]{2,}";
    StringTokenizer tkn = new StringTokenizer(strInputVal, ",");
    while (tkn.hasMoreTokens()) {
      // System.out.println(Pattern.matches(reqExpression,
      // tkn.nextToken().replace("*","").replace("?", "")));
      if (!Pattern.matches(reqExpression, tkn.nextToken().replace("*", "").replace("?", "").trim())) {
        // System.out.println("False");
        return false;
      } else {
        // System.out.println("True");
      }
    }
    return true;
    // return Pattern.matches(reqExpression, strInputVal.replace("*","").replace("?", ""));

  }
  public static boolean checkForCharsDigitsECO(String strInputVal) {

	    String reqExpression = "[a-zA-Z0-9]{4,}";
	    StringTokenizer tkn = new StringTokenizer(strInputVal, ",");
	    while (tkn.hasMoreTokens()) {
	      // System.out.println(Pattern.matches(reqExpression,
	      // tkn.nextToken().replace("*","").replace("?", "")));
	      if (!Pattern.matches(reqExpression, tkn.nextToken().replace("*", "").replace("?", "").trim())) {
	        // System.out.println("False");
	        return false;
	      } else {
	        // System.out.println("True");
	      }
	    }
	    return true;
	    // return Pattern.matches(reqExpression, strInputVal.replace("*","").replace("?", ""));

	  }

  /**
   * @param field_name
   * @param field_value
   * @return
   */
  public static String generateQueryForMultipleNamesCustDoc(String field_name, String field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    boolean whereFlag = false;
    List<String> fieldValueInList = new ArrayList<String>();
    List<String> fieldValueLikeList = new ArrayList<String>();

    StringTokenizer token = new StringTokenizer(field_value, ",");
    List<String> fieldValueList = new ArrayList<String>();
    while (token.hasMoreElements()) {
      String arrayValue = token.nextToken();
      fieldValueList.add(arrayValue.trim());
    }
    if (!PLMUtils.isEmptyList(fieldValueList)) {
      for (int i = 0; i < fieldValueList.size(); i++) {
        String arrayValue = fieldValueList.get(i);

        if (arrayValue.indexOf('*') == -1 && arrayValue.indexOf('?') == -1) {
          fieldValueInList.add(arrayValue);
        }

        if (arrayValue.indexOf('*') != -1 || arrayValue.indexOf('?') != -1) {
          if (arrayValue.indexOf('*') != -1) {
            arrayValue = arrayValue.replace("*", "%");
          }
          if (arrayValue.indexOf('?') != -1) {
            arrayValue = arrayValue.replace("?", "_");
          }
          fieldValueLikeList.add(arrayValue);
        }


      }
    }

    if (!PLMUtils.isEmptyList(fieldValueInList)) {
      whereClauseQry
          .append(field_name + " IN (" + PLMUtils.setListForQuery(fieldValueInList) + ")");
      whereFlag = true;
    }

    if (!PLMUtils.isEmptyList(fieldValueLikeList)) {
      if (whereFlag) {
        whereClauseQry.append(" OR ");
      }
      for (int i = 0; i < fieldValueLikeList.size(); i++) {
        String likeValue = fieldValueLikeList.get(i);
        whereClauseQry.append(field_name + " LIKE '" + likeValue + "'");
        if (i < fieldValueLikeList.size() - 1) {
          whereClauseQry.append(" OR ");
        }
      }
    }
    return whereClauseQry.toString();
  }

 

  public static String joinToString(List<String> collection) {
    CharSequence separator = ",";
    if (collection.isEmpty()) {
      return "";
    } else {
      StringBuilder sepValueBuilder = new StringBuilder();

      for (Object obj : collection) {
        // Append the value and the separator even if it's the last element
        sepValueBuilder.append(obj).append(separator);
      }
      // Remove the last separator
      sepValueBuilder.setLength(sepValueBuilder.length() - separator.length());

      return sepValueBuilder.toString();

    }
  }

 
  public static String setListForQueryCustDoc(List<String> strList) {
    StringBuffer stMake = null;
    StringTokenizer stToken = null;
    String aText = null;

    if (strList != null) {
      for (int i = 0; i < strList.size(); i++) {
        if (aText != null) {
          aText = aText + strList.get(i) + "TC5" + ",";
          // Log.Info(" demandList " + i + " " + aText);
        } else {
          aText = strList.get(i) + "TC5" + ",";
          // Log.Info(" demandList " + i + " " + aText);
        }
      }
    }

    if (aText != null) {
      aText = aText.replace("'", "''");
      stToken = new StringTokenizer(aText, ",");

      while (stToken.hasMoreTokens()) {
        if (stMake == null) {
          stMake = new StringBuffer();
          stMake.append("'");// StringBuffer("'");
          stMake.append(stToken.nextToken());
          stMake.append("'");
          // Log.Info("::stMake - 1::" + stMake);
        } else {
          stMake.append(",");
          stMake.append("'").append(stToken.nextToken()).append("'");
          // Log.Info("::stMake - 2::" + stMake);
        }
      }
    }
    return stMake != null ? stMake.toString() : " ";
  }

  public static String generateQueryForMultipleNamesCustDocNew(String field_name, String field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    boolean whereFlag = false;
    List<String> fieldValueInList = new ArrayList<String>();
    List<String> fieldValueLikeList = new ArrayList<String>();

    StringTokenizer token = new StringTokenizer(field_value, ",");
    List<String> fieldValueList = new ArrayList<String>();
    while (token.hasMoreElements()) {
      String arrayValue = token.nextToken();
      fieldValueList.add(arrayValue.trim());
    }
    if (!PLMUtils.isEmptyList(fieldValueList)) {
      for (int i = 0; i < fieldValueList.size(); i++) {
        String arrayValue = fieldValueList.get(i);

        if (arrayValue.indexOf('*') == -1 && arrayValue.indexOf('?') == -1) {
          fieldValueInList.add(arrayValue);
        }

        if (arrayValue.indexOf('*') != -1 || arrayValue.indexOf('?') != -1) {
          if (arrayValue.indexOf('*') != -1) {
            arrayValue = arrayValue.replace("*", "%");
          }
          if (arrayValue.indexOf('?') != -1) {
            arrayValue = arrayValue.replace("?", "_");
          }
          fieldValueLikeList.add(arrayValue);
        }


      }
    }

    if (!PLMUtils.isEmptyList(fieldValueInList)) {
      whereClauseQry.append(field_name + " IN ("
          + PLMUtils.setListForQueryCustDoc(fieldValueInList) + ")");
      whereFlag = true;
    }

    if (!PLMUtils.isEmptyList(fieldValueLikeList)) {
      if (whereFlag) {
        whereClauseQry.append(" OR ");
      }
      for (int i = 0; i < fieldValueLikeList.size(); i++) {
        String likeValue = fieldValueLikeList.get(i);
        whereClauseQry.append(field_name + " LIKE '" + likeValue + "TC5" + "'");
        if (i < fieldValueLikeList.size() - 1) {
          whereClauseQry.append(" OR ");
        }
      }
    }
    return whereClauseQry.toString();
  }

  public static String joinList(List<String> list, String literal) {
    return list.toString().replaceAll(",", literal).replaceAll("[\\[\\]\\s+]", "");
  }

  /**
   * This Method is used to generate wild Card Criteria
   * 
   * @param field_name
   * @param whereClause_field_value
   * 
   * @return String
   */
  public static String generateWildCardClause(String field_name, String whereClause_field_value) {
    StringBuffer whereClauseQry = new StringBuffer();
    // Locale locale = Locale.getDefault();
    // String field_value = whereClause_field_value.replace("*", "%").toUpperCase(locale);
    String field_value = whereClause_field_value.replace("*", "%");
    if (field_value.indexOf(',') != -1) {
      // contains multiple search criteria
      String[] tokens = field_value.split(",");
      String field_tok = null;

      for (int i = 0; i < tokens.length; i++) {
        // whereClauseQry.append("UPPER(" + field_name + ") LIKE ");
        whereClauseQry.append(field_name + " LIKE ");
        field_tok = tokens[i].trim();
        if (field_tok != null && field_tok.lastIndexOf('*') != -1
            && field_tok.lastIndexOf('*') == field_tok.length() - 1) {
          field_tok = field_tok.substring(0, field_tok.length() - 1);
         // LOG.info("If loop Engg ID(contains multiple search criteria):" + field_tok);
        }
       // LOG.info("After SubString the Value of the Engg ID(contains multiple search criteria):"  + field_tok);

        whereClauseQry.append("'");
        whereClauseQry.append(field_tok);
        whereClauseQry.append("' OR ");
        //LOG.info("whereClauseQry now is:::" + whereClauseQry + "::::");
      }
    } else if (field_value.lastIndexOf('*') != -1
        && (field_value.lastIndexOf('*') == field_value.length() - 1)) {
      whereClauseQry.append(field_name + " LIKE ");
      // simple search
      field_value = field_value.substring(0, field_value.length() - 1);
     // LOG.info("If loop Engg ID(simple search):" + field_value);

     // LOG.info("After SubString the Value of the Engg ID(simple search):" + field_value);

      whereClauseQry.append("'");
      whereClauseQry.append(field_value);
      whereClauseQry.append("' OR ");
    } else {
      // whereClauseQry.append("UPPER(" + field_name + ") LIKE ");
      whereClauseQry.append(field_name + " LIKE ");
      whereClauseQry.append("'");
      whereClauseQry.append(field_value);
      whereClauseQry.append("' OR ");
    }
    String query = whereClauseQry.toString();
    query = query.substring(0, query.length() - 4);
    whereClauseQry = new StringBuffer(query);

    return whereClauseQry.toString();
  }
  
  //Newly Added for comma separated and wild card
  public static String splitWildCardCriteria(String field_name, String field_value) {
	    StringBuffer whereClauseQry = new StringBuffer();
	    boolean whereFlag = false;
	    List<String> fieldValueInList = new ArrayList<String>();
	    List<String> fieldValueLikeList = new ArrayList<String>();

	    StringTokenizer token = new StringTokenizer(field_value, ",");
	    List<String> fieldValueList = new ArrayList<String>();
	    while (token.hasMoreElements()) {
	      String arrayValue = token.nextToken();
	      fieldValueList.add(arrayValue.trim());
	    }
	    if (!PLMUtils.isEmptyList(fieldValueList)) {
	      for (int i = 0; i < fieldValueList.size(); i++) {
	        String arrayValue = fieldValueList.get(i);

	        if (arrayValue.indexOf('*') == -1) {
	          fieldValueInList.add(arrayValue);
	        }

	        if (arrayValue.indexOf('*') != -1) {
	            arrayValue = arrayValue.replace("*", "%");
	          fieldValueLikeList.add(arrayValue);
	        }

	      }
	    }
	    whereClauseQry.append(" ( ");
	    if (!PLMUtils.isEmptyList(fieldValueInList)) {
	      whereClauseQry.append(field_name + " IN ("
	          + PLMUtils.setListForQuery(fieldValueInList) + ")");
	      whereFlag = true;
	    }

	    if (!PLMUtils.isEmptyList(fieldValueLikeList)) {
	      if (whereFlag) {
	        whereClauseQry.append(" OR ");
	      }
	    
	      for (int i = 0; i < fieldValueLikeList.size(); i++) {
	        String likeValue = fieldValueLikeList.get(i);
	        whereClauseQry.append(field_name + " LIKE '" + likeValue + "'");
	        if (i < fieldValueLikeList.size() - 1) {
	          whereClauseQry.append(" OR ");
	        }
	      }
	     
	    }
	    whereClauseQry.append(" ) ");
	    return whereClauseQry.toString();
	  }

  /**
   * @param qty
   * @return
   */
  public static String convertQtyLimit(String qty) {
    String strQtyVal = "";
    String qtyVal=qty;
    try {
      NumberFormat formatter;
      formatter = new DecimalFormat("#0.00");
      if (!isEmpty(qtyVal)) {
    	Double qtyDouble = Double.parseDouble(qtyVal);
        strQtyVal = formatter.format(qtyDouble);
      }
    } catch (NumberFormatException e) {
      e.printStackTrace();
    }
    return strQtyVal;
  }
  
  /**
   * @param strInputVal
   * @return
   */
  public static boolean checkAlphabetic(String strInputVal) {
    String reqExpression = "[^A-Za-z$^]*";
    return Pattern.matches(reqExpression, strInputVal);
  }
  
  /**
   * @param subStr
   * @return
   */
  public static String checkNullValSysName(String val) {
    String value = val;

    if (value == null) {
      value = "Unassigned";
    } else if (value.equalsIgnoreCase("null")) {
      value = "Unassigned";
    }
    return value;
  }
  
  /**
   * @param subStr
   * @return
   */
  public static String splitSemicolonSymbol(String val) {
    String strVal = val;
    String finalStrVal="";
    StringBuffer strBuffer=new StringBuffer();
    if(strVal != null){
      String strArr[] = strVal.split(";");
       for(int i=0;i<strArr.length;i++){
    	   strBuffer.append(strArr[i]+"\n");
       }
       finalStrVal = strBuffer.substring(0, strBuffer.length()-1);
    }
    return finalStrVal;
  }
  
  /**
   * @param strList
   * @return
   */
  public static String setListForPartNames(List<String> strList) {
    StringBuffer stMake = null;
    StringTokenizer stToken = null;
    String aText = null;

    if (strList != null) {
      for (int i = 0; i < strList.size(); i++) {
        if (aText != null) {
          aText = aText + strList.get(i) + ",";
        } else {
          aText = strList.get(i) + ",";
        }
      }
    }

    if (aText != null) {
      aText = aText.replace("'", "''");
      stToken = new StringTokenizer(aText, ",");

      while (stToken.hasMoreTokens()) {
        if (stMake == null) {
          stMake = new StringBuffer();
          stMake.append("'");
          stMake.append(stToken.nextToken().trim());
          stMake.append("'");
        } else {
          stMake.append(",");
          stMake.append("'").append(stToken.nextToken().trim()).append("'");
        }
      }
    }
    return stMake != null ? stMake.toString() : " ";
  }
  /**
   * @param assetType
   * @return boolean
   */
  public static boolean isValidOwner(String assetType) {
	  
	    if (assetType != null && !"".equals(assetType.trim())) {
	      return assetType.matches("^[0-9,]*");
	    }
	    
	    return true;
	  }
  
  /**
   * checks whether passed String is empty or not.
   * if null return blank
   * @param engg_drwng_owner
   * @return boolean
   * @throws DRCommonException
   */
  public static String isEmptyRtnStr(String value) {
	    String localVal = value;
	    if (localVal != null) {
	      localVal = localVal.trim();
	    }
	    if (localVal == null || localVal.equals("")) {
	    	localVal = "";
	    }
	    return localVal;
	  }

  public static String surroundWithWildcards(String root) {
		return new StringBuffer("%").append(root.trim().toLowerCase(Locale.US))
				.append("%").toString();
	}
  
  public static String exportTestCases(List<TestCasesVO> lstTestCaseVo) {
    // TODO Auto-generated method stub
   
    // List<ResultSetMetaData> Column_names=testCaseVo.getMetaDataList();
    Row row = null;
    String workSheetName = "Test_Cases_Result";
    String absPath = ""; 
    String resultFlag = "";
    String resultStatus = "";
    
    XSSFWorkbook workbook = new XSSFWorkbook();
    XSSFSheet sheet = workbook.createSheet("TestCases");
    int cellmax = 0;
    int rownum = 0;
    Cell cell = null;
    CellStyle style = workbook.createCellStyle();
    //style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
    //style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    CellStyle style1 = workbook.createCellStyle();
    style1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
    style1.setFillPattern(CellStyle.SOLID_FOREGROUND);
    
    row = sheet.createRow(rownum++);
    cell = row.createCell(0);
    cell.setCellValue("TestCase Name");
    cell.setCellStyle(style1);
    cell = row.createCell(1);
    cell.setCellValue("Description");
    cell.setCellStyle(style1);
    cell = row.createCell(2);
    cell.setCellValue("Source Query");
    cell.setCellStyle(style1);
   
    cell = row.createCell(3);
    cell.setCellValue("Target Query");
    cell.setCellStyle(style1);
    cell = row.createCell(4);
    cell.setCellValue("Result Status");
    cell.setCellStyle(style1);
    cell = row.createCell(5);
    cell.setCellValue("Result Message");
    cell.setCellStyle(style1);
    //cell = row.createCell(5);
    //cell.setCellValue("Target DB");
    //cell.setCellStyle(style1);
    for(TestCasesVO testCaseVo : lstTestCaseVo) {
      
      row = sheet.createRow(rownum++);
      
      cell = row.createCell(0);
       // cell.setCellValue(testCaseVo.getTestCaseName());
        cell.setCellValue((testCaseVo.getProjectName().substring(0,2)+testCaseVo.getProjectName().substring(testCaseVo.getProjectName().length()-2, testCaseVo.getProjectName().length())).toUpperCase()+"_"+String.format("%03d" , Integer.parseInt(testCaseVo.getTestCaseName())));
        cell.setCellStyle(style);
      cell = row.createCell(1);
        cell.setCellValue(testCaseVo.getDescription());
        cell.setCellStyle(style);
      cell = row.createCell(2);
        cell.setCellValue(testCaseVo.getTestQryOne());
        cell.setCellStyle(style);
      //cell = row.createCell(3);
        //cell.setCellValue(testCaseVo.getTestDSOne());
        //cell.setCellStyle(style);
      cell = row.createCell(3);
        cell.setCellValue(testCaseVo.getTestQryTwo());
        cell.setCellStyle(style);
      //cell = row.createCell(5);
        //cell.setCellValue(testCaseVo.getTestDSTwo());
        //cell.setCellStyle(style);
        if(testCaseVo.getTestResultFlag()!=null) {
          if (testCaseVo.getTestResultFlag().equalsIgnoreCase("P")) {
            resultFlag = "Pass";
            resultStatus = "Result set for both source and target are matched.";
          } else if (testCaseVo.getTestResultFlag().equalsIgnoreCase("F")) {
            resultFlag = "Fail";
            resultStatus = testCaseVo.getTestResultStats();
          } else if (testCaseVo.getTestResultFlag().equalsIgnoreCase("E")){
            resultFlag = "Error";
            resultStatus = testCaseVo.getTestResultStats();
          }else {
            resultFlag = "";
            resultStatus = "";
          }
        }
        
        cell = row.createCell(4);
        cell.setCellValue(resultFlag);
        cell.setCellStyle(style);
        cell = row.createCell(5);
        cell.setCellValue(resultStatus);
        cell.setCellStyle(style);
        resultFlag="";
        resultStatus="";
      
    }
    
    rownum = 0;
    
    try {
      // Write the workbook in file system
      File file = new File(workSheetName+ ".xlsx");
      absPath = file.getName();
      FileOutputStream out = new FileOutputStream(file);
      workbook.write(out);
      out.close();
      System.out.println(absPath +"--"+ workSheetName+ ".xlsx written successfully on disk.");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return absPath;
  }
  
}
