package com.techm.auto.autorunner.data;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is used to maintain report input details.
 * @author : 212321748
 * @version : 1.0 
 */
public class PwiReportResultRowMetaData {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private List<PwiReportResultRow> resultRows;
	private List<PWiResultSetColMetaData> metaData = new ArrayList<PWiResultSetColMetaData>();
	private List<PwiReportResultRow> data = new ArrayList<PwiReportResultRow>();
	private HashMap<String, Integer> htColIdxByName =
		new HashMap<String, Integer>();
	private HashMap<Integer, PWiResultSetColMetaData> htColMdByIdx =
		new HashMap<Integer, PWiResultSetColMetaData>();
	private int rowcounter; // automatically initialized to 0
	private List<String> row = new ArrayList<String>();
	private String executedQry ;
	private List<String> params =new ArrayList<String>();
	private String queryName ;
	private int eventId ;
	private List<HashMap<String,String>> valMap = new ArrayList<HashMap<String,String>>();
	
	public PwiReportResultRowMetaData(){}
	
	public PwiReportResultRowMetaData(List<PWiResultSetColMetaData> metaData, ArrayList<PwiReportResultRow> resultRows){
		this.metaData=metaData;
		this.resultRows = resultRows;
	}

	public List<PwiReportResultRow> getResultRows() {
		return resultRows;
	}
	
	public void setResultRows(List<PwiReportResultRow> resultRows) {
		this.resultRows = resultRows;
	}
	
	public List<PWiResultSetColMetaData> getMetaData() {
		return metaData;
	}

	public void setMetaData(List<PWiResultSetColMetaData> metaData) {
		this.metaData = metaData;
	}

	
	public void sort() {
		this.rowcounter = 0;
		this.row = null;
		final int numCols = this.getColumnCount();
	
		Comparator<ArrayList<String>> eachColCaseInsensitiveOrder =
			new Comparator<ArrayList<String>>() {
			public int compare(ArrayList<String> one, ArrayList<String> two) {
				for (int col = 0; col < numCols; col++) {
					int comp = String.CASE_INSENSITIVE_ORDER.compare(
							one.get(col), two.get(col));
					if (comp != 0) {
						return comp;
					}
				} // end for
				return 0; // all columns are equal
			}
	
			public boolean equals(Object object) { return false; }
			public int hashCode() { return numCols; }
		};
	
		//Collections.sort(data.get(rowcounter).getVals(), eachColCaseInsensitiveOrder);
	}

	// ======================================================================
	// Methods for accessing results by column index and name
	// ======================================================================
	/**
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param colName
	 *            the SQL name of the column
	 * @return the column value; if the value is SQL <code>NULL</code>, the
	 *         value returned is <code>""</code> (the empty string)
	 * @SQLException is not thrown, because no database access error occurs
	 * @UnsupportedOperationException by <code>PWiAbstractResultSet</code> for
	 *            methods not implemented by <code>PWiResultSet</code>
	 */
	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>String</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	
	// TODO pH 2013.01: needed? test custom executors
	// pH 2013.01: per code review, this should be safe to omit; however,
	// we may still wish to test
	private static void checkNulls(ArrayList<String> row) {
		for(int i = 0; i < row.size(); i++) {
			if (row.get(i) == null) {
				row.set(i, "");
				//logger.("column " + i, new NullPointerException());
			}
		}
	}

	/**
	 * Overrides all data and metadata
	 * @param rowMaps 
	 * 
	 * @param data is an ArrayList of complete rows of data. It is the
	 *              responsibility of the client to ensure that each row in
	 *              <code>data</code> is complete and contains no null values.
	 * @param htColIdxByName allows column indices to be found by column name.
	 * @param htColMdByIdx contains metadata for each column
	 */
	public void setData(
				HashMap<String, Integer> htColIdxByNameIn,
				HashMap<Integer, PWiResultSetColMetaData> htColMdByIdxIn, List<HashMap<String, String>> rowMaps) {
		/*for (PwiReportResultRow rowIn : dataIn) {
			checkNulls(rowIn.getVals());
		}*/
		//this.data = dataIn;
		this.htColMdByIdx = htColMdByIdxIn;
		this.htColIdxByName = htColIdxByNameIn;
		this.valMap=rowMaps;
	}
	
	public void setData(
			HashMap<String, Integer> htColIdxByNameIn,
			HashMap<Integer, PWiResultSetColMetaData> htColMdByIdxIn, List<HashMap<String, String>> rowMaps,List<PwiReportResultRow> dataIn) {
	/*for (PwiReportResultRow rowIn : dataIn) {
		checkNulls((ArrayList<String>) rowIn.getVals());
	}*/
	this.data = dataIn;
	this.htColMdByIdx = htColMdByIdxIn;
	this.htColIdxByName = htColIdxByNameIn;
	this.valMap=rowMaps;
}

	/**
	 * adds one row of data
	 * 
	 * @param row
	 *            is the complete row of data in the form of a ArrayList.
	 *            It is the responsibility of the client to ensure that row
	 *            is complete and there are no null values in row.
	 */
	public void addRow(ArrayList<String> rowIn) {
		checkNulls(rowIn);
		data.get(0).setVals(rowIn);
	}

	/**
	 * Clears the <code>PWiResultSet</code> instance.
	 */
	public void close() {
		this.data = null;
		this.row = null;
		this.htColMdByIdx = null;
		this.htColIdxByName = null;
	}

	public boolean wasNull() {
		return false;
	}

	/**
	 * returns the number of rows fetched from database and stored in this
	 * <code>PWiResultSet</code>
	 */
	public int size() {
		return data.size();
	}

	//==========================================================================
	// The methods below implement java.sql.ResultSetMetaData.
	//==========================================================================
	
	/**
	 * Returns the number of columns in this <code>PWiResultSet</code> object.
	 * 
	 * @return the number of columns
	 */
	public int getColumnCount() {
		return htColMdByIdx.size();
	}

	/**
	 * <p>
	 * Returns the fully-qualified name of the Java class whose instances are
	 * manufactured if the method <code>PWiResultSet.getObject</code> is called
	 * to retrieve a value from the column. <code>PWiResultSet.getObject</code>
	 * may return a subclass of the class returned by this method.
	 * 
	 * @return the fully-qualified name of the class in the Java programming
	 *         language that would be used by the method
	 *         <code>PWiResultSet.getObject</code> to retrieve the value in the
	 *         specified column. This is the class name used for custom mapping.
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnClassName(int colindex) {
		return getColumnMetaData(colindex).colclassname;
	}

	/**
	 * Get the designated column's number of decimal digits.
	 * 
	 * @return precision
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public int getPrecision(int colindex) {
		return getColumnMetaData(colindex).precision;
	}

	/**
	 * Gets the designated column's number of digits to right of the decimal
	 * point.
	 * 
	 * @return scale
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public int getScale(int colindex) {
		return getColumnMetaData(colindex).scale;
	}

	/**
	 * Get the designated column's table's schema.
	 * 
	 * @return schema name or "" if not applicable
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getSchemaName(int colindex) {
		return getColumnMetaData(colindex).schema;
	}

	/**
	 * Gets the designated column's table name.
	 * 
	 * @return table name or "" if not applicable
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getTableName(int colindex) {
		return getColumnMetaData(colindex).table;
	}

	/**
	 * Indicates whether the designated column is a cash value.
	 * 
	 * @return <code>true</code> if so; <code>false</code> otherwise
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public boolean isCurrency(int colindex) {
		return getColumnMetaData(colindex).iscurrency;
	}

	/**
	 * Retrieves the designated column's SQL type.
	 * 
	 * @return SQL type from java.sql.Types
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 * @see java.sql.Types
	 */
	public int getColumnType(int colindex) {
		return getColumnMetaData(colindex).coltype;
	}

	/**
	 * Retrieves the designated column's database-specific type name.
	 * 
	 * @return type name used by the database. If the column type is a
	 *         user-defined type, then a fully-qualified type name is returned.
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnTypeName(int colindex) {
		return getColumnMetaData(colindex).coltypename;
	}

	/**
	 * Get the designated column's name.
	 * 
	 * @param column
	 *            the first column is 1, the second is 2, ...
	 * @return column name
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnName(int colindex) {
		return getColumnMetaData(colindex).colname;
	}
	
	/**
	 * Get the designated column's Label.
	 * 
	 * @param column
	 *            the first column is 1, the second is 2, ...
	 * @return column Label
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnLabel(int colindex) {
		return getColumnMetaData(colindex).collabel;
	}

	/**
	 * Get the designated column's Catalog Name.
	 * 
	 * @param column
	 *            the first column is 1, the second is 2, ...
	 * @return column the name of the catalog for the table in which the given
	 *         column appears or "" if not applicable
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getCatalogName(int colindex) {
		return getColumnMetaData(colindex).catalogname;
	}

	/**
	 * gets the Row Cache column name for the given index
	 * 
	 * @param colIndex
	 *            is the index of the column
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnHeading(int colindex) {
		return getColumnMetaData(colindex).colheading;
	}
	
	/**
	 * @param colindex - index of the column
	 * @return metadata about the column
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public PWiResultSetColMetaData getColumnMetaData(int colindex) {
		PWiResultSetColMetaData prscmd = htColMdByIdx.get(Integer.valueOf(colindex));
		if (prscmd == null) {
			throw new IndexOutOfBoundsException(new StringBuffer()
					.append("Invalid column index ")
					.append(colindex).toString());
		}
		return prscmd;
	}

	/**
	 * sets the Column Headings
	 * 
	 * @param colindex
	 *            is the index of the column
	 * @param colHeading
	 *            is the heading to display within the table
	 */
	public void setColumnHeading(int colindex, String colHeading) {
		if (getColumnMetaData(colindex) != null)
			getColumnMetaData(colindex).colheading = colHeading;
		else {
			PWiResultSetColMetaData PWirscmd_tmp = new PWiResultSetColMetaData();
			PWirscmd_tmp.colheading = colHeading;
			htColMdByIdx.put(Integer.valueOf(colindex), PWirscmd_tmp);
		}
	}

	public void setColumnNames(ArrayList<String> selectColumns)
			throws SQLException {
		if (htColIdxByName.size() > 0) {
			throw new SQLException("ResultSetMetaData cannot be overridden.");
		}

		for (int i = 1; i <= selectColumns.size(); i++) {
			PWiResultSetColMetaData PWirscmd = new PWiResultSetColMetaData();
			PWirscmd.colname = selectColumns.get(i - 1).toUpperCase(Locale.US);
			htColIdxByName.put(PWirscmd.colname, Integer.valueOf(i));
			htColMdByIdx.put(Integer.valueOf(i), PWirscmd);
		}
	}

	
	public boolean isSigned(int column) {
		return false;
	}

	public boolean isReadOnly(int column) {
		return false;
	}

	public boolean isWritable(int column) {
		return false;
	}

	public boolean isDefinitelyWritable(int column) {
		return false;
	}

	public boolean isAutoIncrement(int column) {
		return false;
	}

	public boolean isCaseSensitive(int column) {
		return false;
	}

	public boolean isSearchable(int column) {
		return false;
	}

	public int getColumnDisplaySize(int column) {
		return 10; // the display size of all columns in GEAEResultSet is 10.
	}

	public String getExecutedQry() {
		return executedQry;
	}

	public void setExecutedQry(String executedQry) {
		this.executedQry = executedQry;
	}

	public List<String> getParams() {
		return params;
	}

	public void setParams(List<String> params) {
		this.params = params;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public List<PwiReportResultRow> getData() {
		return data;
	}

	public void setData(List<PwiReportResultRow> data) {
		this.data = data;
	}

	public List<HashMap<String, String>> getValMap() {
		return valMap;
	}

	public void setValMap(List<HashMap<String, String>> valMap) {
		this.valMap = valMap;
	}	
}
