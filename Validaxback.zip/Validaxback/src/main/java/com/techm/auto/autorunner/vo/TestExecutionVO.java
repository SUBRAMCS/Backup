package com.techm.auto.autorunner.vo;

import java.io.Serializable;
import java.util.List;

public class TestExecutionVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<TestCasesVO> listTestCases;

	private boolean resultStat;
	private String dbSourceId;
	private String dbTargetId;

	public List<TestCasesVO> getListTestCases() {
		return listTestCases;
	}

	public void setListTestCases(List<TestCasesVO> listTestCases) {
		this.listTestCases = listTestCases;
	}

	public boolean isResultStat() {
		return resultStat;
	}

	public void setResultStat(boolean resultStat) {
		this.resultStat = resultStat;
	}

    public String getDbSourceId() {
      return dbSourceId;
    }
  
    public void setDbSourceId(String dbSourceId) {
      this.dbSourceId = dbSourceId;
    }
  
    public String getDbTargetId() {
      return dbTargetId;
    }
  
    public void setDbTargetId(String dbTargetId) {
      this.dbTargetId = dbTargetId;
    }
	
}
