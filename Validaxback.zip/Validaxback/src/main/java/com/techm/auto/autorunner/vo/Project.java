package com.techm.auto.autorunner.vo;

public class Project {
	
	private int projectId;
	private String projectname;
	private String projectdesc;
	private String projectowner;
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public String getProjectdesc() {
		return projectdesc;
	}
	public void setProjectdesc(String projectdesc) {
		this.projectdesc = projectdesc;
	}
	public String getProjectowner() {
		return projectowner;
	}
	public void setProjectowner(String projectowner) {
		this.projectowner = projectowner;
	}
	
	

}
