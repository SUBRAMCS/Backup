package com.techm.auto.autorunner.database.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.techm.auto.autorunner.database.DatabaseTemplates;

/**
 * Configuration file to get appropriate template for database connection
 * */
@Component
public class DatabaseTemplatesImpl implements DatabaseTemplates {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public enum type {
			ORACLE, TERADATA
	}
	
	@Autowired
	@Qualifier("jdbcOrads")
	JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("jdbcTerads")
	JdbcTemplate jdbcTemplateTr;
	
	@Autowired
	@Qualifier("jdbcRPLMDs")
	JdbcTemplate jdbcTemplateRPLM;
	
	@Autowired
	@Qualifier("jdbcPLMRDs")
	JdbcTemplate jdbcTemplatePLMR;
	
	@Autowired
	@Qualifier("jdbcSQLServDs")
	private JdbcTemplate jdbcTemplateSQLServ;
	
	@Autowired
	@Qualifier("jdbcRPLMDs")
	private JdbcTemplate jdbcTemplateRplmOrcl;
	
	/*
	 * return appropriate data source
	 * */
	@Override
	public JdbcTemplate getDatasourceTemplate(String dsn) {
		logger.debug("Request received for Datasource template");
		
		JdbcTemplate JdbcTemplateFinal ;
		 switch(dsn){  
		    case "pwi" : JdbcTemplateFinal = jdbcTemplate;break;  
		    case "plmrterads" : JdbcTemplateFinal = jdbcTemplateTr;break;  
		    case "plmrperson" : JdbcTemplateFinal = jdbcTemplatePLMR;break;  
		    case "dsp" : JdbcTemplateFinal = jdbcTemplateSQLServ;break;  
		    case "rplmds" : JdbcTemplateFinal = jdbcTemplateRplmOrcl;break; 
		    default: JdbcTemplateFinal = jdbcTemplate;;  
		    }
		/*if(dsn.equalsIgnoreCase("pwi"))
			return jdbcTemplate;
		else if(dsn.equalsIgnoreCase("plmrterads"))
			return jdbcTemplateTr;
		else if(dsn.equalsIgnoreCase("rplmqa"))
			return jdbcTemplateRPLM;
		else if(dsn.equalsIgnoreCase("plmrperson"))
			return jdbcTemplatePLMR;*/
		
		return JdbcTemplateFinal;
	}
	
	/*
	 * return template type
	 * */
	@Override
	public String getDatasourceTemplateType(String dsn) {
		logger.debug("Request received for Datasource template type");
		
		if(dsn.equalsIgnoreCase("pwi"))
			return type.ORACLE.toString();
		else if(dsn.equalsIgnoreCase("plmrterads"))
			return type.TERADATA.toString();
		else if(dsn.equalsIgnoreCase("rplmqa"))
			return type.ORACLE.toString();
		else if(dsn.equalsIgnoreCase("plmrperson"))
			return type.ORACLE.toString();
		
		return type.ORACLE.toString();
	}

}
