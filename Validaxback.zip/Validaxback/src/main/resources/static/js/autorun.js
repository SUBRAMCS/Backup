var app = angular.module('tcapp', [ 'angularTreeview' ]);
app.controller("tcController", [
    '$scope',
    '$http',
    
    function($scope, $http) {
      $scope.init = function() {
  
        $scope.loaderds=false; 
        $scope.showAddDSName=true;
        $scope.showDSBTTN12=false;
        $scope.showSaveBtn11=false;
        $scope.showAddTestCaseName =false;
        $scope.loader =true;
        $scope.loader11 =true;
        $scope.successsMsg=false;
        $scope.prjSelected=false;
        
        $scope.testconnection=true;
        $scope.successsMsgmodal=false;
        $scope.alertMsg='';
        $scope.alertMsgmodal ='';
        $scope.showAddProjectName=true;
        $scope.showSaveBtn=false;
        $scope.getUserProjects();
        $scope.oraDbList=[];
        $scope.sqlDbList=[];
        $scope.teraDbList=[];
        
        $scope.key='';
        $scope.val='';
        $scope.checked='';
        $scope.dsType='';
        $scope.dsHost='';
        $scope.dsPort='';
        $scope.dsService='';
        $scope.dsServiceType='';
        $scope.dsUserName='';
        $scope.dsPassword='';
        
        $scope.testDbSource='';
        $scope.testDbTarget='';
        $scope.flag =false;
        $scope.selectedConnection='';
        
        $http.get('http://localhost:1234/getDataSources', {
          params : {
          },
        }).then(function(response) {
          $scope.srcNames = response.data;
          console.log("detail--" + JSON.stringify($scope.srcNames));
          
          var oraDbList = [];
          var sqlDbList = [];
          var teraDbList = [];
          angular.forEach($scope.srcNames, function(value, key){
            
            if(value.dsType=='oracle')
            {
              oraDbList.push(value);
            }
            else if(value.dsType=='sqlserver')
            {
              sqlDbList.push(value);
            }
            else if(value.dsType=='teradata')
            {
              teraDbList.push(value);
            }

            });
          
          $scope.oraDbList=oraDbList;
          $scope.sqlDbList=sqlDbList;
          $scope.teraDbList=teraDbList;

        });
      };
      
      
        $scope.GetValue =function(index,dsDtl) { 
        
        if(index===1){
          $scope.testDbDSOne =  dsDtl;
                   
        }
        else{
          $scope.testDbDSTwo =  dsDtl;
        }
                
        };
       
      $scope.editTestCase=function(tstCaseNm,editTestCase){
        
        var testcasesbackup=$scope.testCases11;
        angular.forEach(testcasesbackup, function(value, key){
          
          if($scope.testCases11[key].testCaseName==tstCaseNm){
            $scope.testCases11[key].editTestCase = !editTestCase;
          }
          
        });
    
      };
      $scope.selectedDB=function(dbDtl){
        
        //alert(dbDtl.dsType);
        $scope.key=dbDtl.key;
        $scope.dsName=dbDtl.val;
        $scope.dsType=dbDtl.dsType;
        $scope.hostname=dbDtl.dsHost;
        $scope.portno=dbDtl.dsPort;
        $scope.service=dbDtl.dsService;
        $scope.serviceType=dbDtl.dsServiceType;
        $scope.dsUserName=dbDtl.dsUserName;
        $scope.dsPassword=dbDtl.dsPassword;
        
        if(dbDtl.dsType=='oracle'){
          $('#myModalNewOraDs').modal("show");
        }else if (dbDtl.dsType=='sqlserver'){
          $('#myModalNewSqlServDs').modal("show");
        }else{
          $('#myModalNewTeraDs').modal("show");
        }
        
      };
      $scope.disableMsg=function(){
         $scope.alertMsgmodal ='';
        
      };
      
      $scope.callAddDSModal=function(modal){
        $scope.alertMsgmodal ='';
        
        if(modal=='oracle'){
         // $scope.portname11='1521';
          $('#myModalDs11').modal("show");
        }else if (modal=='sqlserv'){
         // $scope.portname11='3433';
          $('#myModalDs12').modal("show");
        }else{
         // $scope.portname11='1025';
          $('#myModalDs13').modal("show");
        }
               $scope.key='';
               $scope.dsType11='';
               $scope.dsName11='';
               $scope.hostname11='';
               $scope.portname11='';
               $scope.serviceType11='';
               $scope.service11='';
               $scope.dsUserName11='';
               $scope.dsPassword11='';
       
     };
      
      $scope.emptyplaceholder=function(){
       
        $('.form-control').val('');
                 
      };
      $scope.selectAll=function(flagvalue){
        
        var testcasesbackup=$scope.testCases11;
        angular.forEach(testcasesbackup, function(value, key){
          
            $scope.testCases11[key].testExecFlag = flagvalue;
          
        });
         
     testcasesbackup='';     
      
    }; 
      $scope.TestStatus=function(id,flag){
        
              
      var cases=JSON.stringify($scope.testCases);
      
      var tstCase;
      
       var myAccess = [];

              angular.forEach($scope.testCases, function (value, key) {
               
                if(value.testCaseId==id)
                  {
                  
                  value.testExecFlag=flag;
                  }
              });

        
      };
      
      $scope.editProject=function(project){
        
        $scope.prjId = project.id;
        $scope.prjlabel = project.label;
        
        $("#EditPrj").modal('show');
      }
      
      $scope.EditPrjSave=function(prjname){
        
        jsonObj = [];
        item = {}
        item["projectId"] = $scope.prjId;
        item["projectname"] = prjname;
        
        jsonObj.push(item);

        $http.post('http://localhost:1234/editPrjName',
            JSON.stringify(item)).then(function(response) {
          $scope.loadingStatus = false;
          $scope.init();
          if(response.data)
          {
             var status =response.data;
                       
                       if(status===999)
                         {
                $scope.successsMsg=false;
                           //$scope.alertMsg = "Name already present";
                           $("#alertMsg").html("Project name already present");

              $('#alertModal').modal("show");
                         }
                       else
                         {

                $scope.successsMsg=true;
                           //$scope.alertMsg =  "Project name has been updated";
                           $("#alertMsg").html(" Project name has been updated");
                $('#alertModal').modal("show");
                         }


          }
          else{
            $scope.successMessage = false;
             //$scope.alertMsg = "Error occured while updated";
            $("#alertMsg").html("Error occured while updated");
            $('#alertModal').modal("show");
          }
            $scope.loader =false;


        });
           $("#EditPrj").modal('hide');
      };
      $scope.saveTestCase=function(tcname,description,selQryone,selQrytwo,newTestCase){
                
      if(description==''|| selQryone=='' || selQrytwo==''){
                        $("#alertMsg").html("Please fill all mandatory fields!");                          
                  $('#alertModal').modal("show");
                  return ;
        
        }
      
        if(!isFinite(tcname))
        {
          tcname=1;
        }
        $scope.loader =true;                  
        jsonObj = [];
        item = {};
        item["projectId"] = $scope.prjId;
        item["testCaseName"] = tcname;
        item["description"] = description;
        item["testQryOne"] = selQryone;
        item["testQryTwo"] = selQrytwo;
              
        jsonObj.push(item);
        
        if(newTestCase){
          
                  $http.post('http://localhost:1234/addTestCase', JSON.stringify(item)).then(function (response) {
                    
                        var status =response.data;
                          if(status===999)
                            {
                              $scope.successsMsg=false;
                              $("#alertMsg").html("Name Already Present");
                              $('#alertModal').modal("show");
                            }
                          else
                            {
                              $scope.disabled=false;
                              $scope.successsMsg=true;
                              $("#alertMsg").html("New test case added successfully");
                              $('#alertModal').modal("show");
                            }
                          
                          $scope.myFunc($scope.prjId,$scope.prjlabel);
                      }, function (response) {                          
                                     
                            $scope.msg = "Service not Exists";
                  
                  });
          
        }else{

                $http.post('http://localhost:1234/saveSelectedCases',
                    JSON.stringify(item)).then(function(response) {
                  $scope.loadingStatus = false;
                   $scope.myFunc($scope.prjId,$scope.prjlabel);
                  if(response.data)
                  {
                     var status =response.data;                    
        
                             if(status===999)
                               {
                              
                                  $("#alertMsg").html("Test case for the project is already present");
                                  $('#alertModal').modal("show");
                               }
                             else
                               {
                           
                                  $("#alertMsg").html("Test case name has been updated");
                                  $('#alertModal').modal("show");
                               }
                             $scope.myFunc($scope.prjId,$scope.prjlabel);
                  }
                  else{
                    
                    $("#alertMsg").html("Error occurred while update");
                    $('#alertModal').modal("show");
                  }

                });
        }
        
        $scope.loader =false;      
      };
      
     $scope.removeselect = function() {
       
       var el =document.getElementById("selTestcaseName");
         el.value='';
       var el =document.getElementById("selTestcase");
         el.value='';
       var el =document.getElementById("description");
         el.value='';
       var el =document.getElementById("selQryone");
         el.value='';
       var el =document.getElementById("selQrytwo");
         el.value='';
       
       $("#myModalEdit").modal('hide');
     
     }; 
           
       $scope.closeAlert = function(index) {
           $scope.alerts.splice(index, 1);
         };
      $scope.showBTTN=function(){
        $scope.showAddProjectName=false;
        $scope.showSaveBtn=true;
      };
      $scope.showBTTN11=function(){
        $scope.showAddProjectName=false;
        $scope.showSaveBtn11=true;
      }
      $scope.showBTTN12=function(){
        $scope.showAddDSName=false;
        $scope.showAddProjectName=false;
        $scope.showAddTestCaseName=false;
        $scope.showDSBTTN12=true;;
      }
      $scope.myFunc11 = function(index) {
        
          $scope.testCases11[index].collapse = !$scope.testCases11[index].collapse;
    
        };
        
      $scope.myFunc = function(prjId,prjLabel) {
        
        $scope.prjId=prjId;
        $scope.prjlabel=prjLabel;
        $scope.prjSelected=true;
        $scope.flag =false;
        $scope.showAddTestCaseName =true;
        $http.get('http://localhost:1234/getTestCaseDtls', {
          params : {
            projectid : prjId
          },
        }).then(function(response) {
          
        
          $scope.testCases11 = response.data;  
          console.log(JSON.stringify($scope.testCases11));
          $scope.loader11 =true;
        });
        
   
        document.getElementById('testDbSource').value = '';
        document.getElementById('testDbTarget').value = '';
        document.getElementById('checkAll').checked = false;
        
        };
        


      $scope.getUserProjects = function() {
        
        $scope.loader =false;
        $http.get('http://localhost:1234/getUserProjects', {
          params : {},
        }).then(function(response) {

          $scope.treedata = response.data;
          $scope.selectedprj = response.data[0].id;
          $scope.selectedprjnm = response.data[0].label;
          $scope.getTestCaseDtls();
          console.log("detail--" + response.data);
          
        });
      };
      $scope.getTestCaseDtls = function() {

      $http.get('http://localhost:1234/getTestCaseDtls', {
          params : {

            projectid : $scope.selectedprj
          },
        }).then(function(response) {

          $scope.testCases = response.data;
          if ($scope.testCases == '') {
            $scope.testCases.push({
              'testCaseId' : '',
              'testCaseName' : '',
              'testQryOne' : '',
              'testQryTwo' : '',
              'testDSOne' : '',
              'testDSTwo' : '',
              'testResultFlag' : false,
              'testExecFlag' : false,
              'projectId' : $scope.selectedprj,
              'projectName' : $scope.selectedprjnm
            });
          }
          console.log("detail--" + response.data);
          $scope.loader =false;
        });
      };
      
      $scope.pad = function(nr, n, str) { 
        
        if(!isFinite(nr))
          {
            nr=1;
          }
        
        return Array(n-String(nr).length+1).join(str||'0')+nr;
      }
      
      $scope.AddTestCases = function(){
        
        if($scope.prjId==undefined || $scope.prjId=='')
        {
          $("#alertMsg").html("Please select one project to add test case.");
          $('#alertModal').modal("show");
          return;
        }
      
       angular.forEach($scope.testCases11, function(value, key){
          
          if($scope.testCases11[key].description==''||$scope.testCases11[key].testQryOne==''||$scope.testCases11[key].testQryTwo=='')
          {
            $("#alertMsg").html("Please fill all mandatory fields and save before adding new test case");                          
            $('#alertModal').modal("show");
           return forEach.break();
          }
         
       });

        var items =  $scope.testCases11.map(function(o) { return parseInt(o.testCaseName); });
        var maxCaseNo = Math.max.apply(Math, items);
      
        if(!isFinite(maxCaseNo))
        {
          maxCaseNo = 0;
        }
    
        $scope.name11 = maxCaseNo+1;
        $scope.testCaseNo=($scope.prjlabel.substring(0, 2)+$scope.prjlabel.substring(($scope.prjlabel.length-2), $scope.prjlabel.length)).toUpperCase()+'_'+$scope.pad($scope.name11,3,0);

          //$scope.disabled=true;
          $scope.testCases11.push({
            'testCaseCode' : $scope.testCaseNo,
            'description' : '',
            'testCaseName' : $scope.name11,
            'testQryOne' : '',
            'testQryTwo' : '',
            'testResultFlag' : false,
            'testExecFlag' : false,
            'editTestCase' : false,
            'newTestCase' : true,
            'testResultStats' : '',
            'projectId' : $scope.prjId,
            'projectName' : $scope.prjlabel
          });
        //}
        
        
       // $("#myModal").modal('show');
        
      }

      $scope.addNew = function(a,description11,qryOne,qryTwo) {
        
        if(document.getElementById('testDescription').value==''|| document.getElementById('srcQry').value=='' || document.getElementById('tgtQry').value==''){
                        $("#alertMsg").html("Please fill all mandatory fields!");                          
                  $('#alertModal').modal("show");
                  return ;
        
        }
        
        if(!isFinite(a))
        {
          a=1;
        }
        jsonObj = [];
        item = {}
        $scope.showAddTestCaseName =true;
        $scope.showAddProjectName =true;
        
        item["projectId"] = $scope.prjId;
        item["testCaseName"] = a;
        item["description"] = description11;
        item["testQryOne"] = qryOne;
        item["testQryTwo"] = qryTwo;
        
         $http.post('http://localhost:1234/addTestCase', JSON.stringify(item)).then(function (response) {
                    
                       var status =response.data;
                         
                         if(status===999)
                           {
                             $scope.successsMsg=false;
                             $("#alertMsg").html("Name already present");
                             $('#alertModal').modal("show");
                           }
                         else
                           {
                           $scope.disabled=false;
                $scope.successsMsg=true;
                         //$scope.alertMsg =  "New TestCase added successfully";
                             $("#alertMsg").html("New test case added successfully");
                             $('#alertModal').modal("show");
                           }
                       // }
                     $scope.myFunc($scope.prjId,$scope.prjlabel);
         }, function (response) {                          
                          
                 $scope.msg = "Service not Exists";
    
        });
         $scope.showSaveBtn11=false;
         $scope.myFunc($scope.prjId,$scope.prjlabel);
         $scope.name11 ='';
         $scope.description11 ='';
         $scope.QryONE ='';
         $scope.testDSOne11 ='';
         $scope.QryTWO ='';
         $scope.testDSTwo11 ='';
         $("#myModal").modal('hide');
         
      };
      $scope.saveDS = function(key,dsName,dsType,hostname,portno,service,serviceType,dsUserName,dsPassword) {
                
          if(dsType=='oracle'){
            if(dsName=='' || hostname=='' || portno=='' || dsUserName=='' || dsPassword=='' || service=='' || serviceType==null || serviceType=='' ){
          
                $("#alertMsg").html("Please enter all mandatory fields!");                          
                $('#alertModal').modal("show");
                return ;
            }
          }
          else if(dsType=='sqlserver'){
            if(dsName=='' || hostname=='' || portno=='' || dsUserName=='' || dsPassword==''){
              
              $("#alertMsg").html("Please enter all mandatory fields!");                          
              $('#alertModal').modal("show");
              return ;
            }
          }
          else if(dsType=='teradata'){
            if(dsName=='' || hostname=='' || dsUserName=='' || dsPassword==''){
              
              $("#alertMsg").html("Please enter all mandatory fields!");                          
              $('#alertModal').modal("show");
              return ;
            }
          }
        
          jsonObj = [];
          item = {}
          $scope.showAddTestCaseName =true;
          $scope.showAddProjectName =true;
          $scope.showAddDSName=true;
          item["key"]  = key;
          item["val"] = dsName;
          item["checked"] = true;
          item["dsType"] = dsType;
          item["dsHost"] = hostname;
          item["dsPort"] = portno;
          item["dsService"] = service;
          item["dsServiceType"] = serviceType;
          item["dsUserName"] = dsUserName;
          item["dsPassword"] = dsPassword;
          
          $scope.loaderds=true; 

         $http.post('http://localhost:1234/saveDS', JSON.stringify(item)).then(function (response) {
           $scope.init();
                  
             var status =response.data;
                       
           if(status === 999)
             {
               $scope.successsMsg=false;
               $("#alertMsg").html("Connection name already present");
               $('#alertModal').modal("show");
             }
           else if(status === 998){
             
             $("#alertMsg").html("Please enter valid connection details");
             $('#alertModal').modal("show");
           }
           else
             {
                 $scope.successsMsg=true;
                 $("#alertMsg").html("Connection added successfully");
                 $('#alertModal').modal("show");
                                  
             }
               }, function (response) {
               
                 $scope.msg = "Service not Exists";

             });
         
                 $scope.loaderds=false; 
         
                 $scope.key='';
                 $scope.dsType11='';
                 $scope.dsName11='';
                 $scope.hostname11='';
                 $scope.portname11='';
                 $scope.serviceType11='';
                 $scope.service11='';
                 $scope.dsUserName11='';
                 $scope.dsPassword11='';

                 $("#myModalNewOraDs").modal('hide');
                 $("#myModalNewSqlServDs").modal('hide');
                 $("#myModalNewTeraDs").modal('hide');
                 $("#myModalDs11").modal('hide');
                 $('#myModalDs12').modal("hide");
                 $('#myModalDs13').modal("hide");
                
         
      };
      
      $scope.saveEditDS = function(key,dsName,dsType,hostname,portno,service,serviceType,dsUserName,dsPassword) {
        
        if(dsType=='oracle'){
          if(dsName=='' || hostname=='' || portno=='' || dsUserName=='' || dsPassword=='' || service=='' || serviceType==null || serviceType=='' ){
        
              $("#alertMsg").html("Please enter all mandatory fields!");                          
              $('#alertModal').modal("show");
              return ;
          }
        }
        else if(dsType=='sqlserver'){
          if(dsName=='' || hostname=='' || portno=='' || dsUserName=='' || dsPassword==''){
            
            $("#alertMsg").html("Please enter all mandatory fields!");                          
            $('#alertModal').modal("show");
            return ;
          }
        }
        else if(dsType=='teradata'){
          if(dsName=='' || hostname=='' || dsUserName=='' || dsPassword==''){
            
            $("#alertMsg").html("Please enter all mandatory fields!");                          
            $('#alertModal').modal("show");
            return ;
          }
        }
      
          jsonObj = [];
          item = {}
          $scope.showAddTestCaseName =true;
          $scope.showAddProjectName =true;
          $scope.showAddDSName=true;
          item["key"]  = key;
          item["val"] = dsName;
          item["checked"] = true;
          item["dsType"] = dsType;
          item["dsHost"] = hostname;
          item["dsPort"] = portno;
          item["dsService"] = service;
          item["dsServiceType"] = serviceType;
          item["dsUserName"] = dsUserName;
          item["dsPassword"] = dsPassword;
          
          $scope.loaderds=true; 
         $http.post('http://localhost:1234/saveDS', JSON.stringify(item)).then(function (response) {
           $scope.init();
                  
                       var status =response.data;
                       
            if(status === 999)
             {
               $scope.successsMsg=false;
               $("#alertMsg").html("Connection name already present");
               $('#alertModal').modal("show");
             }
           else if(status === 998){
               
               $("#alertMsg").html("Please enter valid connection details");
               $('#alertModal').modal("show");
             }
           else
             {
                 $("#alertMsg").html("DataSource updated successfully");
                 $('#alertModal').modal("show");
                 $scope.successsMsg=true;
             }
               }, function (response) {
               
                 $scope.msg = "Service not Exists";

             });
                 
                 $scope.loaderds=false; 
                 $scope.key='';
                 $scope.val='';
                 $scope.checked='';
                 $scope.dsType='';
                 $scope.dsHost='';
                 $scope.dsPort='';
                 $scope.dsService='';
                 $scope.dsServiceType='';
                 $scope.dsUserName='';
                 $scope.dsPassword='';
                 
                 $("#myModalNewOraDs").modal('hide');
                 $("#myModalNewSqlServDs").modal('hide');
                 $("#myModalNewTeraDs").modal('hide');
                 $("#myModalNewOraDs").modal('hide');
                 $("#myModalNewSqlServDs").modal('hide');
                 $("#myModalNewTeraDs").modal('hide');
                 
                 

      };
       $scope.testDS = function(key,dsName,dsType,hostname,portno,service,serviceType,dsUserName,dsPassword) {
          
         if(dsType=='oracle'){
           if(dsName=='' || hostname=='' || portno=='' || dsUserName=='' || dsPassword=='' || service=='' || serviceType==null || serviceType=='' ){
         
               $("#alertMsg").html("Please enter all mandatory fields!");                          
               $('#alertModal').modal("show");
               return ;
           }
         }
         else if(dsType=='sqlserver'){
           if(dsName=='' || hostname=='' || portno=='' || dsUserName=='' || dsPassword==''){
             
             $("#alertMsg").html("Please enter all mandatory fields!");                          
             $('#alertModal').modal("show");
             return ;
           }
         }
         else if(dsType=='teradata'){
           if(dsName=='' || hostname=='' || dsUserName=='' || dsPassword==''){
             
             $("#alertMsg").html("Please enter all mandatory fields!");                          
             $('#alertModal').modal("show");
             return ;
           }
         }
         
         $scope.loaderds=true; 
        jsonObj = [];
        item = {}
        $scope.showAddTestCaseName =true;
        $scope.showAddProjectName =true;
        $scope.showAddDSName=true;
        item["key"]  = key;
        item["val"] = dsName;
        item["checked"] = true;
        item["dsType"] = dsType;
        item["dsHost"] = hostname;
        item["dsPort"] = portno;
        item["dsService"] = service;
        item["dsServiceType"] = serviceType;
        item["dsUserName"] = dsUserName;
        item["dsPassword"] = dsPassword;

         $http.post('http://localhost:1234/testDS', JSON.stringify(item)).then(function (response) {
        
                       var status =response.data;
                    
                         if(status === 999)
                           {
                             $scope.successsMsgmodal=false;
                             $scope.alertMsgmodal = "Error in connection";
                             $scope.testconnection=true;
                             $scope.loaderds=false; 
                           }
                         else
                           {
                             $scope.successsMsgmodal=true;
                             $scope.alertMsgmodal =  "Successfully connected";
                             $scope.testconnection=false;
                             $scope.loaderds=false; 
                           }

                         }, function (response) {
                           
                           $scope.loaderds=false; 
                         $scope.msg = "Service not Exists";
    
            });
        
         $scope.loader =false;
         $scope.showDSBTTN12=false;
         
      };
      
      $scope.testEditDS = function(dsName,dsType,hostname,portno,service,serviceType,dsUserName,dsPassword) {
       
        if(dsType=='oracle'){
          if(dsName=='' || hostname=='' || portno=='' || dsUserName=='' || dsPassword=='' || service=='' || serviceType==null || serviceType=='' ){
        
              $("#alertMsg").html("Please enter all mandatory fields!");                          
              $('#alertModal').modal("show");
              return ;
          }
        }
        else if(dsType=='sqlserver'){
          if(dsName=='' || hostname=='' || portno=='' || dsUserName=='' || dsPassword==''){
            
            $("#alertMsg").html("Please enter all mandatory fields!");                          
            $('#alertModal').modal("show");
            return ;
          }
        }
        else if(dsType=='teradata'){
          if(dsName=='' || hostname=='' || dsUserName=='' || dsPassword==''){
            
            $("#alertMsg").html("Please enter all mandatory fields!");                          
            $('#alertModal').modal("show");
            return ;
          }
        }
               
      $scope.loaderds=true; 
      jsonObj = [];
      item = {}
      $scope.showAddTestCaseName =true;
      $scope.showAddProjectName =true;
      $scope.showAddDSName=true;
      item["val"] = dsName;
      item["checked"] = true;
      item["dsType"] = dsType;
      item["dsHost"] = hostname;
      item["dsPort"] = portno;
      item["dsService"] = service;
      item["dsServiceType"] = serviceType;
      item["dsUserName"] = dsUserName;
      item["dsPassword"] = dsPassword;
      
      $http.post('http://localhost:1234/testDS', JSON.stringify(item)).then(function (response) {
    
                   var status =response.data;
                
                     if(status === 999)
                       {
                         $scope.successsMsgmodal=false;
                         $scope.alertMsgmodal = "Error in connection";
                         $scope.testconnection=true;
                         $scope.loaderds=false; 
                       }
                     else
                       {
                         $scope.successsMsgmodal=true;
                         $scope.alertMsgmodal =  "Successfully connected";
                         $scope.testconnection=false;
                         $scope.loaderds=false; 
                       }

                     }, function (response) {
                       
                       $scope.loaderds=false; 
                     $scope.msg = "Service not Exists";

        });
    
     $scope.loader =false;
     $scope.showDSBTTN12=false;
     
  }; 
      $scope.confirmDeleteDB = function(src){

         $scope.key=src.key;
         $scope.dsName=src.val;
         $("#confirmDeleteDB").modal('show');
                           
       };
                           
      $scope.confirmDeleteDbModal = function(){

         
         $("#confirmDeleteDB").modal('show');
                           
         };
      
       $scope.deleteDB= function () {
            
            jsonObj = [];
            item = {};
            item["dsid"] =$scope.key; 


            jsonObj.push(item);
            
          $http.post('http://localhost:1234/deleteDB', JSON.stringify(item)).then(function (response) {
                           if (response.data)
                             {
                             $scope.init();
                             $("#alertMsg").html($scope.dsName +" database deleted succesfully");
                             $('#alertModal').modal("show");
                            // $scope.successsMsg=true;
                            // $scope.alertMsg =  $scope.dsName +" Database deleted Succesfully";
                             }
                           // $scope.getUserProjects();
                             }, function (response) {
                               
                              
                             $scope.msg = "Service not Exists";
        
                             });
          
                           };
                           

        $scope.confirmRemoveRow = function(testCaseId){
             
          $scope.testCaseId = testCaseId;
          //document.getElementById("testCaseId").value=testCaseId;
          $("#confirmDeleteCase").modal('show');
                   
        };

      $scope.removeRow = function(a) {
        
        jsonObj = [];
        item = {}
        item["projectId"] = $scope.prjId;
        item["testCaseName"] = a;
        $http.post('http://localhost:1234/deleteTestCase', JSON.stringify(item)).then(function (response) {
          $scope.myFunc($scope.prjId,$scope.prjlabel);
                   if (response.data)
                 {
                   $scope.successsMsg=true;
                  $("#alertMsg").html("Test case deleted succesfully");
                  $('#alertModal').modal("show");
                  // $scope.alertMsg = "TestCase Deleted Succesfully";
                   $scope.myFunc($scope.prjId,$scope.prjlabel);
                 }
                    $scope.getUserProjects();
                         }, function (response) {
                           
                          
                         $scope.msg = "Service not Exists";
    
                         });
      };
      
      
       $scope.removeAlert = function(){
          $scope.successsMsg=false;
         
          
          };
      
      $scope.Export = function(obj) {
        
        $scope.loader =true;
        $http.post('http://localhost:1234/writeExcel',
                JSON.stringify(obj.case)).then(function(response) {
              
              var a=0;
            
              if(response.data)
                {
                
              $scope.successsMsg=true; 
              $scope.loader =false;
                            
              //$scope.alertMsg = "file created";
              
               $("#alertMsg").html("File created successfully");
                $('#alertModal').modal("show");
              
                }
              else
                {
                $scope.successsMsg=false;
                $scope.loader =false;
                //$scope.alertMsg = "Error in Query";
                
                 $("#alertMsg").html("There is an error while executing the query");
                $('#alertModal').modal("show");
                }
              
          
        });
      };
      
      $scope.exportAll = function() {
              
        $http.post('http://localhost:1234/exportTestCases', JSON.stringify($scope.testCases11)).then(function(response) {
          
              var anchor = angular.element('<a/>');
              anchor.attr({
                  href: 'data:application/octet-stream;base64,' + response.data,
                  target: '_self',
                  download: "Test_Case_Result.xlsx"});
              
              angular.element(document.body).append(anchor);
              anchor[0].click();
          });     
        
      };
      
      $scope.confirmRemoveAllRow = function(){
        
        //$scope.testCaseId = testCaseId;
        //document.getElementById("testCaseId").value=testCaseId;
        $("#confirmDeleteAllCase").modal('show');
                 
      };
      
      $scope.deleteAll = function() {
                
        $("#confirmDeleteAllCase").modal('hide');
        var counter =0 ;
               
        angular.forEach($scope.testCases11, function(value, key){
          
          if($scope.testCases11[key].testExecFlag)
          {
            counter++;
          }

        });
        
        if(counter==0){
          $("#alertMsg").html("Please select test cases to delete");
          $('#alertModal').modal("show");
          return;
        }
        
        $http.post('http://localhost:1234/deleteAllTestCases', JSON.stringify($scope.testCases11)).then(function(response) {
            
            if(response.data)
            {

              $("#alertMsg").html("Deleted test cases successfully");
              $('#alertModal').modal("show");
              $scope.myFunc($scope.prjId,$scope.prjlabel);
  
            }
          else
            {
             $("#alertMsg").html("There is an error while deleting the test cases");
             $('#alertModal').modal("show");
            }
 
          });    
        
        $scope.getUserProjects();
        
      };
      
      $scope.resetAllCase = function() {
        
        angular.forEach($scope.testCases11, function(value, key){
          
          $scope.testCases11[key].testExecFlag = false;
          $scope.testCases11[key].testResultStats = '';
          $scope.testCases11[key].testResultFlag = '';
          document.getElementById('checkAll').checked = false;
         
        });
        
      };

      $scope.startTesting = function(obj) {
               
        $scope.selectedTestCaseObj = obj;
              
        if(obj.case.description==''|| obj.case.selQryone=='' || obj.case.selQrytwo==''){
          $("#alertMsg").html("Please fill all mandatory fields!");                          
          $('#alertModal').modal("show");
          return ;

        }
        
        if(document.getElementById('testDbSource').value=='' || document.getElementById('testDbTarget').value=='')
        {                       
              $('#confirmExecutetestCase').modal("show");
    
        }else{
          $scope.startTestingWthConfirm(obj)
        }
      }
     
      $scope.startTestingWthConfirm = function(obj) {  
               
        $scope.loader =true;
        var testCaseVo = obj.case;
        var dbSourceId = document.getElementById('testDbSource').value;
        var dbTargetId = document.getElementById('testDbTarget').value;
        
        obj.case.testDSOne = document.getElementById('testDbSource').value;
        obj.case.testDSTwo = document.getElementById('testDbTarget').value;
       
        
       $http.post('http://localhost:1234/compareQuery',obj.case).then(function(response) {
              
              var a=0;
              
              if(response.data)
              {
                
                $scope.successsMsg=true;
                $("#alertMsg").html("TestCase executed successfully.");
                $('#alertModal').modal("show");
                            
                angular.forEach($scope.testCases11, function(value, key){
                  
                  if(obj.case.testCaseName==value.testCaseName)
                  {
                    $scope.testCases11[key] = response.data;
                    $scope.testCases11[key].testExecFlag = true;
                  }
                  else{
                    
                    $scope.testCases11[key].testExecFlag = false;
                  }
                });
              
                $scope.loader =false;
                a=a+1;
              }
              else
                {
                  $scope.successsMsg=false;
                  $scope.loader =false;
                  //$scope.alertMsg = "Error in Query";
                  $("#alertMsg").html("Error in excuting test case");
                  $('#alertModal').modal("show");
                }
        });
        
        $scope.alertMsg = "";
        console.log(obj);
      };
      
      
      $scope.startTestingForAll = function(tstCase) {
        $scope.loader =true;
      
             var error= JSON.stringify(tstCase.testCaseName);
            $http.post('http://localhost:1234/compareQuery',
            JSON.stringify(tstCase)).then(function(response) {
              
              if(response.data)
                {
                  $scope.successsMsg=true; 
                  $("#alertMsg").html("Test cases executed successfully.");
                  $('#alertModal').modal("show");
                                    
                  angular.forEach($scope.testCases11, function(value, key){
                    
                    if(tstCase.testCaseName==value.testCaseName)
                    {
                      $scope.testCases11[key].testResultFlag = response.data.testResultFlag;
                      $scope.testCases11[key].testExecFlag = true;
                    }
                    else{
                      
                      $scope.testCases11[key].testExecFlag = false;
                    }
                  }); 
                  $scope.loader =false;
                }
              else
                {
                  $scope.successsMsg=false;
                  $scope.loader =false;
                  //$scope.alertMsg = "Error in Query";
                  $("#alertMsg").html("Error in excuting test case");
                  $('#alertModal').modal("show");
                }
        });
        
        $scope.alertMsg = "";

      };
      
      $scope.executeAllCase = function(obj) {
           
        if(document.getElementById('testDbSource').value=='' || document.getElementById('testDbTarget').value=='')
        {                       
              $('#confirmExecuAllCase').modal("show");
    
        }else{
          
          $scope.executeAllCaseConfirm();
        }
      }

      $scope.executeAllCaseConfirm = function() {
        
        var counter = 0;
        angular.forEach($scope.testCases11, function(value, key){
          
          if($scope.testCases11[key].testExecFlag)
          {
            counter++;
          }

        });
        
        if(counter==0){
          $("#alertMsg").html("Please select test cases to execute");
          $('#alertModal').modal("show");
          return;
        }

        $scope.loader =true;
      
        var data = new FormData();
        data.append('listTestCases', $scope.testCases11);
        data.append('dbSourceId',document.getElementById('testDbSource').value);
        data.append('dbTargetId',document.getElementById('testDbTarget').value);

        var testcasesbackup=$scope.testCases11;
        angular.forEach(testcasesbackup, function(value, key){
          
            $scope.testCases11[key].testDSOne = document.getElementById('testDbSource').value;
            $scope.testCases11[key].testDSTwo = document.getElementById('testDbTarget').value;
          
        });
        

        $http.post('http://localhost:1234/compareQueries',$scope.testCases11).then(function(response) {
                  console.log(JSON.stringify(response.data));
              if(response.data)
                {
                  $scope.successsMsg=true;                 
                  $scope.testCases11 = response.data; 
                  $scope.loader =false;
                }
              else
                {
                 // $scope.successsMsg=false;
                  $scope.loader =false;
                  //$scope.alertMsg = "Error in Query";
                  $("#alertMsg").html("Error in excuting test case");
                  $('#alertModal').modal("show");
                }
        });
        
        $scope.alertMsg = "";
 
      };
    
     $scope.saveSelectedCases = function(tcid,tcname,tcqryone,tcqrytwo,tcdsone,tcdstwo) {
        
        $scope.loader =true;                  
        jsonObj = [];
        item = {}
        item["testCaseId"] = tcid;
        item["testCaseName"] = tcname;
        item["testQryOne"] = tcqryone;
        item["testQryTwo"] = tcqrytwo;
        item["testDSOne"] = tcdsone;
        item["testDSTwo"] = tcdstwo;
        jsonObj.push(item);

        $http.post('http://localhost:1234/saveSelectedCases',
            JSON.stringify(item)).then(function(response) {
          $scope.loadingStatus = false;
          
          if(parseInt(response.data)>0)
          {
            $scope.successsMsg=true;

           // $scope.alertMsg = tcname + " has been updated succesfully";
            $("#alertMsg").html(tcname + " has been updated succesfully");
            $('#alertModal').modal("show");
          
          }
          else{
            $scope.successMessage = false;
            // $scope.alertMsg = "Error occured while updated";
             $("#alertMsg").html("Error occurred while updated");
             $('#alertModal').modal("show");
          }
            $scope.loader =false;
          
        });

      }
      $scope.savePrj = function (name) {
        
        //alert(name)
        if(name=='')
        {
          $("#alertMsg").html("Please enter valid Project Name");
          $('#alertModal').modal("show");
        }
        
        $scope.showAddProjectName=true;
        $scope.showSaveBtn=false;
        
        $scope.msg = "test";
        jsonObj = [];
        item = {}
        
        item["projectname"] = name;
       
        jsonObj.push(item);
        
        $http.post('http://localhost:1234/saveNewPrj', JSON.stringify(item)).then(function (response) {
             if (response.data)
             {
                 var status =response.data;
               if(status===999)
               {
                   $scope.successsMsg=false;
                     //$scope.alertMsg = " Name already present";
                     $("#alertMsg").html("Project name already present");
                     $('#alertModal').modal("show");
               }
                 else
               {
          $scope.successsMsg=true;
                // $scope.alertMsg = "\tNew project Added Succesfully";
                  $("#alertMsg").html("New project added successfully");
          $('#alertModal').modal("show");
               }
             }
             
             $scope.getUserProjects();
             
             }, function (response) {
               
              
             $scope.msg = "Service not Exists";

             });
            $("#myModalPrj").modal('hide');
           };
                       
                             
           $scope.confirmDeletePrj = function(project) {
                /*if (confirm("Do you want to Delete "+$scope.prjlabel+" project ?")) {
                      $scope.deletePrj();
                 }*/
             $scope.prjId = project.id;
             $scope.prjlabel = project.label;
             $("#confirmDeletePrj").modal('show'); 
             
            };
                                         
            $scope.deletePrj = function () {
              
                $scope.showAddProjectName=true;
                $scope.showSaveBtn=false;
                jsonObj = [];
                item = {}
                item["projectId"] = $scope.prjId;
                item["projectname"] = $scope.prjlabel;
                jsonObj.push(item);
                $http.post('http://localhost:1234/deletePrj', JSON.stringify(item)).then(function (response) {
                    
                    if (response.data)
                     {
            $scope.successsMsg=true;
                      // $scope.alertMsg =  $scope.prjlabel+" project deleted Succesfully";
            $("#alertMsg").html($scope.prjlabel+" project deleted Succesfully");
            $('#alertModal').modal("show");
                     }
                       $scope.getUserProjects();
                }, function (response) {
                      $scope.msg = "Service not Exists";
                 });
           };
                                                       
                                  
      $scope.exportAction = function(option) {
        switch (option) {
        case 'pdf':
          $scope.$broadcast('export-pdf', {});
          break;
        case 'excel':
          $scope.$broadcast('export-excel', {});
          break;
        case 'doc':
          $scope.$broadcast('export-doc', {});
          break;
        case 'csv':
          $scope.$broadcast('export-csv', {});
          break;
        default:
          console.log('no event caught');
        }
      }

    
    $scope.file = '';
    $scope.changedVal='';
    $scope.downloadTemplate1=function(){
 
      $http.get('http://localhost:1234/download', {
        params : {
          name : 'testCase.xlsx'
        },responsetype: 'arraybuffer',
      }).then(function(resp) {
        
            var serverData = new Blob([resp.data], {type: 'application/octet-stream'});
            saveAs(serverData, resp.headers()['content-disposition']);  
      });
    }

      $scope.downloadTemplate=function(){
        
        $http.get('http://localhost:1234/download', {
          params : {
            name : 'Test_Case_Template.xlsx'
          },responsetype: 'arraybuffer',
        }).then(function(response) {
            var anchor = angular.element('<a/>');
            anchor.attr({
                href: 'data:application/octet-stream;base64,' + response.data,
                target: '_self',
                download: "Test_Case_Template.xlsx"});
            
            angular.element(document.body).append(anchor);
            anchor[0].click();
        });
      }
      
      $scope.uploadTestCases = function() {
               
        if($scope.prjId==undefined || $scope.prjId=='')
        {
          $("#alertMsg").html("Please select one project to upload the test cases.");
          $('#alertModal').modal("show");
          return;
        }
        angular.element("input[type='file']").val(null);
        $scope.changedVal = false;
        $("#myModalUpload").modal('show');
        
      }

      $scope.uploadFile = function() {
             
        if($scope.file=='')
        {
          $("#alertMsg").html("Please select a file to upload the test cases.");
          $('#alertModal').modal("show");
          return;
        }
        
        
        
          var file = $scope.file;     
          var url = "http://localhost:1234/importTestCases";
          var data = new FormData();
          data.append('file', file);
          data.append('projectid',$scope.prjId);
          data.append('optradio',$scope.changedVal);
 
            var config = {
                transformRequest: angular.identity,
                transformResponse: angular.identity,
              headers : {
                'Content-Type': undefined
                }
            }
          
             $http.post(url, data, config).then(function (response) {

             $scope.myFunc($scope.prjId,$scope.prjlabel);
                $("#myModalUpload").modal('hide');
          //$scope.successsMsg=true;
                //$scope.alertMsg = "Testcases has been uploaded succesfully.";
          $("#alertMsg").html("Test cases has been uploaded successfully.");
          $('#alertModal').modal("show");
           }, function (response) {
            
             $scope.uploadResult=response.data;
           });
       };     
       
      $scope.$watch('abc.currentNode', function(newObj, oldObj) {
        
        $scope.successMessage = false;
        $scope.errorMessage =false;       
        if ($scope.abc && angular.isObject($scope.abc.currentNode)) {
          console.log('Node Selected!!');
          console.log($scope.abc.currentNode);
        }
        
        if(parseInt($scope.abc.currentNode.id)<100){
          angular.forEach($scope.testCases, function(value, key){
      
            if(parseInt($scope.abc.currentNode.id)==parseInt(value.testCaseId))
            {
              $scope.testCases[key].testExecFlag = true;
            }
            else{
              
              $scope.testCases[key].testExecFlag = false;
            }
          });
        }
        else{
          
          $scope.selectedprj = $scope.abc.currentNode.id;
          $scope.selectedprjnm = $scope.abc.currentNode.label;
          $scope.getTestCaseDtls();
        }
        
      }, false);
      
      } ]);


      app.directive('exportTable', function() {
        var link = function($scope, elm, attr) {
          $scope.$on('export-pdf', function(e, d) {
            elm.tableExport({
              type : 'pdf',
              escape : false
            });
          });
          $scope.$on('export-excel', function(e, d) {
            elm.tableExport({
              type : 'excel',
              escape : false
            });
          });
          $scope.$on('export-doc', function(e, d) {
            elm.tableExport({
              type : 'doc',
              escape : false
            });
          });
          $scope.$on('export-csv', function(e, d) {
            elm.tableExport({
              type : 'csv',
              escape : false
            });
          });
        }
        return {
        restrict : 'C',
        link : link
        }
      });

app
.directive(
  'loading',
  function() {
    return {
      restrict : 'E',
      replace : true,
      template : '<div class="loading"><img src="http://www.nasa.gov/multimedia/videogallery/ajax-loader.gif" width="20" height="20" />LOADING...</div>',
      link : function(scope, element, attr) {
        scope.$watch('loading', function(val) {
          if (val)
            $scope.loadingStatus = true;
          else
            $scope.loadingStatus = false;
        });
      }
    }
  });
app.directive('fileModel', [ '$parse', function($parse) {
return {
restrict : 'A',
link : function(scope, element, attrs) {
    var model = $parse(attrs.fileModel);
    var modelSetter = model.assign;

    element.bind('change', function() {
        scope.$apply(function() {
            modelSetter(scope, element[0].files[0]);
        });
    });
}
};
} ]);
