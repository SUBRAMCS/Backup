var app = angular.module('tcapp', [ 'angularTreeview' ]);
app.controller("tcController", [
		'$scope',
		'$http',
		
		function($scope, $http) {
			$scope.init = function() {
				
				// $scope.loadingStatus = true;
				$scope.showAddDSName=true;
				$scope.showDSBTTN12=false;
				$scope.showSaveBtn11=false;
				$scope.showAddTestCaseName =false;
				$scope.loader =true;
				$scope.loader11 =false;
				$scope.successsMsg=false;
				
				$scope.testconnection=true;
				$scope.successsMsgmodal=false;
				$scope.alertMsg='';
				$scope.alertMsgmodal ='';
				$scope.showAddProjectName=true;
				$scope.showSaveBtn=false;
				$scope.getUserProjects();
				$http.get('http://localhost:8080/getDataSources', {
					params : {
					},
				}).then(function(response) {
					$scope.srcNames = response.data;
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});

				/*$http.get('http://localhost:8080/getTestCaseDtls', {
					params : {},
				}).then(function(response) {

					$scope.testCases = response.data;
					if ($scope.testCases == '') {
						$scope.testCases.push({
							'testCaseId' : '',
							'testCaseName' : '',
							'testQryOne' : '',
							'testQryTwo' : '',
							'testDSOne' : '',
							'testDSTwo' : '',
							'testResultFlag' : false,
							'testExecFlag' : false,
							'projectId' : $scope.selectedprj,
							'projectName' : $scope.selectedprjnm
						});
					}
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});*/
				// alert($scope.loadingStatus)
				// $scope.loadingStatus = false;
				// $("#loadingChart1").hide();
			};
			
			/*$scope.showmsg() =function()
			{
				$scope.alertMsgmodal='';
			};*/
			$scope.editTestCase=function(tstCaseId,tstCaseNm){
				$scope.testcaseid=tstCaseId;
				$scope.selTestcase=tstCaseNm;
				// alert(a);
				
			};
			$scope.selectedDB=function(dbDtl){
		
				$scope.key=dbDtl.key;
				$scope.dsName=dbDtl.val;
				$scope.dsType=dbDtl.dsType;
				$scope.hostname=dbDtl.dsHost;
				$scope.portno=dbDtl.dsPort;
				$scope.service=dbDtl.dsService;
				$scope.serviceType=dbDtl.dsServiceType;
				$scope.dsUserName=dbDtl.dsUserName;
				$scope.dsPassword=dbDtl.dsPassword;
				
			};
			
			$scope.EditPrjSave=function(prjname){
				// alert( $scope.prjId);
					            	
				jsonObj = [];
				item = {}
				item["projectId"] = $scope.prjId;
				item["projectname"] = prjname;
				
				jsonObj.push(item);

				$http.post('http://localhost:8080/editPrjName',
						JSON.stringify(item)).then(function(response) {
					$scope.loadingStatus = false;
					$scope.init();
					if(response.data)
					{
						 var status =response.data;
                  	   
                  	   if(status===999)
                  		   {
                  		   $scope.successsMsg=false;
                      	   $scope.alertMsg = "name already present";
                  		   }
                  	   else
                  		   {
                  	   $scope.successsMsg=true;
                  	   $scope.alertMsg =  "Project name has been updated";
                  		   }
						
					 	/* $scope.init(); */
					}
					else{
						$scope.successMessage = false;
						 $scope.alertMsg = "Error occured while updated";
					}
					$scope.loader =false;
					// $scope.testCases = response.data;
					// $scope.response = resp;
				});
			};
			$scope.Edit=function(tcname){
				// alert($scope.testcaseid);

				
				$scope.loader =true;		            	
				jsonObj = [];
				item = {}
				item["testCaseId"] = $scope.testcaseid;
				item["testCaseName"] = tcname;
				item["projectId"] = $scope.prjId;
				jsonObj.push(item);

				$http.post('http://localhost:8080/editTestCaseName',
						JSON.stringify(item)).then(function(response) {
					$scope.loadingStatus = false;
					 $scope.myFunc($scope.prjId,$scope.prjlabel);
					if(response.data)
					{

						 var status =response.data;
                 	   
                 	   if(status===999)
                 		   {
                 		   $scope.successsMsg=false;
                     	   $scope.alertMsg = "name already present";
                 		   }
                 	   else
                 		   {
                 	   $scope.successsMsg=true;
                 	   $scope.alertMsg =  "Test Case name has been updated";
                 		   }
                 	  $scope.myFunc($scope.prjId,$scope.prjlabel);
					 	/* $scope.init(); */
					}
					else{
						$scope.successMessage = false;
						 $scope.alertMsg = "Error occured while updated";
					}
					$scope.loader =false;
					// $scope.testCases = response.data;
					// $scope.response = resp;
				});

				
				console.log(obj);
			
			};
			/*
			 * $scope.decrement = function() { alert(111);
			 * $(document).ready(function(){ $('.open-modal').click(function(){
			 * $('#myModalDs').modal('show'); // show modal });
			 * $('.close-modal').click(function(){
			 * $('#DemoModal').modal('hide'); // hide modal }); }); };
			 */
			
			 $scope.closeAlert = function(index) {
				    $scope.alerts.splice(index, 1);
				  };
			$scope.showBTTN=function(){
				$scope.showAddProjectName=false;
				$scope.showSaveBtn=true;
			};
			$scope.showBTTN11=function(){
				$scope.showAddProjectName=false;
				$scope.showSaveBtn11=true;
			}
			$scope.showBTTN12=function(){
				$scope.showAddDSName=false;
				$scope.showAddProjectName=false;
				$scope.showAddTestCaseName=false;
				$scope.showDSBTTN12=true;;
			}
			$scope.myFunc11 = function(a) {
				var a1=a;
				
				
				
				$http.get('http://localhost:8080/getSpecificTestCasedetails', {
					params : {
						testcaseid : a1
					},
				}).then(function(response) {

					$scope.testCasesDtl = response.data;
					
					if ($scope.testCasesDtl  != '') {
						
						$scope.disabled=false;
						/*$scope.testCasesDtl.push({
							'testCaseId' : '',
							'testCaseName' : '',
							'testQryOne' : '',
							'testQryTwo' : '',
							'testDSOne' : '',
							'testDSTwo' : '',
							'testResultFlag' : false,
							'testExecFlag' : false,
							
						});*/
					}
					
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});
					
		    };
		    
			$scope.myFunc = function(prjId,prjLabel) {
				
				$scope.prjId=prjId;
				$scope.prjlabel=prjLabel;
				$scope.showAddTestCaseName =true;
				$http.get('http://localhost:8080/getTestCaseDtls', {
					params : {
						projectid : prjId
					},
				}).then(function(response) {

					$scope.testCases11 = response.data;
					if ($scope.testCases11 == '') {
						$scope.disabled=true;
						$scope.testCases11.push({
							'testCaseId' : '',
							'testCaseName' : 'Add Test Case',
							'testQryOne' : '',
							'testQryTwo' : '',
							'testDSOne' : '',
							'testDSTwo' : '',
							'testResultFlag' : false,
							'testExecFlag' : false,
							'projectId' : '',
							'projectName' : ''
						});
					}
					else{
						$scope.disabled=false;
					}
					$scope.loader11 =true;
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});
				
		    };
		    
		   
		    
			$scope.getUserProjects = function() {
				
				$scope.loader =false;
				$http.get('http://localhost:8080/getUserProjects', {
					params : {},
				}).then(function(response) {

					$scope.treedata = response.data;
					$scope.selectedprj = response.data[0].id;
					$scope.selectedprjnm = response.data[0].label;
					$scope.getTestCaseDtls();
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});
			};
			$scope.getTestCaseDtls = function() {

			$http.get('http://localhost:8080/getTestCaseDtls', {
					params : {

						projectid : $scope.selectedprj
					},
				}).then(function(response) {

					$scope.testCases = response.data;
					if ($scope.testCases == '') {
						$scope.testCases.push({
							'testCaseId' : '',
							'testCaseName' : '',
							'testQryOne' : '',
							'testQryTwo' : '',
							'testDSOne' : '',
							'testDSTwo' : '',
							'testResultFlag' : false,
							'testExecFlag' : false,
							'projectId' : $scope.selectedprj,
							'projectName' : $scope.selectedprjnm
						});
					}
					console.log("detail--" + response.data);
					$scope.loader =false;
				});
			};

			$scope.addNew = function(a,qryOne,qryTwo,DsOne,Dstwo) {
				jsonObj = [];
				item = {}
				$scope.showAddTestCaseName =true;
				$scope.showAddProjectName =true;
				
				item["projectId"] = $scope.prjId;
				item["testCaseName"] = a;
				item["testQryOne"] = qryOne;
				item["testQryTwo"] = qryTwo;
				item["testDSOne"] = DsOne;
				item["testDSTwo"] = Dstwo;

				 $http.post('http://localhost:8080/addTestCase', JSON.stringify(item)).then(function (response) {
                     if (response.data)
                  	   {
                    	 var status =response.data;
                    	   
                    	   if(status===999)
                    		   {
                    		   $scope.successsMsg=false;
                        	   $scope.alertMsg = "name already present";
                    		   }
                    	   else
                    		   {
                    		   $scope.disabled=false;
                    	   $scope.successsMsg=true;
                    	   $scope.alertMsg =  "New TestCase added successfully";
                    		   }
                  	   }
                     $scope.myFunc($scope.prjId,$scope.prjlabel);
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
				 $scope.showSaveBtn11=false;
				 $scope.myFunc($scope.prjId,$scope.prjlabel);
			};
			$scope.saveDS = function(key,dsName,dsType,hostname,portno,service,serviceType,dsUserName,dsPassword) {
				
				
				jsonObj = [];
				item = {}
				$scope.showAddTestCaseName =true;
				$scope.showAddProjectName =true;
				$scope.showAddDSName=true;
				item["key"]  = key;
				item["val"] = dsName;
				item["checked"] = true;
				item["dsType"] = dsType;
				item["dsHost"] = hostname;
				item["dsPort"] = portno;
				item["dsService"] = service;
				item["dsServiceType"] = serviceType;
				item["dsUserName"] = dsUserName;
				item["dsPassword"] = dsPassword;

				 $http.post('http://localhost:8080/saveDS', JSON.stringify(item)).then(function (response) {
					 $scope.init();
                     if (response.data)
                  	   {
                    	
                    	 var status =response.data;
                  	   
                  	   if(status === 999)
                  		   {
                  	
                  		   $scope.successsMsg=false;
                      	   $scope.alertMsg = "name already present";
                  		   }
                  	   else
                  		   {
                  	   $scope.successsMsg=true;
                  	   $scope.alertMsg =  "Datsource added successfully";
                  	   
                  		   }
                  	 
                  	   
                  	   }
                    
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
				
				 $scope.showDSBTTN12=false;
				 
			};
          $scope.testDS = function(key,dsName,dsType,hostname,portno,service,serviceType,dsUserName,dsPassword) {
				
				
				jsonObj = [];
				item = {}
				$scope.showAddTestCaseName =true;
				$scope.showAddProjectName =true;
				$scope.showAddDSName=true;
				item["key"]  = key;
				item["val"] = dsName;
				item["checked"] = true;
				item["dsType"] = dsType;
				item["dsHost"] = hostname;
				item["dsPort"] = portno;
				item["dsService"] = service;
				item["dsServiceType"] = serviceType;
				item["dsUserName"] = dsUserName;
				item["dsPassword"] = dsPassword;

				 $http.post('http://localhost:8080/testDS', JSON.stringify(item)).then(function (response) {
					
                     if (response.data)
                  	   {
                    	
                    	 var status =response.data;
                  	   
                  	   if(status === 999)
                  		   {
                  	
                  		   $scope.successsMsgmodal=false;
                      	   $scope.alertMsgmodal = "Error in connection";
                      	 $scope.testconnection=true;
                  		   }
                  	   else
                  		   {
                  	   $scope.successsMsgmodal=true;
                  	   $scope.alertMsgmodal =  "Successfully connected";
                  	 $scope.testconnection=false;
                  		   }
                  	 
                  	   
                  	   }
                    
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
				   
				 $scope.showDSBTTN12=false;
				 
			};
			 $scope.deleteDB= function () {
    				/*$scope.showAddProjectName=true;
    				$scope.showSaveBtn=false;*/
    				
    				
    				// $scope.msg = "test";
    				jsonObj = [];
    				item = {}
    				
    				item["dsid"] =$scope.key;
    				
    				
    				
    				
    				
    				jsonObj.push(item);
    				// alert(JSON.stringify(item));
          $http.post('http://localhost:8080/deleteDB', JSON.stringify(item)).then(function (response) {
                           if (response.data)
                        	   {
                        	   $scope.init();
                        	   $scope.successsMsg=true;
                        	   $scope.alertMsg =  $scope.dsName +"  deleted Succesfully";
                        	   }
                           //$scope.getUserProjects();
    	                       }, function (response) {
    	                    	   
    	                    	  
    	                       $scope.msg = "Service not Exists";
    	  
    	                       });
    			
                           };

			$scope.removeRow = function(a) {
				jsonObj = [];
				item = {}
				item["testCaseId"] = a;
				$http.post('http://localhost:8080/deleteTestCase', JSON.stringify(item)).then(function (response) {
					$scope.myFunc($scope.prjId,$scope.prjlabel);
                    if (response.data)
                 	   {
                 	   $scope.successsMsg=true;
                 	   $scope.alertMsg = "TestCAse Deleted Succesfully";
                 	  $scope.myFunc($scope.prjId,$scope.prjlabel);
                 	   }
                    $scope.getUserProjects();
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
				
				/*
				 * if (index == 0) { $scope.testCases.splice(index, 1);
				 * $scope.testCases.push({ 'testCaseId' : '', 'testCaseName' :
				 * '', 'testQryOne' : '', 'testQryTwo' : '', 'testDSOne' : '',
				 * 'testDSTwo' : '', 'testResultFlag' : false, 'testExecFlag' :
				 * false, 'projectId' : '', 'projectName' : '' }); } else {
				 * $scope.testCases.splice(index, 1); }
				 */

			};
			
			$scope.startTesting = function(obj) {
				$scope.loader =true;
				/* $scope.successsMsg=false; */
          	 var error= JSON.stringify(obj.case.testCaseName);
              				$http.post('http://localhost:8080/compareQuery',
						JSON.stringify(obj.case)).then(function(response) {
							/*$scope.loader =false;*/
							var a=0;
							/*if(response.data.testCaseName!==error)
								{
								$scope.successsMsg=false;
								$scope.loader =false;
								$scope.alertMsg = response.data.testCaseName;
								}*/
							if(response.data)
								{
								alert(response.data.testResultFlag );
				/*
				 * angular.forEach($scope.testCases, function(value, key){
				 * if(parseInt(response.data.testCaseId)==parseInt(value.testCaseId)) {
				 * $scope.testCases[key].testResultFlag =
				 * response.data.testResultFlag;
				 * $scope.testCases[key].testResultStats =
				 * response.data.testResultStats; } $scope.loader =false; });
				 */
							$scope.successsMsg=true; 
							/* $scope.alertMsg = "Getting Results"; */
							$scope.testCasesDtl[0].testResultFlag=response.data.testResultFlag;
							$scope.testCasesDtl[0].testResultStats = response.data.testResultStats;
							alert($scope.testCasesDtl[0].testResultStats );
							$scope.loader =false;
							a=a+1;
								}
							else
								{
								$scope.successsMsg=false;
								$scope.loader =false;
								$scope.alertMsg = "Error in Query";
								}
							
					
				});
				
				$scope.alertMsg = "";
				
				console.log(obj);
			};

			$scope.executeAllCase = function() {

				$scope.loader =true;
				
				// alert("3333-- " + JSON.stringify($scope.testCases))
				
				jsonObj = [];
				item = {}
				item["listTestCases"] = $scope.testCases;
				item["resultStat"] = "false";
				jsonObj.push(item);

				// alert("4444-- " + JSON.stringify(item))

				$http.post('http://localhost:8080/compareQueries',
						JSON.stringify(item)).then(function(response) {
					
					$scope.testCases = response.data.listTestCases;
					$scope.loader =false;
					// $scope.response = resp;
				});

				
				console.log(obj);
			};

			/*
			 * $scope.saveSelectedCases = function() {
			 * 
			 * $scope.loader =true;
			 * 
			 * jsonObj = []; item = {} item["listTestCases"] = $scope.testCases;
			 * item["resultStat"] = "false"; jsonObj.push(item);
			 * 
			 * $http.post('http://localhost:8080/saveSelectedCases',
			 * JSON.stringify(item)).then(function(response) {
			 * $scope.loadingStatus = false;
			 * 
			 * if(parseInt(response.data)>0) { $scope.errorMessage =false;
			 * $scope.successMessage = 'TestCases Saved Successfully.';
			 * 
			 * $scope.getUserProjects(); } else{ $scope.successMessage = false;
			 * $scope.errorMessage = 'Error in saving testcases.'; }
			 * $scope.loader =false; // $scope.testCases = response.data; //
			 * $scope.response = resp; });
			 * 
			 * 
			 * console.log(obj); };
			 */
              $scope.saveSelectedCases = function(tcid,tcname,tcqryone,tcqrytwo,tcdsone,tcdstwo) {
				
				$scope.loader =true;		            	
				jsonObj = [];
				item = {}
				item["testCaseId"] = tcid;
				item["testCaseName"] = tcname;
				item["testQryOne"] = tcqryone;
				item["testQryTwo"] = tcqrytwo;
				item["testDSOne"] = tcdsone;
				item["testDSTwo"] = tcdstwo;
				jsonObj.push(item);

				$http.post('http://localhost:8080/saveSelectedCases',
						JSON.stringify(item)).then(function(response) {
					$scope.loadingStatus = false;
					
					if(parseInt(response.data)>0)
					{
						$scope.successsMsg=true;
                 	   $scope.alertMsg = tcname + " has been updated succesfully";
						
					 	/* $scope.init(); */
					}
					else{
						$scope.successMessage = false;
						 $scope.alertMsg = "Error occured while updated";
					}
					$scope.loader =false;
					// $scope.testCases = response.data;
					// $scope.response = resp;
				});

				
				console.log(obj);
			}
			$scope.savePrj = function (name, desc, owner) {
				$scope.showAddProjectName=true;
				$scope.showSaveBtn=false;
				
				
				 $scope.msg = "test";
				jsonObj = [];
				item = {}
				
				item["projectname"] = name;
				item["projectdesc"] = desc;
				item["projectowner"] = owner;
				
				
				jsonObj.push(item);
				// alert(JSON.stringify(item));
      $http.post('http://localhost:8080/saveNewPrj', JSON.stringify(item)).then(function (response) {
                       if (response.data)
                    	   {
                    	   var status =response.data;
                    	   
                    	   if(status===999)
                    		   {
                    		   $scope.successsMsg=false;
                        	   $scope.alertMsg = "name already present";
                    		   }
                    	   else
                    		   {
                    	   $scope.successsMsg=true;
                    	   $scope.alertMsg = "New project Added Succesfully";
                    		   }
                    	   }
                       $scope.getUserProjects();
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
                       };
                       
                       
                       $scope.deletePrj = function () {
           				$scope.showAddProjectName=true;
           				$scope.showSaveBtn=false;
           				
           				
           				// $scope.msg = "test";
           				jsonObj = [];
           				item = {}
           				
           				item["projectId"] = $scope.prjId;
           				item["projectname"] = $scope.prjlabel;
           				
           				
           				
           				
           				jsonObj.push(item);
           				// alert(JSON.stringify(item));
                 $http.post('http://localhost:8080/deletePrj', JSON.stringify(item)).then(function (response) {
                                  if (response.data)
                               	   {
                               	   $scope.successsMsg=true;
                               	   $scope.alertMsg =  $scope.prjlabel+" project deleted Succesfully";
                               	   }
                                  $scope.getUserProjects();
           	                       }, function (response) {
           	                    	   
           	                    	  
           	                       $scope.msg = "Service not Exists";
           	  
           	                       });
           			
                                  };
                                  
                                  
			$scope.exportAction = function(option) {
				switch (option) {
				case 'pdf':
					$scope.$broadcast('export-pdf', {});
					break;
				case 'excel':
					$scope.$broadcast('export-excel', {});
					break;
				case 'doc':
					$scope.$broadcast('export-doc', {});
					break;
				case 'csv':
					$scope.$broadcast('export-csv', {});
					break;
				default:
					console.log('no event caught');
				}
			}

			$scope.$watch('abc.currentNode', function(newObj, oldObj) {
				
				$scope.successMessage = false;
				$scope.errorMessage =false;				
				if ($scope.abc && angular.isObject($scope.abc.currentNode)) {
					console.log('Node Selected!!');
					console.log($scope.abc.currentNode);
				}
				
				if(parseInt($scope.abc.currentNode.id)<100){
					angular.forEach($scope.testCases, function(value, key){
		
						if(parseInt($scope.abc.currentNode.id)==parseInt(value.testCaseId))
						{
							$scope.testCases[key].testExecFlag = true;
						}
						else{
							
							$scope.testCases[key].testExecFlag = false;
						}
					});
				}
				else{
					
					$scope.selectedprj = $scope.abc.currentNode.id;
					$scope.selectedprjnm = $scope.abc.currentNode.label;
					$scope.getTestCaseDtls();
				}
				
			}, false);

		} ]);
 

 
/*
 * app.directive('ngRightClick', function($parse) { return function(scope,
 * element, attrs) { var fn = $parse(attrs.ngRightClick);
 * element.bind('contextmenu', function(event) { scope.$apply(function() {
 * event.preventDefault(); fn(scope, {$event:event}); }); }); }; });
 */

app.directive('exportTable', function() {
	var link = function($scope, elm, attr) {
		$scope.$on('export-pdf', function(e, d) {
			elm.tableExport({
				type : 'pdf',
				escape : false
			});
		});
		$scope.$on('export-excel', function(e, d) {
			elm.tableExport({
				type : 'excel',
				escape : false
			});
		});
		$scope.$on('export-doc', function(e, d) {
			elm.tableExport({
				type : 'doc',
				escape : false
			});
		});
		$scope.$on('export-csv', function(e, d) {
			elm.tableExport({
				type : 'csv',
				escape : false
			});
		});
	}
	return {
		restrict : 'C',
		link : link
	}
});

app
		.directive(
				'loading',
				function() {
					return {
						restrict : 'E',
						replace : true,
						template : '<div class="loading"><img src="http://www.nasa.gov/multimedia/videogallery/ajax-loader.gif" width="20" height="20" />LOADING...</div>',
						link : function(scope, element, attr) {
							scope.$watch('loading', function(val) {
								if (val)
									$scope.loadingStatus = true;
								else
									$scope.loadingStatus = false;
							});
						}
					}
				});
