var app = angular.module('tcapp', [ 'angularTreeview' ]);
app.controller("tcController", [
		'$scope',
		'$http',
		
		function($scope, $http) {
			$scope.init = function() {
				
				// $scope.loadingStatus = true;
				$scope.showAddDSName=true;
				$scope.showDSBTTN12=false;
				$scope.showSaveBtn11=false;
				$scope.showAddTestCaseName =false;
				$scope.loader =true;
				$scope.loader11 =false;
				$scope.successsMsg=false;
				
				$scope.testconnection=true;
				$scope.successsMsgmodal=false;
				$scope.alertMsg='';
				$scope.alertMsgmodal ='';
				$scope.showAddProjectName=true;
				$scope.showSaveBtn=false;
				$scope.getUserProjects();
				$http.get('http://localhost:5464/getDataSources', {
					params : {
					},
				}).then(function(response) {
					$scope.srcNames = response.data;
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});

				$http.get('http://localhost:5464/getTestCaseDtls', {
					params : {},
				}).then(function(response) {

					$scope.testCases = response.data;
					if ($scope.testCases == '') {
						$scope.testCases.push({
							'testCaseId' : '',
							'testCaseName' : '',
							'testQryOne' : '',
							'testQryTwo' : '',
							'testDSOne' : '',
							'testDSTwo' : '',
							'testResultFlag' : false,
							'testExecFlag' : false,
							'projectId' : $scope.selectedprj,
							'projectName' : $scope.selectedprjnm
						});
					}
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});
			};
			
			
			  $scope.GetValue =function(index,dsDtl) { 
			  			  
			  if(index===1){
				  $scope.testDbDSOne =  dsDtl;
			  }
			  else{
				  $scope.testDbDSTwo =  dsDtl;
			  }
			 
			  
			  };
			 
			$scope.editTestCase=function(tstCaseId,tstdescription,tstCaseNm,testQryOne,testQryTwo,testDSOne,testDSTwo){
		
				$scope.testcaseid='';
				$scope.selTestcase='';
				$scope.selQryone='';
				$scope.selQrytwo='';
				$scope.testDbDSOne='';
				$scope.testDbDSTwo='';
				
				angular.forEach($scope.srcNames, function(value2, key2){
				
					if(parseInt(value2.key)===parseInt(testDSOne)){
						$scope.testDbDSOne = value2;
					}
					if(parseInt(value2.key)===parseInt(testDSTwo)){
						$scope.testDbDSTwo = value2;
					}
					
				});	
				
				$scope.testcaseid=tstCaseId;
				$scope.selTestcase=tstCaseNm;
				$scope.description=tstdescription;
				$scope.selQryone=testQryOne;
				$scope.selQrytwo=testQryTwo;
				
			};
			$scope.selectedDB=function(dbDtl){
		
				$scope.key=dbDtl.key;
				$scope.dsName=dbDtl.val;
				$scope.dsType=dbDtl.dsType;
				$scope.hostname=dbDtl.dsHost;
				$scope.portno=dbDtl.dsPort;
				$scope.service=dbDtl.dsService;
				$scope.serviceType=dbDtl.dsServiceType;
				$scope.dsUserName=dbDtl.dsUserName;
				$scope.dsPassword=dbDtl.dsPassword;
				
			};
			$scope.disableMsg=function(){
				 $scope.alertMsgmodal ='';
				
			};
			$scope.emptyplaceholder=function(){
				
				 $scope.name11 ='';
				 $scope.description11 ='';
				 $scope.QryONE ='';
				 $scope.testDSOne11 ='';
				 $scope.QryTWO ='';
				 $scope.testDSTwo11 ='';
				 //alert( $scope.name11);
				 
			};
			$scope.selectAll=function(flagvalue){
				
				var testcasesbackup=$scope.testCases11;
				angular.forEach(testcasesbackup, function(value, key){
					
						$scope.testCases11[key].testExecFlag = flagvalue;
					
				});
				 
		 testcasesbackup='';		 
			
		}; 
			$scope.TestStatus=function(id,flag){
				
							
			var cases=JSON.stringify($scope.testCases);
			
			var tstCase;
			
			 var myAccess = [];

	            angular.forEach($scope.testCases, function (value, key) {
	            	/*
					 * alert(value.testCaseId) alert(value.testCaseId==id)
					 */
	            	if(value.testCaseId==id)
	            		{
	            		
	            		value.testExecFlag=flag;
	            		}
	               /* myAccess.push(value.testCaseId); */
	            });

				
			};
			$scope.EditPrjSave=function(prjname){
				// alert( $scope.prjId);
					            	
				jsonObj = [];
				item = {}
				item["projectId"] = $scope.prjId;
				item["projectname"] = prjname;
				
				jsonObj.push(item);

				$http.post('http://localhost:5464/editPrjName',
						JSON.stringify(item)).then(function(response) {
					$scope.loadingStatus = false;
					$scope.init();
					if(response.data)
					{
						 var status =response.data;
                  	   
                  	   if(status===999)
                  		   {
                  		   $scope.successsMsg=false;
                      	   $scope.alertMsg = "name already present";
                  		   }
                  	   else
                  		   {
                  	   $scope.successsMsg=true;
                  	   $scope.alertMsg =  "Project name has been updated";
                  		   }
						
					 	/* $scope.init(); */
					}
					else{
						$scope.successMessage = false;
						 $scope.alertMsg = "Error occured while updated";
					}
					$scope.loader =false;
					// $scope.testCases = response.data;
					// $scope.response = resp;
				});
			};
			$scope.Edit=function(tcname,description,selQryone1,selQrytwo1,testDSOne1,testDSTwo1 ){
				
				$scope.loader =true;		            	
				jsonObj = [];
				item = {}
				item["testCaseId"] = $scope.testcaseid;
				item["testCaseName"] = tcname;
				item["description"] = description;
				item["testQryOne"] =selQryone1;
				item["testQryTwo"] = selQrytwo1;
				item["testDSOne"] =testDSOne1.key;
				item["testDSTwo"] = testDSTwo1.key;
				jsonObj.push(item);
				
				$http.post('http://localhost:5464/saveSelectedCases',
						JSON.stringify(item)).then(function(response) {
					$scope.loadingStatus = false;
					 $scope.myFunc($scope.prjId,$scope.prjlabel);
					if(response.data)
					{

						 var status =response.data;
                 	   
                 	   if(status===999)
                 		   {
                 		   $scope.successsMsg=false;
                     	   $scope.alertMsg = "name already present";
                 		   }
                 	   else
                 		   {
                 	   $scope.successsMsg=true;
                 	   $scope.alertMsg =  "Test Case name has been updated";
                 		   }
                 	  $scope.myFunc($scope.prjId,$scope.prjlabel);
					 	/* $scope.init(); */
					}
					else{
						$scope.successMessage = false;
						 $scope.alertMsg = "Error occured while updated";
					}
			
					$scope.loader =false;
					// $scope.testCases = response.data;
					// $scope.response = resp;
				});

				
				console.log(obj);
			
			};
						
			 $scope.closeAlert = function(index) {
				    $scope.alerts.splice(index, 1);
				  };
			$scope.showBTTN=function(){
				$scope.showAddProjectName=false;
				$scope.showSaveBtn=true;
			};
			$scope.showBTTN11=function(){
				$scope.showAddProjectName=false;
				$scope.showSaveBtn11=true;
			}
			$scope.showBTTN12=function(){
				$scope.showAddDSName=false;
				$scope.showAddProjectName=false;
				$scope.showAddTestCaseName=false;
				$scope.showDSBTTN12=true;;
			}
			$scope.myFunc11 = function(index) {
				
					$scope.testCases11[index].collapse = !$scope.testCases11[index].collapse;
			/*
			 * var a1=a;
			 * $http.get('http://localhost:5464/getSpecificTestCasedetails', {
			 * params : { testcaseid : a1 }, }).then(function(response) {
			 * 
			 * $scope.testCasesDtl = response.data;
			 * 
			 * if ($scope.testCasesDtl != '') {
			 * 
			 * $scope.disabled=false; $scope.testCasesDtl.push({ 'testCaseId' :
			 * '', 'testCaseName' : '', 'testQryOne' : '', 'testQryTwo' : '',
			 * 'testDSOne' : '', 'testDSTwo' : '', 'testResultFlag' : false,
			 * 'testExecFlag' : false,
			 * 
			 * }); }
			 * 
			 * console.log("detail--" + response.data); // $scope.response =
			 * resp; });
			 */
		    };
		    
			$scope.myFunc = function(prjId,prjLabel) {
				
				$scope.prjId=prjId;
				$scope.prjlabel=prjLabel;
				$scope.showAddTestCaseName =true;
				$http.get('http://localhost:5464/getTestCaseDtls', {
					params : {
						projectid : prjId
					},
				}).then(function(response) {
					
					$scope.testCases11 = response.data;
					if ($scope.testCases11 == '') {
						$scope.disabled=true;
						$scope.testCases11.push({
							'testCaseId' : '',
							'testCaseName' : 'Add Test Case',
							'testQryOne' : '',
							'testQryTwo' : '',
							'testDSOne' : '',
							'testDSTwo' : '',
							'testResultFlag' : false,
							'testExecFlag' : false,
							'projectId' : '',
							'projectName' : ''
						});
					}
					else{
						$scope.disabled=false;
					}
					var testcasesbackup = 	$scope.testCases11;
									
					angular.forEach(testcasesbackup, function(value1, key1){
						
						angular.forEach($scope.srcNames, function(value2, key2){
							
						if(parseInt(value2.key)===parseInt(value1.testDSOne)){
							$scope.testCases11[key1].testDSNmOne = value2.val;
						}
						if(parseInt(value2.key)===parseInt(value1.testDSTwo)){
							$scope.testCases11[key1].testDSNmTwo = value2.val;
						}
						
					});
				});
					
					
					$scope.loader11 =true;
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});
				
		    };
		    
		   
		    
			$scope.getUserProjects = function() {
				
				$scope.loader =false;
				$http.get('http://localhost:5464/getUserProjects', {
					params : {},
				}).then(function(response) {

					$scope.treedata = response.data;
					$scope.selectedprj = response.data[0].id;
					$scope.selectedprjnm = response.data[0].label;
					$scope.getTestCaseDtls();
					console.log("detail--" + response.data);
					// $scope.response = resp;
				});
			};
			$scope.getTestCaseDtls = function() {

			$http.get('http://localhost:5464/getTestCaseDtls', {
					params : {

						projectid : $scope.selectedprj
					},
				}).then(function(response) {

					$scope.testCases = response.data;
					if ($scope.testCases == '') {
						$scope.testCases.push({
							'testCaseId' : '',
							'testCaseName' : '',
							'testQryOne' : '',
							'testQryTwo' : '',
							'testDSOne' : '',
							'testDSTwo' : '',
							'testResultFlag' : false,
							'testExecFlag' : false,
							'projectId' : $scope.selectedprj,
							'projectName' : $scope.selectedprjnm
						});
					}
					console.log("detail--" + response.data);
					$scope.loader =false;
				});
			};

			$scope.addNew = function(a,description11,qryOne,qryTwo,DsOne,Dstwo) {
				jsonObj = [];
				item = {}
				$scope.showAddTestCaseName =true;
				$scope.showAddProjectName =true;
				
				item["projectId"] = $scope.prjId;
				item["testCaseName"] = a;
				item["description"] = description11;
				item["testQryOne"] = qryOne;
				item["testQryTwo"] = qryTwo;
				item["testDSOne"] = DsOne;
				item["testDSTwo"] = Dstwo;

				 $http.post('http://localhost:5464/addTestCase', JSON.stringify(item)).then(function (response) {
                     // if (response.data)
                  	  // {
                    	 var status =response.data;
                    	   
                    	   if(status===999)
                    		   {
                    		   $scope.successsMsg=false;
                        	   $scope.alertMsg = "name already present";
                    		   }
                    	   else
                    		   {
                    		   $scope.disabled=false;
                    	   $scope.successsMsg=true;
                    	   $scope.alertMsg =  "New TestCase added successfully";
                    		   }
                  	   // }
                     $scope.myFunc($scope.prjId,$scope.prjlabel);
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
				 $scope.showSaveBtn11=false;
				 $scope.myFunc($scope.prjId,$scope.prjlabel);
				 $scope.name11 ='';
				 $scope.description11 ='';
				 $scope.QryONE ='';
				 $scope.testDSOne11 ='';
				 $scope.QryTWO ='';
				 $scope.testDSTwo11 ='';
				 
			};
			$scope.saveDS = function(key,dsName,dsType,hostname,portno,service,serviceType,dsUserName,dsPassword) {
				
				
				jsonObj = [];
				item = {}
				$scope.showAddTestCaseName =true;
				$scope.showAddProjectName =true;
				$scope.showAddDSName=true;
				item["key"]  = key;
				item["val"] = dsName;
				item["checked"] = true;
				item["dsType"] = dsType;
				item["dsHost"] = hostname;
				item["dsPort"] = portno;
				item["dsService"] = service;
				item["dsServiceType"] = serviceType;
				item["dsUserName"] = dsUserName;
				item["dsPassword"] = dsPassword;

				 $http.post('http://localhost:5464/saveDS', JSON.stringify(item)).then(function (response) {
					 $scope.init();
                   // if (response.data)
                  	  // {
                    	
                    	 var status =response.data;
                  	   
                  	   if(status === 999)
                  		   {
	                  		   $scope.successsMsg=false;
	                      	   $scope.alertMsg = "name already present";
                  		   }
                  	   else
                  		   {
		                  	   $scope.successsMsg=true;
		                  	   $scope.alertMsg =  "Datsource added successfully";
                  	   
                  		   }
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
				 
				 $scope.key='';
				 $scope.val='';
				 $scope.checked='';
				 $scope.dsType='';
				 $scope.dsHost='';
				 $scope.dsPort='';
				 $scope.dsService='';
				 $scope.dsServiceType='';
				 $scope.dsUserName='';
				 $scope.dsPassword='';

				 
				
				 $scope.showDSBTTN12=false;
				 
			};
          $scope.testDS = function(key,dsName,dsType,hostname,portno,service,serviceType,dsUserName,dsPassword) {
				
        	  $scope.loader =true;
				jsonObj = [];
				item = {}
				$scope.showAddTestCaseName =true;
				$scope.showAddProjectName =true;
				$scope.showAddDSName=true;
				item["key"]  = key;
				item["val"] = dsName;
				item["checked"] = true;
				item["dsType"] = dsType;
				item["dsHost"] = hostname;
				item["dsPort"] = portno;
				item["dsService"] = service;
				item["dsServiceType"] = serviceType;
				item["dsUserName"] = dsUserName;
				item["dsPassword"] = dsPassword;

				 $http.post('http://localhost:5464/testDS', JSON.stringify(item)).then(function (response) {
					 // alert('inside response 1');
					// alert('response.data'+JSON.stringify(response.data));
                  // if (response.data===)
                  	  // {
                    	// alert('inside response 2');
                    	 var status =response.data;
                    	// alert('status -- '+status);
                  	   if(status === 999)
                  		   {
                  	
                  		   $scope.successsMsgmodal=false;
                      	   $scope.alertMsgmodal = "Error in Connection";
                      	 $scope.testconnection=true;
                  		   }
                  	   else
                  		   {
                  	   $scope.successsMsgmodal=true;
                  	   $scope.alertMsgmodal =  "Successfully Connected";
                  	 $scope.testconnection=false;
                  		   }
                  	 
                  	   
                  	  // }
                    
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
				 
				 $scope.key='';
				 $scope.val='';
				 $scope.checked='';
				 $scope.dsType='';
				 $scope.dsHost='';
				 $scope.dsPort='';
				 $scope.dsService='';
				 $scope.dsServiceType='';
				 $scope.dsUserName='';
				 $scope.dsPassword='';
				 $scope.loader =false;
				 $scope.showDSBTTN12=false;
				 
			};
			 $scope.deleteDB= function () {
    				/*
					 * $scope.showAddProjectName=true; $scope.showSaveBtn=false;
					 */
    				
    				
    				// $scope.msg = "test";
    				jsonObj = [];
    				item = {}
    				
    				item["dsid"] =$scope.key;
    				
    				
    				
    				
    				
    				jsonObj.push(item);
    				// alert(JSON.stringify(item));
          $http.post('http://localhost:5464/deleteDB', JSON.stringify(item)).then(function (response) {
                           if (response.data)
                        	   {
                        	   $scope.init();
                        	   $scope.successsMsg=true;
                        	   $scope.alertMsg =  $scope.dsName +"  deleted Succesfully";
                        	   }
                           // $scope.getUserProjects();
    	                       }, function (response) {
    	                    	   
    	                    	  
    	                       $scope.msg = "Service not Exists";
    	  
    	                       });
    			
                           };

			$scope.removeRow = function(a) {
				jsonObj = [];
				item = {}
				item["testCaseId"] = a;
				$http.post('http://localhost:5464/deleteTestCase', JSON.stringify(item)).then(function (response) {
					$scope.myFunc($scope.prjId,$scope.prjlabel);
                   if (response.data)
             	   {
	             	   $scope.successsMsg=true;
	             	   $scope.alertMsg = "TestCAse Deleted Succesfully";
	             	   $scope.myFunc($scope.prjId,$scope.prjlabel);
             	   }
                    $scope.getUserProjects();
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
			};
			
			$scope.startTesting = function(obj) {
				$scope.loader =true;
				/* $scope.successsMsg=false; */
          	 var error= JSON.stringify(obj.case.testCaseName);
              				$http.post('http://localhost:5464/compareQuery',
						JSON.stringify(obj.case)).then(function(response) {
							
							var a=0;
							/*
							 * if(response.data.testCaseName!==error) {
							 * $scope.successsMsg=false; $scope.loader =false;
							 * $scope.alertMsg = response.data.testCaseName; }
							 */
							if(response.data)
								{
								
							$scope.successsMsg=true; 
							/* $scope.alertMsg = "Getting Results"; */
							// $scope.testCasesDtl[0].testResultFlag=response.data.testResultFlag;
							// $scope.testCasesDtl[0].testResultStats =
							// response.data.testResultStats;
							// alert($scope.testCasesDtl[0].testResultStats );
							
							angular.forEach($scope.testCases11, function(value, key){
								
								if(parseInt(obj.case.testCaseId)==parseInt(value.testCaseId))
								{
									// alert(key)
									$scope.testCases11[key].testResultFlag = response.data.testResultFlag;
									$scope.testCases11[key].testExecFlag = true;
								}
								else{
									
									$scope.testCases11[key].testExecFlag = false;
								}
							});
							
							$scope.loader =false;
							a=a+1;
								}
							else
								{
								$scope.successsMsg=false;
								$scope.loader =false;
								$scope.alertMsg = "Error in Query";
								}
							
					
				});
				
				$scope.alertMsg = "";
				
				console.log(obj);
			};
			
			
			$scope.startTestingForAll = function(tstCase) {
				$scope.loader =true;
				/* $scope.successsMsg=false; */
				// alert(111)
          	 var error= JSON.stringify(tstCase.testCaseName);
              				$http.post('http://localhost:5464/compareQuery',
						JSON.stringify(tstCase)).then(function(response) {
							
							if(response.data)
								{
									$scope.successsMsg=true; 
									/* $scope.alertMsg = "Getting Results"; */
									// $scope.testCasesDtl[0].testResultFlag=response.data.testResultFlag;
									// $scope.testCasesDtl[0].testResultStats =
									// response.data.testResultStats;
									// alert($scope.testCasesDtl[0].testResultStats );
									
									angular.forEach($scope.testCases11, function(value, key){
										
										if(parseInt(tstCase.testCaseId)==parseInt(value.testCaseId))
										{
											// alert(key)
											$scope.testCases11[key].testResultFlag = response.data.testResultFlag;
											$scope.testCases11[key].testExecFlag = true;
										}
										else{
											
											$scope.testCases11[key].testExecFlag = false;
										}
									});	
									$scope.loader =false;
								}
							else
								{
									$scope.successsMsg=false;
									$scope.loader =false;
									$scope.alertMsg = "Error in Query";
								}
							
					
				});
				
				$scope.alertMsg = "";
				
				// console.log(obj);
			};

			$scope.executeAllCase = function() {
			
				angular.forEach($scope.testCases11, function(value, key){
										
					$scope.startTestingForAll(value);
					
				});

			};

			/*
			 * $scope.saveSelectedCases = function() {
			 * 
			 * $scope.loader =true;
			 * 
			 * jsonObj = []; item = {} item["listTestCases"] = $scope.testCases;
			 * item["resultStat"] = "false"; jsonObj.push(item);
			 * 
			 * $http.post('http://localhost:5464/saveSelectedCases',
			 * JSON.stringify(item)).then(function(response) {
			 * $scope.loadingStatus = false;
			 * 
			 * if(parseInt(response.data)>0) { $scope.errorMessage =false;
			 * $scope.successMessage = 'TestCases Saved Successfully.';
			 * 
			 * $scope.getUserProjects(); } else{ $scope.successMessage = false;
			 * $scope.errorMessage = 'Error in saving testcases.'; }
			 * $scope.loader =false; // $scope.testCases = response.data; //
			 * $scope.response = resp; });
			 * 
			 * 
			 * console.log(obj); };
			 */
              $scope.saveSelectedCases = function(tcid,tcname,tcqryone,tcqrytwo,tcdsone,tcdstwo) {
				
            	  alert("save selected");
				$scope.loader =true;		            	
				jsonObj = [];
				item = {}
				item["testCaseId"] = tcid;
				item["testCaseName"] = tcname;
				item["testQryOne"] = tcqryone;
				item["testQryTwo"] = tcqrytwo;
				item["testDSOne"] = tcdsone;
				item["testDSTwo"] = tcdstwo;
				jsonObj.push(item);

				$http.post('http://localhost:5464/saveSelectedCases',
						JSON.stringify(item)).then(function(response) {
					$scope.loadingStatus = false;
					
					if(parseInt(response.data)>0)
					{
						$scope.successsMsg=true;
                 	   $scope.alertMsg = tcname + " has been updated succesfully";
						
					 	/* $scope.init(); */
					}
					else{
						$scope.successMessage = false;
						 $scope.alertMsg = "Error occured while updated";
					}
					$scope.loader =false;
					// $scope.testCases = response.data;
					// $scope.response = resp;
				});

				
				console.log(obj);
			}
			$scope.savePrj = function (name, desc, owner) {
				$scope.showAddProjectName=true;
				$scope.showSaveBtn=false;
				
				
				 $scope.msg = "test";
				jsonObj = [];
				item = {}
				
				item["projectname"] = name;
				item["projectdesc"] = desc;
				item["projectowner"] = owner;
				
				
				jsonObj.push(item);
				// alert(JSON.stringify(item));
				$http.post('http://localhost:5464/saveNewPrj', JSON.stringify(item)).then(function (response) {
                       	if (response.data)
	                	   {
	                    	   var status =response.data;
	                    	   if(status===999)
	                		   {
	                    		   $scope.successsMsg=false;
	                        	   $scope.alertMsg = "name already present";
	                		   }
	                    	   else
	                		   {
			                	   $scope.successsMsg=true;
			                	   $scope.alertMsg = "New project Added Succesfully";
	                		   }
	                	   }
                       			$scope.getUserProjects();
	                       }, function (response) {
	                    	   
	                    	  
	                       $scope.msg = "Service not Exists";
	  
	                       });
                       };
                       
                       
                       $scope.deletePrj = function () {
	           				$scope.showAddProjectName=true;
	           				$scope.showSaveBtn=false;
	           				jsonObj = [];
	           				item = {}
	           				item["projectId"] = $scope.prjId;
	           				item["projectname"] = $scope.prjlabel;
	           				jsonObj.push(item);
	           				$http.post('http://localhost:5464/deletePrj', JSON.stringify(item)).then(function (response) {
	                                  if (response.data)
	                               	   {
	                               	   $scope.successsMsg=true;
	                               	   $scope.alertMsg =  $scope.prjlabel+" project deleted Succesfully";
	                               	   }
	                                  $scope.getUserProjects();
	           	                       }, function (response) {
	           	                    	   
	           	                    	  
	           	                       $scope.msg = "Service not Exists";
	           	  
	           	                       });
           			
                    };
                                  
                                  
			$scope.exportAction = function(option) {
				switch (option) {
				case 'pdf':
					$scope.$broadcast('export-pdf', {});
					break;
				case 'excel':
					$scope.$broadcast('export-excel', {});
					break;
				case 'doc':
					$scope.$broadcast('export-doc', {});
					break;
				case 'csv':
					$scope.$broadcast('export-csv', {});
					break;
				default:
					console.log('no event caught');
				}
			}

			$scope.$watch('abc.currentNode', function(newObj, oldObj) {
				
				$scope.successMessage = false;
				$scope.errorMessage =false;				
				if ($scope.abc && angular.isObject($scope.abc.currentNode)) {
					console.log('Node Selected!!');
					console.log($scope.abc.currentNode);
				}
				
				if(parseInt($scope.abc.currentNode.id)<100){
					angular.forEach($scope.testCases, function(value, key){
		
						if(parseInt($scope.abc.currentNode.id)==parseInt(value.testCaseId))
						{
							$scope.testCases[key].testExecFlag = true;
						}
						else{
							
							$scope.testCases[key].testExecFlag = false;
						}
					});
				}
				else{
					
					$scope.selectedprj = $scope.abc.currentNode.id;
					$scope.selectedprjnm = $scope.abc.currentNode.label;
					$scope.getTestCaseDtls();
				}
				
			}, false);

		} ]);
 

 
/*
 * app.directive('ngRightClick', function($parse) { return function(scope,
 * element, attrs) { var fn = $parse(attrs.ngRightClick);
 * element.bind('contextmenu', function(event) { scope.$apply(function() {
 * event.preventDefault(); fn(scope, {$event:event}); }); }); }; });
 */

app.directive('exportTable', function() {
	var link = function($scope, elm, attr) {
		$scope.$on('export-pdf', function(e, d) {
			elm.tableExport({
				type : 'pdf',
				escape : false
			});
		});
		$scope.$on('export-excel', function(e, d) {
			elm.tableExport({
				type : 'excel',
				escape : false
			});
		});
		$scope.$on('export-doc', function(e, d) {
			elm.tableExport({
				type : 'doc',
				escape : false
			});
		});
		$scope.$on('export-csv', function(e, d) {
			elm.tableExport({
				type : 'csv',
				escape : false
			});
		});
	}
	return {
		restrict : 'C',
		link : link
	}
});

app
		.directive(
				'loading',
				function() {
					return {
						restrict : 'E',
						replace : true,
						template : '<div class="loading"><img src="http://www.nasa.gov/multimedia/videogallery/ajax-loader.gif" width="20" height="20" />LOADING...</div>',
						link : function(scope, element, attr) {
							scope.$watch('loading', function(val) {
								if (val)
									$scope.loadingStatus = true;
								else
									$scope.loadingStatus = false;
							});
						}
					}
				});
